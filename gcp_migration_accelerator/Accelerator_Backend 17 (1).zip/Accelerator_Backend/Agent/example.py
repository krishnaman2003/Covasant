import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, SetupOptions
import argparse
import csv
 
# Parser for CSV to dictionary
class ParseCSV(beam.DoFn):
    def __init__(self, headers):
        self.headers = headers
 
    def process(self, line):
        row = next(csv.reader([line]))
        return [dict(zip(self.headers, row))]
 
# Unpacks the result of the CoGroupByKey
def unpack_cgbk_results(element):
    key, value = element
    employees = value['emp']
    departments = value['dept']
    # Ensure there is a matching department for the employees
    if employees and departments:
        department = departments[0]
        for employee in employees:
            yield (employee, department)
 
# Processes each (employee, department) pair
class ProcessAndFilter(beam.DoFn):
    def process(self, record):
        emp, dept = record
        salary = int(emp['Salary'])
        if salary > 15000:
            yield {
                'Dname': dept['Dname'],
                'Salary': salary
            }
 
def run(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--input_employees', required=True, help='GCS path for employees.csv')
    parser.add_argument('--input_departments', required=True, help='GCS path for department.csv')
    parser.add_argument('--output_table', required=True, help='BigQuery table spec, e.g., project:dataset.table')
    known_args, pipeline_args = parser.parse_known_args(argv)
 
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(SetupOptions).save_main_session = True
 
    with beam.Pipeline(options=pipeline_options) as p:
 
        employees = (
            p
| 'Read Employees' >> beam.io.ReadFromText(known_args.input_employees, skip_header_lines=1)
            | 'Parse Employees' >> beam.ParDo(ParseCSV(['Eid', 'FirstName', 'LastName', 'Did', 'Salary']))
            | 'Emp Key By Did' >> beam.Map(lambda x: (x['Did'], x))
        )
 
        departments = (
            p
| 'Read Departments' >> beam.io.ReadFromText(known_args.input_departments, skip_header_lines=1)
            | 'Parse Departments' >> beam.ParDo(ParseCSV(['Did', 'Dname']))
            | 'Dept Key By Did' >> beam.Map(lambda x: (x['Did'], x))
        )
 
        # Correctly join, unpack, and filter the data
        processed_data = (
            {'emp': employees, 'dept': departments}
            | 'Join Emp + Dept' >> beam.CoGroupByKey()
            | 'Unpack Join' >> beam.FlatMap(unpack_cgbk_results)
            | 'Filter by Salary' >> beam.ParDo(ProcessAndFilter())
        )
 
        # Aggregate the results and format for BigQuery
        aggregated = (
            processed_data
            | 'Group by Department' >> beam.Map(lambda x: (x['Dname'], x['Salary']))
            | 'Sum Salary' >> beam.CombinePerKey(sum)
            | 'Format for BigQuery' >> beam.Map(lambda x: {'Dname': x[0], 'TotalSalary': x[1]})
        )
 
        # Write the final result to the specified BigQuery table
        aggregated | 'Write to BigQuery' >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema='Dname:STRING,TotalSalary:INTEGER',
create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
            )
 
if __name__ == '__main__':
#     python main.py ^
#   --runner DataflowRunner ^
#   --project data-pipeline-project-466008 ^
#   --region us-central1 ^
#   --temp_location gs://etl-bucket-2025/temp ^
#   --staging_location gs://etl-bucket-2025/staging ^
#   --input_employees gs://etl-bucket-2025/input/employees.csv ^
#   --input_departments gs://etl-bucket-2025/input/department.csv ^
#   --output_table data-pipeline-project-466008:etl_demo.department_salary_summary ^
#   --job_name etl-department-salary-summary
    run()