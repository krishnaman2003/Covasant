
import os
import json
import re 
import traceback
from pydantic import BaseModel
from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai.types import Content, Part
from dotenv import load_dotenv
from google.oauth2 import service_account
import vertexai
from vertexai.preview.generative_models import GenerativeModel


# THE FIX: Explicitly find and load the .env file from this script's directory.
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(dotenv_path=dotenv_path)

# load_dotenv(".env")
# # BASE_DIR = "project_workspace"
# SERVICE_ACCOUNT_INFO = json.loads(os.getenv("GOOGLE_CREDENTIALS"))
# credentials = service_account.Credentials.from_service_account_info(SERVICE_ACCOUNT_INFO)
# vertexai.init(project=SERVICE_ACCOUNT_INFO["project_id"], credentials=credentials)
# model_name = "gemini-2.5-pro-preview-05-06"

try:
    # Assuming example.py is in the root of your project or accessible path
    with open('example.py', 'r') as f:
        EXAMPLE_BEAM_SCRIPT_CONTENT = f.read()
except FileNotFoundError:
    EXAMPLE_BEAM_SCRIPT_CONTENT = "# Example Beam script not found."

# --- Pydantic Models for Data Validation ---
class GCPConfig(BaseModel):
    project_id: str
    region: str
    bucket_name: str
    bigquery_dataset: str

class AgentRequest(BaseModel):
    unified_json: dict
    gcp_config: GCPConfig

# --- Tuned Agent Definition ---
json_to_beam_agent = Agent(
    model='gemini-2.5-pro-preview-05-06',
    # model=model_name,
    name='json_to_beam_agent',
    description='An expert agent that converts a unified ETL JSON and GCP config into a Beam script and a fully populated Cloud Build YAML.',
    instruction=f"""
    You are an expert Google Cloud data engineer. Your task is to convert a unified ETL pipeline JSON into a functional Apache Beam script and generate a ready-to-use `cloudbuild.yaml` file using the provided GCP configuration.

    **CONTEXT YOU WILL RECEIVE:**
    1.  **Unified Pipeline JSON:** A JSON object describing the ETL pipeline's sources, targets, and transformations.
    2.  **GCP Configuration:** A JSON object with specific values for `project_id`, `region`, `bucket_name`, and `bigquery_dataset`.

    **YOUR TASKS:**

    **TASK 1: GENERATE THE APACHE BEAM SCRIPT**
    - The script must be a complete, runnable Python file.
    - Use `argparse` to define command-line arguments for **ALL** sources found in the `SOURCE_LIST`. For a source named "employees_data", create an argument `--input_employees_data`.
    - For each source: if the type is 'csv' or 'flat file', read from GCS using `beam.io.ReadFromText`; if the type is 'table' or any oracle_src/database, read from BigQuery using `beam.io.ReadFromBigQuery`. Do not generate any JDBC or database connection code.
    - The final output sink **MUST** be `beam.io.WriteToBigQuery`. Create an `--output_table` argument for the BigQuery table specification.
    - **IMPORTANT:** Always set `write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND` in `WriteToBigQuery` so that data is appended, not overwritten.
    - Translate the logic from the `TRANSFORMATIONS` list into Beam PTransforms (`Map`, `Filter`, `CoGroupByKey`, etc.).
    - **CRITICAL JOIN RULE:** When implementing a join using `beam.CoGroupByKey`, you **MUST** first prepare each input PCollection. Use a `beam.Map` transform to convert each element into a 2-element `(key, value)` tuple. The `key` is the column to join on, and the `value` is the **entire dictionary** for that row`.
    - Reference the provided `example.py` for style, structure, and best practices.

    **TASK 2: GENERATE THE `cloudbuild.yaml` FILE**
    - Use the provided `GCP Configuration` to populate the YAML file. **DO NOT use placeholders like 'project-id'.**
    - The YAML must follow this exact structure:
    ```yaml
    steps:
    - name: 'python:3.9'
      entrypoint: 'bash'
      args:
      - '-c'
      - |
        pip install 'apache-beam[gcp]==2.66.0' && \\
        python <<beam_script_name>> \\
            --runner DataflowRunner \\
            --project <<project_id>> \\
            --region <<region>> \\
            --temp_location gs://<<bucket_name>>/temp \\
            --staging_location gs://<<bucket_name>>/staging \\
            <<dynamic_input_args>> \\
            --output_table <<project_id>>:<<bigquery_dataset>>.<<output_table_name>> \\
            --job_name <<job_name>>
    ```
    - **Populate the YAML dynamically as follows:**
        - `<<beam_script_name>>`: Use the `name` from the unified JSON, ending with `_beam.py`. (e.g., `m_Emp_Dept_FF_beam.py`).
        - `<<project_id>>`, `<<region>>`, `<<bucket_name>>`, `<<bigquery_dataset>>`: Use the exact values from the provided GCP Configuration.
        - `<<dynamic_input_args>>`: For each source in the `SOURCE_LIST`, add a line like `--input_sourcename gs://<<bucket_name>>/input/sourcename.csv \\`.
        - `<<output_table_name>>`: Use the `name` from the unified JSON as the table name (e.g., `m_Emp_Dept_FF`).
        - `<<job_name>>`: Create a job name from the unified JSON name, using lowercase and hyphens (e.g., `m-emp-dept-ff`).

    **FINAL OUTPUT FORMAT:**
    Your response MUST be a single JSON object with two keys: "beam_script" and "yaml_config". Do not add any conversational text.
    Example:
    ```json
    {{
        "beam_script": "```python\\n# Your Beam script here\\n```",
        "yaml_config": "```yaml\\n# Your YAML config here\\n```"
    }}
    ```
    Here is the example Apache Beam Python script for structural and stylistic reference:
    ```python
    {EXAMPLE_BEAM_SCRIPT_CONTENT}
    ```
    """
)

# --- Helper Functions ---
async def _invoke_agent(request_data: AgentRequest) -> str:
    """Internal function to run the agent and get a response."""
    session_service = InMemorySessionService()
    runner = Runner(app_name='adf_to_beam_converter', agent=json_to_beam_agent, session_service=session_service)
    session_id = f"session-{os.urandom(16).hex()}"
    await session_service.create_session(app_name='adf_to_beam_converter', user_id='api_user', session_id=session_id)
    prompt_input = f"Unified Pipeline JSON:\n```json\n{json.dumps(request_data.unified_json, indent=2)}\n```\n\nGCP Configuration:\n```json\n{json.dumps(request_data.gcp_config.model_dump(), indent=2)}\n```"
    events = runner.run_async(user_id='api_user', session_id=session_id, new_message=Content(parts=[Part(text=prompt_input)], role='user'))
    response_text = ""
    async for event in events:
        if event.is_final_response() and event.content and event.content.parts:
            response_text = event.content.parts[0].text
            break
    if not response_text:
        raise ValueError("Agent execution failed to return a valid response.")
    return response_text

def _parse_agent_response(response_text: str) -> tuple[str, str]:
    """Internal function to parse and clean the agent's JSON response."""
    try:
        clean_text = re.sub(r'```json\s*|\s*```', '', response_text).strip()
        parsed_response = json.loads(clean_text)
        
        beam_script = parsed_response.get("beam_script", "").strip()
        yaml_config = parsed_response.get("yaml_config", "").strip()

        if not beam_script or not yaml_config:
            raise ValueError("Agent response is missing 'beam_script' or 'yaml_config' keys.")

        def clean_content(content: str, lang: str) -> str:
            if content.startswith(f"```{lang}"):
                content = content[len(f"```{lang}"):]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()
            if content.startswith(f"{lang}\n"):
                content = content[len(f"{lang}\n"):].lstrip()
            return content

        beam_script = clean_content(beam_script, "python")
        yaml_config = clean_content(yaml_config, "yaml")

        return beam_script, yaml_config
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"Failed to parse agent's JSON response. Reason: {e}.")

# --- Main Public Function ---
async def generate_beam_and_yaml(unified_json: dict, gcp_config: dict) -> dict:
    """
    The main entry point to trigger the agent logic.
    Takes unified JSON and GCP config, returns generated script and YAML.
    """
    try:
        # Validate input data using Pydantic models
        request_data = AgentRequest(
            unified_json=unified_json,
            gcp_config=GCPConfig(**gcp_config)
        )
        
        # Invoke the agent and get the raw response
        agent_response_text = await _invoke_agent(request_data)
        
        # Parse the response to get clean script and yaml
        beam_script, yaml_config = _parse_agent_response(agent_response_text)
        
        return {"beam_script": beam_script, "yaml_config": yaml_config}
    except Exception as e:
        print("!!! AGENT LOGIC INTERNAL ERROR !!!")
        traceback.print_exc()
        # Re-raise the exception to be caught by the API router
        raise e
    
def get_beam_update_prompt(original_beam_code: str, review_json: str, beam_script_filename: str) -> str:
    return f"""
    You are a Python code refactoring agent.
    Your task is to update the following Apache Beam script ({beam_script_filename}) by applying all modifications described in the provided review JSON.

    **Original Beam Script:**
    {original_beam_code}

    **Review JSON:**
    {review_json}

    Apply every modification listed in the 'modifications' array of the review JSON.
    Return ONLY the updated Python code, with all fixes applied. Do not include any explanations or markdown formatting.
    """
    

async def apply_review_modifications(original_beam_path: str, review_json_path: str) -> str:
    """
    Uses the agent to update the Beam script by applying all modifications from the review JSON.
    Returns the updated Beam script as a string.
    """
    with open(original_beam_path, "r", encoding="utf-8") as f:
        original_beam_code = f.read()
    with open(review_json_path, "r", encoding="utf-8") as f:
        review_json = f.read()
    beam_script_filename = os.path.basename(original_beam_path)

    prompt = get_beam_update_prompt(original_beam_code, review_json, beam_script_filename)
    model = GenerativeModel("gemini-2.5-pro")
    response = model.generate_content(prompt)
    updated_code = getattr(response, "text", "") or str(response)
    return updated_code.strip()




# import os
# import json
# import re
# import traceback
# from pydantic import BaseModel
# from google.adk.agents import Agent
# from google.adk.runners import Runner
# from google.adk.sessions import InMemorySessionService
# from google.genai.types import Content, Part
# from dotenv import load_dotenv
# from google.cloud import storage
# from google.oauth2 import service_account
# import vertexai
# from vertexai.preview.generative_models import GenerativeModel

# # Load .env
# dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
# load_dotenv(dotenv_path=dotenv_path)

# def get_service_account_info(migration_folder):
#     config_dir = os.path.join(migration_folder, "configuration")
#     service_account_path = os.path.join(config_dir, "service_account.json")
#     if os.path.exists(service_account_path):
#         with open(service_account_path, "r") as f:
#             return json.load(f)
#     raise FileNotFoundError("service_account.json not found in configuration folder.")

# def get_bucket_name(migration_folder):
#     config_path = os.path.join(migration_folder, "configuration", "config.json")
#     if os.path.exists(config_path):
#         with open(config_path, "r") as f:
#             config = json.load(f)
#         return config.get("bucket_name")
#     raise FileNotFoundError("config.json not found in configuration folder.")

# def get_csv_file_name_from_arm(unified_json):
#     sources = unified_json.get("properties", {}).get("typeProperties", {}).get("sources", [])
#     for src in sources:
#         csv_file = src.get("partitionFileNames", [None])[0]
#         if csv_file:
#             return csv_file
#     return None

# def get_csv_header_from_gcs(migration_folder, unified_json):
#     # Get service account info and bucket name
#     service_account_info = get_service_account_info(migration_folder)
#     bucket_name = get_bucket_name(migration_folder)
#     csv_file_name = get_csv_file_name_from_arm(unified_json)
#     if not csv_file_name:
#         return []

#     credentials = service_account.Credentials.from_service_account_info(service_account_info)
#     client = storage.Client(credentials=credentials, project=service_account_info["project_id"])
#     bucket = client.bucket(bucket_name)

#     # Search for the CSV file in all folders in the bucket
#     blobs = bucket.list_blobs()
#     for blob in blobs:
#         if blob.name.lower().endswith(csv_file_name.lower()):
#             # Found the matching CSV file
#             header_line = blob.download_as_text().splitlines()[0]
#             return header_line.split(",")
#     return []

# try:
#     with open('example.py', 'r') as f:
#         EXAMPLE_BEAM_SCRIPT_CONTENT = f.read()
# except FileNotFoundError:
#     EXAMPLE_BEAM_SCRIPT_CONTENT = "# Example Beam script not found."

# class GCPConfig(BaseModel):
#     project_id: str
#     region: str
#     bucket_name: str
#     bigquery_dataset: str

# class AgentRequest(BaseModel):
#     unified_json: dict
#     gcp_config: GCPConfig
#     csv_columns: list = []

# json_to_beam_agent = Agent(
#     model='gemini-2.5-pro-preview-05-06',
#     name='json_to_beam_agent',
#     description='An expert agent that converts a unified ETL JSON and GCP config into a Beam script and a fully populated Cloud Build YAML.',
#     instruction=f"""
#     You are an expert Google Cloud data engineer. Your task is to convert a unified ETL pipeline JSON into a functional Apache Beam script and generate a ready-to-use `cloudbuild.yaml` file using the provided GCP configuration.

#     **CONTEXT YOU WILL RECEIVE:**
#     1.  **Unified Pipeline JSON:** A JSON object describing the ETL pipeline's sources, targets, and transformations.
#     2.  **GCP Configuration:** A JSON object with specific values for `project_id`, `region`, `bucket_name`, and `bigquery_dataset`.
#     3.  **CSV Columns:** A list of column names extracted from the referenced CSV file.

#     **YOUR TASKS:**

#     **TASK 1: GENERATE THE APACHE BEAM SCRIPT**
#     - The script must be a complete, runnable Python file.
#     - Use `argparse` to define command-line arguments for **ALL** sources found in the `SOURCE_LIST`. For a source named "employees_data", create an argument `--input_employees_data`.
#     - For each source: if the type is 'csv' or 'flat file', read from GCS using `beam.io.ReadFromText`; if the type is 'table' or any oracle_src/database, read from BigQuery using `beam.io.ReadFromBigQuery`. Do not generate any JDBC or database connection code.
#     - The final output sink **MUST** be `beam.io.WriteToBigQuery`. Create an `--output_table` argument for the BigQuery table specification.
#     - **IMPORTANT:** Always set `write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND` in `WriteToBigQuery` so that data is appended, not overwritten.
#     - Translate the logic from the `TRANSFORMATIONS` list into Beam PTransforms (`Map`, `Filter`, `CoGroupByKey`, etc.).
#     - **CRITICAL JOIN RULE:** When implementing a join using `beam.CoGroupByKey`, you **MUST** first prepare each input PCollection. Use a `beam.Map` transform to convert each element into a 2-element `(key, value)` tuple. The `key` is the column to join on, and the `value` is the **entire dictionary** for that row`.
#     - You MUST use the provided CSV Columns for both parsing each line and for the BigQuery schema. Do NOT default to a single raw_data column under ANY circumstances. If the CSV Columns are present, always use them for both parsing and schema.
#     - Reference the provided `example.py` for style, structure, and best practices.

#     **TASK 2: GENERATE THE `cloudbuild.yaml` FILE**
#     - Use the provided `GCP Configuration` to populate the YAML file. **DO NOT use placeholders like 'project-id'.**
#     - The YAML must follow this exact structure:
#     ```yaml
#     steps:
#     - name: 'python:3.9'
#       entrypoint: 'bash'
#       args:
#       - '-c'
#       - |
#         pip install 'apache-beam[gcp]==2.66.0' && \\
#         python <<beam_script_name>> \\
#             --runner DataflowRunner \\
#             --project <<project_id>> \\
#             --region <<region>> \\
#             --temp_location gs://<<bucket_name>>/temp \\
#             --staging_location gs://<<bucket_name>>/staging \\
#             <<dynamic_input_args>> \\
#             --output_table <<project_id>>:<<bigquery_dataset>>.<<output_table_name>> \\
#             --job_name <<job_name>>
#     ```
#     - **Populate the YAML dynamically as follows:**
#         - `<<beam_script_name>>`: Use the `name` from the unified JSON, ending with `_beam.py`. (e.g., `m_Emp_Dept_FF_beam.py`).
#         - `<<project_id>>`, `<<region>>`, `<<bucket_name>>`, `<<bigquery_dataset>>`: Use the exact values from the provided GCP Configuration.
#         - `<<dynamic_input_args>>`: For each source in the `SOURCE_LIST`, add a line like `--input_sourcename gs://<<bucket_name>>/input/sourcename.csv \\`.
#         - `<<output_table_name>>`: Use the `name` from the unified JSON as the table name (e.g., `m_Emp_Dept_FF`).
#         - `<<job_name>>`: Create a job name from the unified JSON name, using lowercase and hyphens (e.g., `m-emp-dept-ff`).

#     **FINAL OUTPUT FORMAT:**
#     Your response MUST be a single JSON object with two keys: "beam_script" and "yaml_config". Do not add any conversational text.
#     Example:
#     ```json
#     {{
#         "beam_script": "```python\\n# Your Beam script here\\n```",
#         "yaml_config": "```yaml\\n# Your YAML config here\\n```"
#     }}
#     ```
#     Here is the example Apache Beam Python script for structural and stylistic reference:
#     ```python
#     {EXAMPLE_BEAM_SCRIPT_CONTENT}
#     ```
#     """
# )

# async def _invoke_agent(request_data: AgentRequest) -> str:
#     session_service = InMemorySessionService()
#     runner = Runner(app_name='adf_to_beam_converter', agent=json_to_beam_agent, session_service=session_service)
#     session_id = f"session-{os.urandom(16).hex()}"
#     await session_service.create_session(app_name='adf_to_beam_converter', user_id='api_user', session_id=session_id)
#     prompt_input = f"Unified Pipeline JSON:\n```json\n{json.dumps(request_data.unified_json, indent=2)}\n```\n\nGCP Configuration:\n```json\n{json.dumps(request_data.gcp_config.model_dump(), indent=2)}\n```\n\nCSV Columns:\n{json.dumps(request_data.csv_columns)}"
#     events = runner.run_async(user_id='api_user', session_id=session_id, new_message=Content(parts=[Part(text=prompt_input)], role='user'))
#     response_text = ""
#     async for event in events:
#         if event.is_final_response() and event.content and event.content.parts:
#             response_text = event.content.parts[0].text
#             break
#     if not response_text:
#         raise ValueError("Agent execution failed to return a valid response.")
#     return response_text

# def _parse_agent_response(response_text: str) -> tuple[str, str]:
#     try:
#         clean_text = re.sub(r'```json\s*|\s*```', '', response_text).strip()
#         parsed_response = json.loads(clean_text)
#         beam_script = parsed_response.get("beam_script", "").strip()
#         yaml_config = parsed_response.get("yaml_config", "").strip()
#         if not beam_script or not yaml_config:
#             raise ValueError("Agent response is missing 'beam_script' or 'yaml_config' keys.")

#         def clean_content(content: str, lang: str) -> str:
#             if content.startswith(f"```{lang}"):
#                 content = content[len(f"```{lang}"):]
#             if content.endswith("```"):
#                 content = content[:-3]
#             content = content.strip()
#             if content.startswith(f"{lang}\n"):
#                 content = content[len(f"{lang}\n"):].lstrip()
#             return content

#         beam_script = clean_content(beam_script, "python")
#         yaml_config = clean_content(yaml_config, "yaml")
#         return beam_script, yaml_config
#     except (json.JSONDecodeError, ValueError) as e:
#         raise ValueError(f"Failed to parse agent's JSON response. Reason: {e}.")

# async def generate_beam_and_yaml(unified_json: dict, gcp_config: dict, migration_folder: str = None) -> dict:
#     try:
#         # Extract CSV columns from GCS using service account and config
#         csv_columns = []
#         if migration_folder:
#             csv_columns = get_csv_header_from_gcs(migration_folder, unified_json)
#         request_data = AgentRequest(
#             unified_json=unified_json,
#             gcp_config=GCPConfig(**gcp_config),
#             csv_columns=csv_columns
#         )
#         agent_response_text = await _invoke_agent(request_data)
#         beam_script, yaml_config = _parse_agent_response(agent_response_text)
#         return {"beam_script": beam_script, "yaml_config": yaml_config}
#     except Exception as e:
#         print("!!! AGENT LOGIC INTERNAL ERROR !!!")
#         traceback.print_exc()
#         raise e

# def get_beam_update_prompt(original_beam_code: str, review_json: str, beam_script_filename: str) -> str:
#     return f"""
#     You are a Python code refactoring agent.
#     Your task is to update the following Apache Beam script ({beam_script_filename}) by applying all modifications described in the provided review JSON.

#     **Original Beam Script:**
#     {original_beam_code}

#     **Review JSON:**
#     {review_json}

#     Apply every modification listed in the 'modifications' array of the review JSON.
#     Return ONLY the updated Python code, with all fixes applied. Do not include any explanations or markdown formatting.
#     """

# async def apply_review_modifications(original_beam_path: str, review_json_path: str) -> str:
#     with open(original_beam_path, "r", encoding="utf-8") as f:
#         original_beam_code = f.read()
#     with open(review_json_path, "r", encoding="utf-8") as f:
#         review_json = f.read()
#     beam_script_filename = os.path.basename(original_beam_path)
#     prompt = get_beam_update_prompt(original_beam_code, review_json, beam_script_filename)
#     model = GenerativeModel("gemini-2.5-pro")
#     response = model.generate_content(prompt)
#     updated_code = getattr(response, "text", "") or str(response)
#     return updated_code.strip()






