import json
import logging
import os
import re
import asyncio
from typing import Optional
from dotenv import load_dotenv
from google.oauth2 import service_account
import vertexai
from vertexai.generative_models import GenerativeModel

# --- Environment Setup ---
BASE_DIR = os.path.dirname(__file__)
dotenv_path = os.path.join(BASE_DIR, ".env")
load_dotenv(dotenv_path=dotenv_path)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("review_agent")

google_credentials = os.getenv("GOOGLE_CREDENTIALS")
if not google_credentials:
    logger.error("GOOGLE_CREDENTIALS environment variable is not set.")
    raise RuntimeError("GOOGLE_CREDENTIALS environment variable is required.")

SERVICE_ACCOUNT_INFO = json.loads(google_credentials)
credentials = service_account.Credentials.from_service_account_info(SERVICE_ACCOUNT_INFO)
project_id = SERVICE_ACCOUNT_INFO.get("project_id")
vertexai.init(project=project_id, credentials=credentials)

# --- Utility Functions ---
def _extract_json_from_text(text: str) -> Optional[str]:
    """Extracts the first valid JSON object from a string."""
    start = None
    brace_count = 0
    for i, ch in enumerate(text):
        if ch == "{":
            if start is None:
                start = i
            brace_count += 1
        elif ch == "}":
            brace_count -= 1
            if brace_count == 0 and start is not None:
                return text[start : i + 1]
    return None

def _safe_load_json(s: str):
    try:
        return json.loads(s)
    except json.JSONDecodeError as e:
        logger.debug("JSON decode error: %s\nInput snippet: %.200s", e, s)
        raise

# --- Main Review Logic ---
def generate_review_sync(unified_json: str, generated_beam_code: str, beam_script_filename: str) -> str:
    model = GenerativeModel("gemini-2.5-pro")
    instruction = f"""
    You are a code review agent. Compare the provided Beam script and pipeline JSON for correctness and best practices.
    
    - Output sink must be BigQuery with WRITE_APPEND.
    - If the script has a docstring or comment block at the top, suggest removing it.
    - For each issue, provide a modification with line numbers, original code, suggested code, and justification.
    - If no issues, status is 'Approved' and modifications is empty.

    **Provided JSON Specification:**
    ```json
    {unified_json}
    ```

    **Provided Beam Script (`{beam_script_filename}`):**
    ```python
    {generated_beam_code}
    ```

    **Expected Output:**
    Your output must be a single, raw JSON object which lists all the required and necessary suggestions one below the other with assigning s_no to each suggestion.
    These suggestions can be code modifications, improvements, fixes, omissions or any other relevant changes.
    Do not wrap it in markdown.
    ```json
    {{

        "review_summary": "A concise, high-level summary and an overall assessment of the code's quality and adherence to the specification.",
        "status": "<Approved or Needs Revision>",
        "file_path": "The filename of the script being reviewed.",
        "modifications": [
            {{
                "s_no": 1,
                "line_number_start": "<integer: The starting line number of the code block to be changed.>",
                "line_number_end": "<integer: The ending line number of the code block to be changed.>",
                "original_code": "<string: The exact block of existing code that needs to be replaced.>",
                "suggested_code": "<string: The new block of code that should replace the original.>",
                "justification": "<string: A clear and technical explanation for why the modification is required, referencing specific best practices or specification requirements.>"
            }}
        ]
    }}
    ```
    **IMPORTANT:** Return ONLY the JSON object, with no additional text, explanations, or formatting. Your response must start with `{{` and end with `}}`.
    """
    try:
        response = model.generate_content(instruction)
        model_text = getattr(response, "text", "") or str(response)
        model_text = model_text.strip()
        json_candidate = _extract_json_from_text(model_text)
        if not json_candidate:
            match = re.search(r"\{(?:.|\n)*\}", model_text, re.DOTALL)
            json_candidate = match.group(0) if match else None
        if not json_candidate:
            logger.error("Model response did not contain a parsable JSON object.")
            raise ValueError("LLM response did not contain a valid JSON object.")
        parsed = _safe_load_json(json_candidate)
        return json.dumps(parsed, ensure_ascii=False, indent=2)
    except Exception as exc:
        logger.error(
        "Vertex AI authentication or permission error: This issue is likely caused by missing or insufficient service account credentials for Vertex AI. "
        "Check that GOOGLE_CREDENTIALS is set to a valid service account JSON with Vertex AI User permissions and access to the correct project."
        )
        logger.exception("Failed to generate or parse review: %s", exc)
        raise ValueError("Failed to generate a valid JSON review from the code review model.") from exc

async def generate_review(unified_json: str, generated_beam_code: str, beam_script_filename: str) -> str:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None,
        generate_review_sync,
        unified_json,
        generated_beam_code,
        beam_script_filename
    )


