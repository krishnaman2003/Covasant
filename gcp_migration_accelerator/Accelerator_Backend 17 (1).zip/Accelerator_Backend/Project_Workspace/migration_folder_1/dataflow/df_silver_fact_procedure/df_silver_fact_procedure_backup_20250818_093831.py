import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# This Beam pipeline reads data from a GCS file, assumes a simple schema,
# and writes it to a BigQuery table.
# The 'sort' transformation from the original JSON is intentionally not implemented.
# Global sorting is an anti-pattern in large-scale parallel processing like Beam.
# For efficient ordering, it is recommended to load the data into BigQuery and
# use BigQuery's clustering capabilities on the relevant columns (e.g., 'ProcedureCode').

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""

    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='GCS path for the input CSV file for the factprocedure source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table specifier in format PROJECT:DATASET.TABLE.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery table schema based on the source definition
    table_schema = {
        'fields': [
            {'name': 'ProcedureID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureCode', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureDesc', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureDateTime', 'type': 'STRING', 'mode': 'NULLABLE'}
        ]
    }

    csv_header_list = [
        'ProcedureID', 'PatientID', 'EncounterID', 'ProviderID',
        'FacilityID', 'LocationID', 'ProcedureCode', 'ProcedureDesc',
        'ProcedureDateTime'
    ]

    def parse_csv_line(line):
        """Parses a single CSV line into a dictionary."""
        values = [v.strip() for v in line.split(',')]
        if len(values) == len(csv_header_list):
            return dict(zip(csv_header_list, values))
        else:
            # Log or handle malformed rows as needed
            return None

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from the source GCS file
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_factprocedure, skip_header_lines=1)

        # 2. Parse CSV lines and filter out any malformed rows
        parsed_data = (
            lines
            | 'ParseToDict' >> beam.Map(parse_csv_line)
            | 'FilterNone' >> beam.Filter(lambda x: x is not None)
        )

        # 3. Write records to the target BigQuery table
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()