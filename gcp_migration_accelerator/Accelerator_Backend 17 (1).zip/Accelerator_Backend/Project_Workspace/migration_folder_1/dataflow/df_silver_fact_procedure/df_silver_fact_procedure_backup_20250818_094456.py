# AUTO-GENERATED FILE: df_silver_fact_procedure_beam.py
#
# An Apache Beam pipeline to process data from GCS and load it into BigQuery.

import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

def parse_csv(element):
    """Parses a single CSV line into a dictionary.

    Args:
        element (str): A string representing a line from a CSV file.

    Returns:
        dict: A dictionary representing the row of data, or None if parsing fails.
    """
    fields = [
        'ProcedureID',
        'PatientID',
        'EncounterID',
        'ProviderID',
        'FacilityID',
        'LocationID',
        'ProcedureCode',
        'ProcedureDesc',
        'ProcedureDateTime'
    ]
    try:
        values = element.split(',')
        if len(values) == len(fields):
            return dict(zip(fields, values))
        else:
            logging.warning(f'Skipping malformed row: {element}')
            return None
    except Exception as e:
        logging.error(f'Error parsing row: {element} | Error: {e}')
        return None

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='Input GCS file path for the factprocedure source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery table schema
    table_schema = {
        'fields': [
            {'name': 'ProcedureID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureCode', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureDesc', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # Read from the source file in GCS
        factprocedure = (
            p
            | 'ReadFactProcedure' >> beam.io.ReadFromText(
                known_args.input_factprocedure, skip_header_lines=1)
            | 'ParseFactProcedure' >> beam.Map(parse_csv)
            | 'FilterNullFactProcedure' >> beam.Filter(lambda x: x is not None)
        )

        # NOTE: The 'sort' transformation from the source JSON is omitted.
        # Global sorting in a distributed pipeline like Beam is an anti-pattern
        # as it forces all data onto a single worker, creating a bottleneck.
        # It's recommended to perform sorting in the destination database (e.g., BigQuery)
        # using an ORDER BY clause in a view or query.
        # Therefore, we pass the data directly to the sink.
        processed_data = factprocedure

        # Write the results to BigQuery
        processed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()