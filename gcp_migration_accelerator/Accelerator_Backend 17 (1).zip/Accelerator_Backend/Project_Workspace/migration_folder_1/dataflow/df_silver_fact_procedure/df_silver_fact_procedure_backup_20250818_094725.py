# AUTO-GENERATED FILE: df_silver_fact_procedure_beam.py
#
# An Apache Beam pipeline to process data from GCS and load it into BigQuery.

import argparse
import logging
import re
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Helper function to parse CSV lines
def parse_csv(element, columns):
    """Parses a single CSV line into a dictionary."""
    # A simple split, assuming no commas within fields. 
    # For more complex CSVs, consider using the 'csv' module.
    try:
        values = element.split(',')
        if len(values) == len(columns):
            return dict(zip(columns, values))
        else:
            # Log or discard malformed rows
            logging.warning(f"Skipping malformed row: {element}")
            return None
    except Exception as e:
        logging.error(f"Error parsing row: {element} | Exception: {e}")
        return None

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""

    parser = argparse.ArgumentParser()
    # Add arguments for all sources found in the JSON
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='Input GCS path for the factprocedure source CSV file.')
    
    # Add argument for the output BigQuery table
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery schema for the output table
    table_schema = {
        'fields': [
            {'name': 'ProcedureID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureCode', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureDesc', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }
    
    # The column order must match the CSV file
    csv_columns = [
        'ProcedureID',
        'PatientID',
        'EncounterID',
        'ProviderID',
        'FacilityID',
        'LocationID',
        'ProcedureCode',
        'ProcedureDesc',
        'ProcedureDateTime'
    ]

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from the source GCS file
        lines = p | 'ReadFactProcedure' >> beam.io.ReadFromText(
            known_args.input_factprocedure, skip_header_lines=1)

        # 2. Parse CSV and convert to dictionaries
        parsed_data = (
            lines 
            | 'ParseToDict' >> beam.Map(parse_csv, columns=csv_columns)
            | 'FilterNone' >> beam.Filter(lambda x: x is not None)
        )

        # NOTE: The 'sort' transformation from the original JSON is omitted.
        # A global sort on an entire PCollection is an anti-pattern in Beam/Dataflow
        # as it forces all data onto a single worker, creating a significant bottleneck.
        # Sorting is best performed on the final data within the sink system (e.g., BigQuery using ORDER BY).

        # 3. Write the results to the target BigQuery table
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()