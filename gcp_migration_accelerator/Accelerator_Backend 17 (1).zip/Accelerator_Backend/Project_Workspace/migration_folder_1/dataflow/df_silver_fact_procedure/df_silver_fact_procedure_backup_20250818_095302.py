import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Define the schema for the BigQuery table based on the unified JSON.
SCHEMA = {
    'fields': [
        {'name': 'ProcedureID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureCode', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureDesc', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
    ]
}

# Extract headers for parsing
HEADERS = [field['name'] for field in SCHEMA['fields']]

def parse_csv(csv_line, headers):
    """
    Parses a single CSV line into a dictionary.
    This is a simple parser assuming no commas within quoted fields.
    Args:
        csv_line: A string representing a line from a CSV file.
        headers: A list of strings for the column headers.
    Returns:
        A dictionary representing the row, or None on failure.
    """
    try:
        values = [v.strip() for v in csv_line.split(',')]
        if len(values) == len(headers):
            return dict(zip(headers, values))
        else:
            logging.warning(f"Row has {len(values)} columns, header has {len(headers)}. Skipping row: {csv_line}")
            return None
    except Exception as e:
        logging.error(f"Error parsing line '{csv_line}': {e}")
        return None

def run(argv=None):
    """The main function which creates and runs the pipeline."""
    parser = argparse.ArgumentParser()

    # Define command-line arguments for sources
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='Input GCS path for the factprocedure CSV file.')

    # Define command-line argument for the output BigQuery table
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to (e.g., project:dataset.table).')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read the source data from a GCS file.
        #    Assuming the file is CSV and the first line is a header.
        lines = p | 'ReadSourceFile' >> beam.io.ReadFromText(
            known_args.input_factprocedure, skip_header_lines=1)

        # 2. Parse each CSV line into a dictionary.
        parsed_data = (
            lines
            | 'ParseCSV' >> beam.Map(lambda line: parse_csv(line, HEADERS))
            | 'FilterFailedParses' >> beam.Filter(lambda x: x is not None)
        )

        # NOTE: The 'sort' transformation from the JSON is omitted. Global sorts are
        # computationally expensive in distributed systems like Beam/Dataflow
        # and are often not required for loading data into a sink like BigQuery,
        # where sorting can be handled efficiently at query time.

        # 3. Write the processed data to the target BigQuery table.
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=SCHEMA,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()