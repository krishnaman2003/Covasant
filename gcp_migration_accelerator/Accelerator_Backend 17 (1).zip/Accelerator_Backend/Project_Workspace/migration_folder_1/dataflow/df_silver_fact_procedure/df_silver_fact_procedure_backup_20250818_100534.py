import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Define the schema for the output BigQuery table
TABLE_SCHEMA = (
    'ProcedureID:STRING, ' 
    'PatientID:STRING, ' 
    'EncounterID:STRING, ' 
    'ProviderID:STRING, ' 
    'FacilityID:STRING, ' 
    'LocationID:STRING, ' 
    'ProcedureCode:STRING, ' 
    'ProcedureDesc:STRING, ' 
    'ProcedureDateTime:STRING'
)

# Define the column headers for parsing the CSV
CSV_HEADERS = [
    'ProcedureID', 'PatientID', 'EncounterID', 'ProviderID', 'FacilityID',
    'LocationID', 'ProcedureCode', 'ProcedureDesc', 'ProcedureDateTime'
]

def parse_csv_to_dict(csv_line):
    """Parses a single CSV line into a dictionary."""
    values = csv_line.split(',')
    # Basic validation to ensure the row has the expected number of columns
    if len(values) == len(CSV_HEADERS):
        return dict(zip(CSV_HEADERS, values))
    else:
        # Log or handle malformed rows as needed
        return None

def run(argv=None):
    """Main entry point; defines and runs the pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='GCS path for the input factprocedure CSV file.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read the source file from GCS
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_factprocedure, skip_header_lines=1)

        # 2. Parse CSV lines into dictionaries
        parsed_data = lines | 'ParseCSV' >> beam.Map(parse_csv_to_dict)

        # 3. Filter out any rows that failed parsing (are None)
        valid_data = parsed_data | 'FilterMalformedRows' >> beam.Filter(lambda x: x is not None)
        
        # Note: The 'sort' transformation from the JSON is not implemented as a separate PTransform.
        # Global sorting in Beam is a resource-intensive operation. It's often more efficient to
        # load data into BigQuery and use clustering on the 'ProcedureCode' column for fast, sorted queries.

        # 4. Write the results to BigQuery
        valid_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=TABLE_SCHEMA,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()