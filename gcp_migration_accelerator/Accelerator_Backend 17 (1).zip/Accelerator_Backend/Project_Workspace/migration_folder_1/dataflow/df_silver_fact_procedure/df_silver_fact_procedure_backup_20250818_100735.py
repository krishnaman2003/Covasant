# AUTO-GENERATED FILE. DO NOT EDIT.
import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Define the schema for the output BigQuery table
SCHEMA = (
    'ProcedureID:STRING, PatientID:STRING, EncounterID:STRING, ProviderID:STRING, ' 
    'FacilityID:STRING, LocationID:STRING, ProcedureCode:STRING, ProcedureDesc:STRING, '
    'ProcedureDateTime:STRING'
)

# Define the headers in the expected order of the CSV columns
CSV_HEADERS = [
    'ProcedureID', 'PatientID', 'EncounterID', 'ProviderID', 'FacilityID',
    'LocationID', 'ProcedureCode', 'ProcedureDesc', 'ProcedureDateTime'
]

def parse_csv(element):
    """Parses a single CSV line into a dictionary."""
    try:
        values = element.split(',')
        if len(values) == len(CSV_HEADERS):
            return dict(zip(CSV_HEADERS, values))
    except Exception as e:
        logging.error(f'Error parsing element {element}: {e}')
    return None

def run(argv=None):
    """Main entry point; defines and runs the pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='Input file path for the factprocedure source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from the source(s)
        # Source: factprocedure (CSV from GCS)
        factprocedure_data = p | 'ReadFactprocedureData' >> beam.io.ReadFromText(
            known_args.input_factprocedure, skip_header_lines=1
        )

        # 2. Apply transformations
        # Parse CSV lines into dictionaries
        parsed_data = factprocedure_data | 'ParseFactprocedureCSV' >> beam.Map(parse_csv)

        # Filter out any rows that failed parsing
        valid_data = parsed_data | 'FilterInvalidRows' >> beam.Filter(lambda x: x is not None)

        # Note: The original pipeline specified a 'sort' transformation.
        # Global sorting is a very expensive and often anti-pattern operation in a distributed
        # processing framework like Apache Beam. It's more efficient to load the data into
        # BigQuery and perform sorting at query time or by using clustering on the table.
        # Therefore, the explicit sort step is omitted from this Beam implementation.
        final_data = valid_data

        # 3. Write to the target
        # Target: silverFactProcedure (BigQuery)
        final_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=SCHEMA,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()