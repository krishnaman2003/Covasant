# AUTO-GENERATED BEAM SCRIPT
#
# Pipeline Name: df_silver_fact_procedure
#
# This script reads data from a GCS source, processes it, and writes the result to a BigQuery table.

import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Define the schema for the output BigQuery table
SCHEMA = (
    'ProcedureID:STRING, '
    'PatientID:STRING, '
    'EncounterID:STRING, '
    'ProviderID:STRING, '
    'FacilityID:STRING, '
    'LocationID:STRING, '
    'ProcedureCode:STRING, '
    'ProcedureDesc:STRING, '
    'ProcedureDateTime:STRING'
)

# Define the headers for the input CSV file
CSV_HEADERS = [
    'ProcedureID',
    'PatientID',
    'EncounterID',
    'ProviderID',
    'FacilityID',
    'LocationID',
    'ProcedureCode',
    'ProcedureDesc',
    'ProcedureDateTime'
]

def parse_csv_line(line):
    """Parses a single CSV line and returns a dictionary."""
    try:
        # Simple CSV split, assuming no commas within fields
        values = line.split(',')
        if len(values) == len(CSV_HEADERS):
            return dict(zip(CSV_HEADERS, values))
        else:
            # Log a warning if the number of columns does not match the header
            logging.warning(f'Skipping malformed line: {line}')
            return None
    except Exception as e:
        logging.error(f'Error parsing line: {line} - {e}')
        return None

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='GCS path for the input factprocedure CSV file.'
    )
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='BigQuery table specifier for the output data, e.g., project_id:dataset.table'
    )

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from GCS
        lines = p | 'ReadFactProcedure' >> beam.io.ReadFromText(
            known_args.input_factprocedure, skip_header_lines=1
        )

        # 2. Parse CSV and convert to dictionaries
        parsed_data = lines | 'ParseCSV' >> beam.Map(parse_csv_line)

        # 3. Filter out any rows that failed parsing
        valid_data = parsed_data | 'FilterValid' >> beam.Filter(lambda x: x is not None)

        # NOTE: The original pipeline specified a sort on 'ProcedureCode'.
        # In a distributed, parallel system like Apache Beam, sorting a large PCollection
        # is a computationally expensive operation and often not performed within the ETL pipeline itself.
        # Data is typically loaded into the warehouse (BigQuery) and sorted there if needed.
        # Therefore, the sort transformation is acknowledged but not implemented here.
        processed_data = valid_data

        # 4. Write to BigQuery
        processed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=SCHEMA,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()