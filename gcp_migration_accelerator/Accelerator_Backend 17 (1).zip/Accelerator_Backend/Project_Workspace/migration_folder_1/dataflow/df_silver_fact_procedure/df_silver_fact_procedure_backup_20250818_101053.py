# AUTO-GENERATED APACHE BEAM SCRIPT
#
# Pipeline Name: df_silver_fact_procedure
#
# This script reads data from a GCS source, performs transformations,
# and writes the results to a BigQuery table.

import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Define the schema for the output BigQuery table
TABLE_SCHEMA = {
    'fields': [
        {'name': 'ProcedureID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureCode', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureDesc', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
    ]
}

CSV_HEADERS = [
    'ProcedureID', 'PatientID', 'EncounterID', 'ProviderID', 'FacilityID',
    'LocationID', 'ProcedureCode', 'ProcedureDesc', 'ProcedureDateTime'
]

class ParseCsvToDict(beam.DoFn):
    """Parses a CSV line into a dictionary.
    
    Assumes a comma-separated line and maps columns to a predefined
    list of headers.
    """
    def process(self, element):
        try:
            values = element.split(',')
            if len(values) == len(CSV_HEADERS):
                row_dict = dict(zip(CSV_HEADERS, values))
                yield row_dict
            else:
                logging.warning(f'Skipping malformed row: {element}')
        except Exception as e:
            logging.error(f'Error parsing row: {element} - {e}')

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='Input GCS file path for the factprocedure source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from the source(s)
        factprocedure_data = (
            p
            | 'ReadFactProcedureCSV' >> beam.io.ReadFromText(
                  known_args.input_factprocedure, skip_header_lines=1)
            | 'ParseFactProcedure' >> beam.ParDo(ParseCsvToDict())
        )

        # 2. Transformations
        # The JSON specified a sort, which is a costly operation in distributed systems
        # and often not necessary for a simple load. Omitting for efficiency.
        # If sorting is critical for business logic (e.g., ranking), it would be implemented here.
        output_data = factprocedure_data

        # 3. Write to the target BigQuery table
        output_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=TABLE_SCHEMA,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()