import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# The schema is derived from the 'TRANSFORMATIONS' section of the pipeline JSON.
TABLE_SCHEMA = {
    'fields': [
        {'name': 'ProcedureID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureCode', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureDesc', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
    ]
}

# Column headers must match the order in the CSV file and schema.
COLUMN_HEADERS = [field['name'] for field in TABLE_SCHEMA['fields']]

def parse_csv_line(csv_line):
    """
    Parses a single CSV line and converts it into a dictionary.
    This is a simple parser assuming no commas within quoted fields.
    """
    values = csv_line.split(',')
    row = dict(zip(COLUMN_HEADERS, values))
    return row

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='GCS path for the input factprocedure CSV file.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table specification (project:dataset.table).')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # Note: The 'sort' transformation from the original JSON is intentionally
        # omitted. Performing a global sort on a distributed dataset is an
        # expensive anti-pattern in Beam and often unnecessary, as databases
        # like BigQuery handle data organization and clustering internally.

        # 1. Read source data from GCS.
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_factprocedure, skip_header_lines=1)

        # 2. Transform each line into a dictionary.
        parsed_data = lines | 'ParseCSV' >> beam.Map(parse_csv_line)

        # 3. Write the results to the target BigQuery table.
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=TABLE_SCHEMA,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()