import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Define the BigQuery schema for the output table.
TABLE_SCHEMA = {
    'fields': [
        {'name': 'ProcedureID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureCode', 'type': 'STRING', 'mode': 'NULLABLE'},
        {'name': 'ProcedureDesc', 'type': 'STRING', 'mode': 'NULLABLE'},
        # NOTE: ProcedureDateTime is loaded as a STRING. For analytics,
        # consider casting to a DATETIME or TIMESTAMP in BigQuery.
        {'name': 'ProcedureDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
    ]
}

class ParseCsvFn(beam.DoFn):
    """Parses a CSV line into a dictionary element."""
    def process(self, element):
        try:
            # Split the CSV line by comma.
            # This is a basic parser; for complex CSVs (e.g., with quoted commas),
            # consider using Python's `csv` module.
            values = element.split(',')
            
            # Ensure the row has the expected number of columns.
            if len(values) == 9:
                yield {
                    'ProcedureID': values[0],
                    'PatientID': values[1],
                    'EncounterID': values[2],
                    'ProviderID': values[3],
                    'FacilityID': values[4],
                    'LocationID': values[5],
                    'ProcedureCode': values[6],
                    'ProcedureDesc': values[7],
                    'ProcedureDateTime': values[8],
                }
            else:
                 logging.warning(f"Skipping malformed row: {element}")
        except Exception as e:
            logging.error(f"Error parsing line '{element}': {e}")

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        required=True,
        help='GCS path for the factprocedure source CSV file.')
    parser.add_argument(
        '--output_table',
        required=True,
        help='BigQuery table to write to, in the format `project:dataset.table`')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from the source file in GCS
        source_data = (
            p
            | 'ReadFromGCS' >> beam.io.ReadFromText(
                known_args.input_factprocedure, skip_header_lines=1)
        )

        # 2. Parse the CSV data into structured dictionaries
        parsed_data = (
            source_data
            | 'ParseCSV' >> beam.ParDo(ParseCsvFn())
        )
        
        # NOTE on Transformations:
        # The original ETL specified a 'sort' operation on 'ProcedureCode'.
        # Performing a global sort on a large-scale, distributed dataset is an
        # anti-pattern in frameworks like Apache Beam and Dataflow due to high
        # computational and cost overhead. The recommended best practice is to load
        # the unsorted data into BigQuery and perform sorting there using 'ORDER BY'
        # in your queries, which is highly optimized.
        # Therefore, the sort step is intentionally omitted from this pipeline.
        
        # 3. Write the results to BigQuery
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=TABLE_SCHEMA,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()