import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

def parse_line(element):
    """Parses a line of text into a dictionary with a single key."""
    return {'raw_data': element}

def run(argv=None):
    """Main entry point; defines and runs the pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawConsentRecord',
        dest='input_rawConsentRecord',
        required=True,
        help='Input file path for source rawConsentRecord on GCS.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery schema
    # As no columns were provided, we default to a single raw_data column.
    table_schema = {
        'fields': [
            {'name': 'raw_data', 'type': 'STRING', 'mode': 'NULLABLE'}
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # Read from the source file on GCS
        raw_consent_record = p | 'ReadRawConsentRecord'
            >> beam.io.ReadFromText(known_args.input_rawConsentRecord)

        # The 'select1' transformation in the JSON is a pass-through.
        # We parse each line into a dictionary format required by BigQuery.
        parsed_data = raw_consent_record | 'ParseToDict'
            >> beam.Map(parse_line)

        # Write the results to BigQuery
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()