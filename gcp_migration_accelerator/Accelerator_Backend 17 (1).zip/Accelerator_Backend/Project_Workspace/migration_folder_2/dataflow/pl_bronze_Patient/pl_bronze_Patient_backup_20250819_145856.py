#   Copyright 2024 Google LLC
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# NOTE: Since no CSV columns were provided, this script will treat each line
# from the source file as a single string field named 'raw_data'.
# To parse the CSV into distinct columns, please provide the column names.


def parse_line(element):
    """Reads a line and returns a dictionary with the raw data."""
    return {"raw_data": element}


def run():
    """Builds and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser(description='Apache Beam ETL pipeline.')
    parser.add_argument(
        '--input_rawPatient',
        required=True,
        help='Input GCS file path for the rawPatient source.')
    parser.add_argument(
        '--output_table',
        required=True,
        help='Output BigQuery table specification, e.g., project:dataset.table.')

    known_args, pipeline_args = parser.parse_known_args()
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery schema
    # As no columns were provided, a single 'raw_data' column is defined.
    table_schema = {
        'fields': [
            {'name': 'raw_data', 'type': 'STRING', 'mode': 'NULLABLE'}
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # Read from the source file in GCS
        raw_patient_data = (
            p
            | 'ReadRawPatientData' >> beam.io.ReadFromText(known_args.input_rawPatient, skip_header_lines=1)
        )

        # The 'select1' transformation is a simple pass-through.
        # Parse each line into a dictionary format suitable for BigQuery.
        parsed_data = (
            raw_patient_data
            | 'SelectAndParse' >> beam.Map(parse_line)
        )

        # Write the results to the target BigQuery table
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()