import argparse
import logging
import csv
import io

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

class ParseCsvDoFn(beam.DoFn):
    """
    Parses a CSV line into a dictionary, assuming a specific order of columns.
    """
    def __init__(self, headers):
        self.headers = headers

    def process(self, element):
        try:
            # Use csv.reader to handle quoted fields and other CSV complexities
            reader = csv.reader(io.StringIO(element))
            values = next(reader)
            if len(values) == len(self.headers):
                row = dict(zip(self.headers, values))
                yield row
            else:
                logging.warning(f"Skipping malformed row: found {len(values)} fields, expected {len(self.headers)}. Row: {element}")
        except StopIteration:
            # This can happen for empty lines
            logging.warning(f"Skipping empty or unparsable row: {element}")
        except Exception as e:
            logging.error(f"Error parsing row '{element}': {e}")

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_dimpatient',
        dest='input_dimpatient',
        required=True,
        help='GCS path for the input dimpatient CSV file.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='BigQuery table spec for the output table, e.g., project_id:dataset.table.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # BigQuery table schema
    table_schema = {
        'fields': [
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FirstName', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LastName', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'DOB', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Gender', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Phone', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Email', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    # Column headers for parsing the CSV file
    csv_headers = [
        'PatientID', 'FirstName', 'LastName', 'DOB', 'Gender', 'Phone', 'Email'
    ]

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from the source file in GCS
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_dimpatient, skip_header_lines=1)

        # 2. Parse CSV lines into dictionaries
        parsed_rows = lines | 'ParseCSV' >> beam.ParDo(ParseCsvDoFn(csv_headers))

        # Note: The 'sort' transformation is not implemented as a global sort is inefficient
        # in a distributed processing environment like Dataflow. Sorting is best performed
        # in the sink system (BigQuery) upon querying.

        # 3. Write the processed records to BigQuery
        parsed_rows | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()