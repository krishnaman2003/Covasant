import argparse
import logging
import csv
import io

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

class ParseCsvDoFn(beam.DoFn):
    """Parses a CSV line into a dictionary based on the expected schema."""
    def process(self, element):
        try:
            # Use io.StringIO to treat the string line as a file for the csv reader
            reader = csv.reader(io.StringIO(element))
            row = next(reader)
            # Ensure the row has the correct number of columns
            if len(row) == 9:
                yield {
                    'EncounterID': row[0],
                    'AppointmentID': row[1],
                    'PatientID': row[2],
                    'ProviderID': row[3],
                    'FacilityID': row[4],
                    'LocationID': row[5],
                    'EncounterType': row[6],
                    'StartDateTime': row[7],
                    'EndDateTime': row[8]
                }
        except (csv.Error, IndexError) as e:
            logging.warning(f"Skipping malformed line: {element}. Error: {e}")

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_FactEncounter',
        dest='input_FactEncounter',
        required=True,
        help='Input GCS file path for the FactEncounter source.'
    )
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to. Format: PROJECT:DATASET.TABLE'
    )
    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery table schema
    table_schema = {
        'fields': [
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'AppointmentID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterType', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'StartDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EndDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from the source GCS file, assuming a header row.
        fact_encounter = (
            p
            | 'ReadFactEncounter' >> beam.io.ReadFromText(
                known_args.input_FactEncounter, skip_header_lines=1)
            | 'ParseFactEncounterCSV' >> beam.ParDo(ParseCsvDoFn())
        )

        # 2. Apply the filter transformation. The logic '1==1' means all rows pass.
        # This is a pass-through filter but is implemented to match the source JSON logic.
        filtered_data = (
            fact_encounter
            | 'Filter1' >> beam.Filter(lambda element: True)
        )

        # 3. Write results to BigQuery, appending to the table if it exists.
        filtered_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()