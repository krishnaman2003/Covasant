import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

def run(argv=None):
    """Main entry point; defines and runs the pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_labresult',
        dest='input_labresult',
        required=True,
        help='Input file path for labresult source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)

    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery table schema
    table_schema = {
        'fields': [
            {'name': 'LabResultID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LabOrderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'TestCode', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'TestName', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ResultValue', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Unit', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ResultDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ResultStatus', 'type': 'STRING', 'mode': 'NULLABLE'}
        ]
    }

    def parse_csv(line):
        """Parses a CSV line into a dictionary."""
        # This is a simple parser assuming no commas within fields.
        # For more complex CSVs, use Python's 'csv' module.
        columns = [
            'LabResultID', 'LabOrderID', 'PatientID', 'EncounterID',
            'TestCode', 'TestName', 'ResultValue', 'Unit',
            'ResultDateTime', 'ResultStatus'
        ]
        values = line.split(',')
        if len(values) == len(columns):
            return dict(zip(columns, values))
        else:
            # Log malformed rows if necessary
            return None

    with beam.Pipeline(options=pipeline_options) as p:

        # 1. Read from the source GCS file
        lab_results = (
            p
            | 'ReadLabResultData' >> beam.io.ReadFromText(
                known_args.input_labresult, skip_header_lines=1)
            | 'ParseCSVToDict' >> beam.Map(parse_csv)
            | 'RemoveMalformedRows' >> beam.Filter(lambda x: x is not None)
        )

        # 2. Filter for specific TestName
        filtered_results = (
            lab_results
            | 'FilterByTestName' >> beam.Filter(
                lambda element: element.get('TestName') == 'COVID-19 PCR')
        )

        # Note: The 'sort' transformation from the source JSON is computationally
        # expensive for large-scale distributed data and is often best handled
        # by ordering the data in the sink system (e.g., using ORDER BY in BigQuery).
        # Therefore, a direct sort transform is omitted here.

        # 3. Write the final PCollection to BigQuery
        filtered_results | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()