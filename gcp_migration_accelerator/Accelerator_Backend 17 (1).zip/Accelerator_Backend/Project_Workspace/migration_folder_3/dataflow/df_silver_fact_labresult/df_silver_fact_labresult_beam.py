import argparse
import logging
import csv
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

def run(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_labresult',
        dest='input_labresult',
        required=True,
        help='Input file path for labresult source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)

    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery table schema
    table_schema = {
        'fields': [
            {'name': 'LabResultID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LabOrderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'TestCode', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'TestName', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ResultValue', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Unit', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ResultDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ResultStatus', 'type': 'STRING', 'mode': 'NULLABLE'}
        ]
    }

    def parse_csv(line):
        """Parses a CSV line into a dictionary using the csv module."""
        columns = [
            'LabResultID', 'LabOrderID', 'PatientID', 'EncounterID',
            'TestCode', 'TestName', 'ResultValue', 'Unit',
            'ResultDateTime', 'ResultStatus'
        ]
        try:
            # Use csv.reader for robust parsing of a single line.
            values = next(csv.reader([line]))
            if len(values) == len(columns):
                return dict(zip(columns, values))
            else:
                return None
        except (StopIteration, csv.Error):
            # Handle potential empty lines or parsing errors
            return None

    with beam.Pipeline(options=pipeline_options) as p:

        # 1. Read from the source GCS file
        lab_results = (
            p
            | 'ReadLabResultData' >> beam.io.ReadFromText(
                known_args.input_labresult, skip_header_lines=1)
            | 'ParseCSVToDict' >> beam.Map(parse_csv)
            | 'RemoveMalformedRows' >> beam.Filter(lambda x: x is not None)
        )

        # 2. Filter for specific TestName
        filtered_results = (
            lab_results
            | 'FilterByTestName' >> beam.Filter(
                lambda element: element.get('TestName') == 'COVID-19 PCR')
        )

        # 3. Sort by LabOrderID as per specification
        # Note: This performs a global sort which collects all elements onto a single
        # worker. This is memory-intensive and may not scale for large datasets.
        sorted_results = (
            filtered_results
            | 'CombineGlobally' >> beam.transforms.combiners.ToList()
            | 'SortGlobally' >> beam.Map(lambda elements: sorted(elements, key=lambda x: x.get('LabOrderID', '')))
            | 'Flatten' >> beam.FlatMap(lambda sorted_list: sorted_list)
        )

        # 4. Write the final PCollection to BigQuery
        sorted_results | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()