import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions


def parse_csv_to_dict(line, header):
    """Parses a CSV line into a dictionary using a provided header."""
    try:
        values = line.split(',')
        if len(values) == len(header):
            return dict(zip(header, values))
    except Exception as e:
        logging.warning(f"Could not parse line: {line}. Error: {e}")
    return None

def run(argv=None):
    """Main entry point; defines and runs the pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factObservation',
        dest='input_factObservation',
        required=True,
        help='Input GCS file path for the factObservation source CSV.'
    )
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table specification, e.g., project:dataset.table'
    )
    known_args, pipeline_args = parser.parse_known_args(argv)

    pipeline_options = PipelineOptions(pipeline_args)

    # Define the schema for the output BigQuery table
    table_schema = {
        'fields': [
            {'name': 'ObservationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ObservationType', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Value', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Unit', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ObservationDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Source', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    # Define the CSV header based on the source definition
    csv_header = [
        'ObservationID',
        'PatientID',
        'EncounterID',
        'ObservationType',
        'Value',
        'Unit',
        'ObservationDateTime',
        'Source'
    ]

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read from the source GCS file
        observations = (
            p
            | 'ReadObservationData' >> beam.io.ReadFromText(
                known_args.input_factObservation, skip_header_lines=1
            )
            | 'ParseCSVToDict' >> beam.Map(parse_csv_to_dict, header=csv_header)
            | 'RemoveFailedParses' >> beam.Filter(lambda x: x is not None)
        )

        # 2. Apply the filter transformation
        filtered_observations = (
            observations
            | 'FilterByTypeTemp' >> beam.Filter(
                lambda element: element.get('ObservationType') == 'TEMP'
            )
        )

        # 3. Write the results to the target BigQuery table
        filtered_observations | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()