import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Helper function to parse CSV lines into dictionaries
def parse_csv(element):
    """Parses a CSV line into a dictionary based on a predefined schema."""
    # Based on the TRANSFORMATIONS string
    columns = [
        'ProcedureID',
        'PatientID',
        'EncounterID',
        'ProviderID',
        'FacilityID',
        'LocationID',
        'ProcedureCode',
        'ProcedureDesc',
        'ProcedureDateTime'
    ]
    values = element.split(',')
    if len(values) == len(columns):
        return dict(zip(columns, values))
    return {}

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_factprocedure',
        dest='input_factprocedure',
        required=True,
        help='GCS path for the input factprocedure CSV file.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery schema for the output table
    table_schema = {
        'fields': [
            {'name': 'ProcedureID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProviderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureCode', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureDesc', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ProcedureDateTime', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # The pipeline reads data, parses it, and writes to BigQuery.
        # The 'sort' transformation from the source JSON is omitted as it does not
        # affect the final output in a simple sink operation and is inefficient in a distributed context.
        
        # 1. Read input data from GCS
        input_data = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_factprocedure, skip_header_lines=1)

        # 2. Parse CSV data into dictionaries
        parsed_data = input_data | 'ParseCSV' >> beam.Map(parse_csv)

        # 3. Filter out any empty rows that may result from parsing errors
        valid_data = parsed_data | 'FilterEmpty' >> beam.Filter(lambda x: x)

        # 4. Write the results to BigQuery
        valid_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()