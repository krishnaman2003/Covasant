import argparse
import logging
import csv
import io

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions


def parse_csv_line(line):
    """Parses a single CSV line into a dictionary."""
    # Use the csv module to handle fields that might contain commas
    try:
        # Assuming a standard comma delimiter
        reader = csv.reader(io.StringIO(line))
        values = next(reader)
        
        columns = [
            'ImagingStudyID',
            'PatientID',
            'EncounterID',
            'FacilityID',
            'LocationID',
            'Modality',
            'BodyPart',
            'StudyInstanceUID',
            'StudyDateTime',
            'Findings'
        ]
        
        if len(values) != len(columns):
            logging.warning(f"Row has incorrect number of columns. Expected {len(columns)}, got {len(values)}. Row: {line}")
            return None
            
        return dict(zip(columns, values))
    except StopIteration:
        # This can happen for empty lines
        logging.warning(f"Skipping empty or malformed line: {line}")
        return None

def run(argv=None):
    """The main entrypoint for the Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawImagingStudy',
        required=True,
        help='Input GCS path for the rawImagingStudy CSV file.'
    )
    parser.add_argument(
        '--output_table',
        required=True,
        help='Output BigQuery table to write to, in the format PROJECT:DATASET.TABLE.'
    )

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery table schema
    table_schema = {
        'fields': [
            {'name': 'ImagingStudyID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Modality', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'BodyPart', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'StudyInstanceUID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'StudyDateTime', 'type': 'TIMESTAMP', 'mode': 'NULLABLE'},
            {'name': 'Findings', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # 1. Read the raw data from the GCS source file
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_rawImagingStudy, skip_header_lines=1
        )

        # 2. Parse each CSV line into a dictionary
        parsed_data = lines | 'ParseCSV' >> beam.Map(parse_csv_line)

        # 3. Filter out any rows that failed to parse
        valid_data = parsed_data | 'FilterInvalidRows' >> beam.Filter(lambda x: x is not None)
        
        # 4. Write the results to the BigQuery target table
        # The 'select1' transformation in the source JSON is a simple pass-through,
        # so no explicit Beam transform is needed.
        valid_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()