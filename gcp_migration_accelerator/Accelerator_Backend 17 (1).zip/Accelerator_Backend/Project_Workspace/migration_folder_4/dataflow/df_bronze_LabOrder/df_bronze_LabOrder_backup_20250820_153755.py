# AUTO-GENERATED APACHE BEAM SCRIPT
#
# Pipeline Name: df_bronze_LabOrder
#

import argparse
import logging
import csv
from io import StringIO

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Defines the BigQuery schema for the output table.
def get_bigquery_schema():
    """Defines the BigQuery schema for the target table."""
    return {
        'fields': [
            {'name': 'LabOrderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'TestCode', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'TestName', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'OrderDateTime', 'type': 'TIMESTAMP', 'mode': 'NULLABLE'},
            {'name': 'OrderStatus', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

def parse_csv_to_dict(csv_row):
    """Parses a CSV row string into a dictionary.

    This function assumes a fixed column order as defined in the pipeline.
    It uses the csv module for robust parsing of fields.
    """
    headers = [
        'LabOrderID',
        'PatientID',
        'EncounterID',
        'TestCode',
        'TestName',
        'OrderDateTime',
        'OrderStatus'
    ]
    # Use StringIO to treat the string row as a file
    reader = csv.reader(StringIO(csv_row))
    row_values = next(reader)
    return dict(zip(headers, row_values))

def run(argv=None):
    """The main function which creates and runs the pipeline."""
    parser = argparse.ArgumentParser()

    # Input argument for the 'rawLabOrder' source
    parser.add_argument(
        '--input_rawLabOrder',
        dest='input_rawLabOrder',
        required=True,
        help='Input GCS file path for rawLabOrder.')

    # Output argument for the BigQuery table
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:

        # Step 1: Read from the GCS source file.
        # The transformation is a simple select, so we read, parse, and write.
        source_data = p | 'ReadRawLabOrder' >> beam.io.ReadFromText(
            known_args.input_rawLabOrder, skip_header_lines=1)

        # Step 2: Parse each CSV row into a Python dictionary.
        parsed_data = source_data | 'ParseCSV' >> beam.Map(parse_csv_to_dict)

        # Step 3: Write the results to the specified BigQuery table.
        # The `select1` transformation in the JSON is a direct mapping,
        # so no further transformation PTransforms are needed.
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=get_bigquery_schema(),
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()