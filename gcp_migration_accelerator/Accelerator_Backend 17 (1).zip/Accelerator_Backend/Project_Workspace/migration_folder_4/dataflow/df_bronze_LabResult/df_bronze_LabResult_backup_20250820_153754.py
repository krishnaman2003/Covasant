import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# This function parses a CSV line into a dictionary.
# It assumes a simple comma-separated format without quoted fields.
def parse_csv_to_dict(line):
    # Define the column headers in the order they appear in the CSV
    columns = [
        'LabResultID',
        'LabOrderID',
        'PatientID',
        'EncounterID',
        'TestCode',
        'TestName',
        'ResultValue',
        'Unit',
        'ResultDateTime',
        'ResultStatus'
    ]
    values = line.split(',')
    # Basic validation to ensure the number of columns matches
    if len(values) == len(columns):
        return dict(zip(columns, values))
    else:
        # Log or handle malformed lines
        logging.warning(f"Skipping malformed line: {line}")
        return None

def run(argv=None):
    """The main function which creates and runs the pipeline."""

    parser = argparse.ArgumentParser()
    # Add command-line arguments for all sources
    parser.add_argument(
        '--input_rawLabResult',
        dest='input_rawLabResult',
        required=True,
        help='Input GCS file path for the rawLabResult source.')

    # Add command-line argument for the output BigQuery table
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    # Parse arguments from the command line
    known_args, pipeline_args = parser.parse_known_args(argv)

    # Define the BigQuery schema for the output table
    table_schema = {
        'fields': [
            {'name': 'LabResultID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LabOrderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'TestCode', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'TestName', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ResultValue', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Unit', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ResultDateTime', 'type': 'TIMESTAMP', 'mode': 'NULLABLE'},
            {'name': 'ResultStatus', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    # Create the Beam pipeline
    with beam.Pipeline(options=PipelineOptions(pipeline_args)) as p:
        # The pipeline logic starts here
        rows = (
            p
            | 'ReadFromGCS' >> beam.io.ReadFromText(
                known_args.input_rawLabResult, skip_header_lines=1)
            | 'ParseCSVToDict' >> beam.Map(parse_csv_to_dict)
            | 'FilterNone' >> beam.Filter(lambda x: x is not None)
        )

        # The 'select1' transformation is a simple pass-through in this context,
        # so no additional transform is needed before writing to the sink.

        # Write the results to the BigQuery sink
        rows | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()