import argparse
import csv
import io
import logging

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

def parse_csv(element, header):
    """Parses a CSV line into a dictionary."""
    if not element or not element.strip():
        return None
    try:
        # Use the csv module for robust parsing of a single line
        csv_file = io.StringIO(element)
        reader = csv.reader(csv_file)
        values = next(reader)
        row = dict(zip(header, values))
        return row
    except StopIteration:
        logging.warning(f"Skipping empty or malformed CSV line: {element}")
        return None
    except Exception as e:
        logging.error(f"Error parsing element {element}: {e}")
        return None

def run(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawLocation',
        dest='input_rawLocation',
        required=True,
        help='Input file GCS path for the rawLocation source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery schema for the output table
    table_schema = {
        'fields': [
            {'name': 'LocationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FacilityID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Unit', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Room', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Bed', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    # The header for the input CSV file
    csv_header = ['LocationID', 'FacilityID', 'Unit', 'Room', 'Bed']

    with beam.Pipeline(options=pipeline_options) as p:
        # Read from the GCS file, skip the header row
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_rawLocation, skip_header_lines=1)

        # Parse each CSV line into a dictionary
        parsed_data = (
            lines
            | 'ParseCSV' >> beam.Map(parse_csv, header=csv_header)
            | 'FilterNone' >> beam.Filter(lambda x: x is not None)
        )

        # The 'select1' transformation is a direct pass-through in this case,
        # as all columns are selected and no modifications are made.
        # So, we write the parsed data directly to BigQuery.
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()