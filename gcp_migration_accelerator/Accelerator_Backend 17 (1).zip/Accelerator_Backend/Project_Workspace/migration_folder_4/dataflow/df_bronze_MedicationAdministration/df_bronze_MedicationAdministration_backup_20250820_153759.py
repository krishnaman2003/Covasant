import argparse
import logging

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

class ParseCsvToDict(beam.DoFn):
    """Parses a CSV line into a dictionary."""
    def process(self, element):
        try:
            # Assuming comma-separated values corresponding to the schema
            columns = element.split(',')
            yield {
                'MedicationAdministrationID': columns[0] if len(columns) > 0 else None,
                'MedicationOrderID': columns[1] if len(columns) > 1 else None,
                'PatientID': columns[2] if len(columns) > 2 else None,
                'EncounterID': columns[3] if len(columns) > 3 else None,
                'AdminDateTime': columns[4] if len(columns) > 4 else None,
                'AdminStatus': columns[5] if len(columns) > 5 else None,
                'Route': columns[6] if len(columns) > 6 else None,
            }
        except Exception as e:
            logging.error(f'Error parsing line: {element}. Error: {e}')

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawMedicationAdministration',
        dest='input_rawMedicationAdministration',
        required=True,
        help='GCS path for the rawMedicationAdministration source CSV file.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table specifier in the format PROJECT:DATASET.TABLE.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery table schema based on the transformation logic
    table_schema = {
        'fields': [
            {'name': 'MedicationAdministrationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'MedicationOrderID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'AdminDateTime', 'type': 'TIMESTAMP', 'mode': 'NULLABLE'},
            {'name': 'AdminStatus', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Route', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # Read the source data from GCS
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_rawMedicationAdministration, skip_header_lines=1)

        # The 'select1' transformation is a direct mapping, so we parse the CSV
        # into a dictionary matching the target schema.
        transformed_data = lines | 'ParseAndSelect' >> beam.ParDo(ParseCsvToDict())

        # Write the transformed data to the target BigQuery table
        transformed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()