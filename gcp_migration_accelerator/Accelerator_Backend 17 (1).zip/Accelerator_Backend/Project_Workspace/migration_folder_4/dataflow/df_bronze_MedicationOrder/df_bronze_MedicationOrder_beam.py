import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
import csv
import io

# Define the schema for the output BigQuery table
TABLE_SCHEMA = (
    'MedicationOrderID:STRING, PatientID:STRING, EncounterID:STRING, '
    'ProviderID:STRING, RxCode:INTEGER, MedicationName:STRING, '
    'StartDate:DATE, EndDate:DATE, Status:STRING'
)

class ParseCsv(beam.DoFn):
    """Parses a CSV line into a dictionary using the csv module."""
    def process(self, element):
        try:
            # The csv module expects an iterable, so we wrap the string in a list
            columns = next(csv.reader([element]))
            if len(columns) == 9:
                yield {
                    'MedicationOrderID': columns[0],
                    'PatientID': columns[1],
                    'EncounterID': columns[2],
                    'ProviderID': columns[3],
                    'RxCode': int(columns[4]),
                    'MedicationName': columns[5],
                    'StartDate': columns[6],
                    'EndDate': columns[7],
                    'Status': columns[8]
                }
            else:
                logging.warning(f'Skipping row with incorrect number of columns: {element}')
        except (csv.Error, ValueError, IndexError) as e:
            logging.error(f'Error processing row {element}: {e}')

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawMedicationOrder',
        dest='input_rawMedicationOrder',
        required=True,
        help='GCS path for the rawMedicationOrder source CSV file.'
    )
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to in the format PROJECT:DATASET.TABLE.'
    )
    known_args, pipeline_args = parser.parse_known_args(argv)

    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # Read from the source GCS file
        source_data = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_rawMedicationOrder, skip_header_lines=1
        )

        # The 'select1' transformation is a simple passthrough, so we just parse the source data.
        parsed_data = source_data | 'ParseCSV' >> beam.ParDo(ParseCsv())

        # Write the results to the target BigQuery table
        parsed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=TABLE_SCHEMA,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()