import argparse
import logging
import csv
import io
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

TABLE_SCHEMA = (
    'ProcedureID:STRING, PatientID:STRING, EncounterID:STRING, '
    'ProviderID:STRING, FacilityID:STRING, LocationID:STRING, '
    'ProcedureCode:INTEGER, ProcedureDesc:STRING, ProcedureDateTime:TIMESTAMP'
)

CSV_HEADERS = [
    'ProcedureID', 'PatientID', 'EncounterID', 'ProviderID', 'FacilityID',
    'LocationID', 'ProcedureCode', 'ProcedureDesc', 'ProcedureDateTime'
]

def parse_csv(element):
    """Parses a CSV line into a dictionary using the csv module."""
    try:
        # Use io.StringIO to treat the string element as a file for the csv reader
        # This requires: import csv, import io
        reader = csv.reader(io.StringIO(element))
        values = next(reader)

        if len(values) != len(CSV_HEADERS):
            logging.warning(f"Skipping row with mismatched column count: {element}")
            return None
            
        row = dict(zip(CSV_HEADERS, values))

        # Type casting with error handling
        if 'ProcedureCode' in row and row['ProcedureCode']:
            try:
                row['ProcedureCode'] = int(row['ProcedureCode'])
            except (ValueError, TypeError):
                row['ProcedureCode'] = None

        return row
    except StopIteration:
        # This handles empty lines that would cause `next(reader)` to fail
        return None
    except Exception as e:
        logging.error(f'Error parsing line: {element}. Error: {e}')
        return None


def run(argv=None):
    """Main entry point; defines and runs the pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawProcedure',
        dest='input_rawProcedure',
        required=True,
        help='Input file path for the rawProcedure source in GCS.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=pipeline_options) as p:
        # Read from the source file in GCS, skipping the header row
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(
            known_args.input_rawProcedure, skip_header_lines=1)

        # Parse each CSV line into a dictionary and handle potential errors
        parsed_data = lines | 'ParseCSV' >> beam.Map(parse_csv)

        # Filter out any rows that failed to parse
        valid_data = parsed_data | 'FilterInvalidRows' >> beam.Filter(lambda x: x is not None)

        # The 'select1' transformation is a simple pass-through in this JSON,
        # so no additional transform is needed.

        # Write the processed data to the target BigQuery table
        valid_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            table=known_args.output_table,
            schema=TABLE_SCHEMA,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()