import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions


def parse_source_data(element):
    """Parses a single CSV line into a dictionary.

    Args:
        element (str): A string representing a line from the CSV file.

    Returns:
        dict: A dictionary representing the parsed row of data.
    """
    columns = [
        'ProviderID',
        'FirstName',
        'LastName',
        'Specialty',
        'NPI',
        'Email'
    ]
    values = [v.strip() for v in element.split(',')]
    return dict(zip(columns, values))


def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawProvider',
        dest='input_rawProvider',
        required=True,
        help='Input GCS file path for the rawProvider source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)

    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery schema for the output table
    table_schema = (
        'ProviderID:STRING, '
        'FirstName:STRING, '
        'LastName:STRING, '
        'Specialty:STRING, '
        'NPI:STRING, '
        'Email:STRING'
    )

    with beam.Pipeline(options=pipeline_options) as pipeline:
        # Read from the GCS source file, skipping the header row
        raw_provider_data = (
            pipeline
            | 'ReadFromGCS' >> beam.io.ReadFromText(
                known_args.input_rawProvider, skip_header_lines=1)
        )

        # The 'select1' transformation is a simple 1:1 mapping.
        # We parse the CSV data into a dictionary format suitable for BigQuery.
        transformed_data = (
            raw_provider_data
            | 'ParseCSV' >> beam.Map(parse_source_data)
        )

        # Write the processed data to the target BigQuery table
        transformed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )


if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()