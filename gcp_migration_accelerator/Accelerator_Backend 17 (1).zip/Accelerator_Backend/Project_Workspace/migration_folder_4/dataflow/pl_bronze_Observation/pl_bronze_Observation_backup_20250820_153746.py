import argparse
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

def parse_csv(element):
    """Parses a CSV line into a dictionary."""
    columns = [
        'ObservationID',
        'PatientID',
        'EncounterID',
        'ObservationType',
        'Value',
        'Unit',
        'ObservationDateTime',
        'Source'
    ]
    values = element.split(',')
    if len(values) == len(columns):
        return dict(zip(columns, values))
    return {}

def run(argv=None):
    """Main entry point; defines and runs the pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawObservation',
        dest='input_rawObservation',
        required=True,
        help='Input file path for the rawObservation source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery schema for the output table
    table_schema = {
        'fields': [
            {'name': 'ObservationID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'EncounterID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ObservationType', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Value', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Unit', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'ObservationDateTime', 'type': 'TIMESTAMP', 'mode': 'NULLABLE'},
            {'name': 'Source', 'type': 'STRING', 'mode': 'NULLABLE'}
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # Read from the GCS source file
        raw_observation_data = (
            p
            | 'ReadRawObservation'
            >> beam.io.ReadFromText(known_args.input_rawObservation, skip_header_lines=1)
        )

        # Transformation: Parse CSV and convert to dictionary
        # This corresponds to the 'select1' step in the JSON
        transformed_data = (
            raw_observation_data
            | 'ParseToDict'
            >> beam.Map(parse_csv)
            | 'FilterEmptyRows'
            >> beam.Filter(lambda x: x)
        )

        # Write the results to the BigQuery target table
        transformed_data | 'WriteToBigQuery' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()