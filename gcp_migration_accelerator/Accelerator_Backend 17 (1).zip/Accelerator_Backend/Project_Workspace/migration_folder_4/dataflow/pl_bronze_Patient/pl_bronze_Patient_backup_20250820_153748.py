# AUTO-GENERATED BEAM SCRIPT
# Pipeline Name: pl_bronze_Patient

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
import argparse
import logging
import csv
import io

def parse_csv_line(csv_row):
    """Parses a CSV row into a dictionary."""
    # Assumes the CSV columns are in the order defined in the source transformation
    header = [
        'PatientID',
        'FirstName',
        'LastName',
        'DOB',
        'Gender',
        'Phone',
        'Email'
    ]
    # Using csv.reader to handle potential quotes in data
    reader = csv.reader([csv_row])
    row_values = next(reader)
    
    if len(row_values) != len(header):
        # Log a warning or handle error for malformed rows
        logging.warning(f"Skipping malformed row: {csv_row}")
        return None

    row_dict = dict(zip(header, row_values))
    return row_dict

def run(argv=None):
    """Defines and runs the Apache Beam pipeline."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_rawPatient',
        dest='input_rawPatient',
        required=True,
        help='Input GCS file path for rawPatient source.')
    parser.add_argument(
        '--output_table',
        dest='output_table',
        required=True,
        help='Output BigQuery table to write results to.')

    known_args, pipeline_args = parser.parse_known_args(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    # Define the BigQuery schema for the output table
    table_schema = {
        'fields': [
            {'name': 'PatientID', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'FirstName', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'LastName', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'DOB', 'type': 'DATE', 'mode': 'NULLABLE'},
            {'name': 'Gender', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Phone', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'Email', 'type': 'STRING', 'mode': 'NULLABLE'},
        ]
    }

    with beam.Pipeline(options=pipeline_options) as p:
        # Step 1: Read from rawPatient source (GCS)
        raw_patient_data = (
            p | 'ReadFromGCS_rawPatient' >> beam.io.ReadFromText(known_args.input_rawPatient, skip_header_lines=1)
              | 'ParseCSV_rawPatient' >> beam.Map(parse_csv_line)
              | 'FilterNone_rawPatient' >> beam.Filter(lambda x: x is not None)
        )

        # Step 2: Apply 'select1' transformation (pass-through)
        # This step doesn't modify the data, as per the JSON logic.
        selected_data = (
            raw_patient_data | 'select1' >> beam.Map(lambda x: x)
        )

        # Step 3: Write to bronzePatient target (BigQuery)
        selected_data | 'WriteToBigQuery_bronzePatient' >> beam.io.WriteToBigQuery(
            known_args.output_table,
            schema=table_schema,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
        )

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()