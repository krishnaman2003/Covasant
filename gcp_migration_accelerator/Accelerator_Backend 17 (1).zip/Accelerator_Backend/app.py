import logging
logging.getLogger("watchfiles").setLevel(logging.WARNING)

import json
import os
import logging
from fastapi import FastAPI, UploadFile, File, Form, Request, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

# Logging setup (MUST be before importing routers)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()
    ]
)

# Routers from modules
from routers.validation_router import router as validation_router
from routers.migration import router as workspace_router
from routers.ingest import router as ingest_router
from routers.config import router as config_router
from routers.dashboard_router import router as dashboard_router
from routers.parser_core import router as parser_router
from routers.uploader_core import router as deployer_router
from routers.notebook_generator import router as notebook_router
from routers.agent_router import router as agent_router
from routers.dataflow_router import router as dataflow_router
from routers.file_browser_router import router as file_browser_router
from routers.deploy_router import router as deploy_router
from routers.flex_template import router as flex_template_router

app = FastAPI()

# Optional: Enable CORS (only if your frontend calls these APIs)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change this in production!
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers

app.include_router(workspace_router)
app.include_router(validation_router)
app.include_router(config_router)
app.include_router(dashboard_router)
app.include_router(ingest_router)
app.include_router(parser_router)
app.include_router(notebook_router)
app.include_router(agent_router)
app.include_router(file_browser_router)
app.include_router(dataflow_router)
app.include_router(deployer_router)
app.include_router(deploy_router)
app.include_router(flex_template_router)

@app.get("/")
def read_root():
    return {"message": "Welcome to Accelerator API"}