import os
import requests
import json
import base64
import logging
import time
 
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
 
def create_workspace_folder(databricks_instance, databricks_token, folder_path):
    """Create a workspace folder in Databricks."""
    api_url = f"{databricks_instance}/api/2.0/workspace/mkdirs"
    headers = {"Authorization": f"Bearer {databricks_token}", "Content-Type": "application/json"}
    data = {"path": folder_path}
    response = requests.post(api_url, headers=headers, data=json.dumps(data))
    if response.status_code != 200:
        logger.error(f"Failed to create workspace folder {folder_path}: {response.text}")
        raise Exception(f"Failed to create workspace folder: {response.text}")
    logger.info(f"Created workspace folder: {folder_path}")
 
def upload_notebook_to_databricks(notebook_path, databricks_token, databricks_instance, databricks_folder_path):
    """Upload a single notebook to Databricks."""
    if not os.path.exists(notebook_path):
        logger.error(f"Notebook file not found: {notebook_path}")
        raise Exception(f"Notebook file not found: {notebook_path}")
   
    with open(notebook_path, "r", encoding="utf-8") as f:
        notebook_content = f.read()
   
    base_name = os.path.basename(notebook_path)
   
    # Assume all files are .py and set format to SOURCE
    api_format = "SOURCE"
 
    # Define headers and url before use
    headers = {
        "Authorization": f"Bearer {databricks_token}",
        "Content-Type": "application/json"
    }
    url = f"{databricks_instance}/api/2.0/workspace/import"
 
    payload = {
        "path": f"{databricks_folder_path}/{os.path.splitext(base_name)[0]}",
        "format": api_format,
        "language": "PYTHON",
        "content": base64.b64encode(notebook_content.encode("utf-8")).decode("ascii")
    }
   
    logger.info(f"Uploading notebook {base_name} with format '{api_format}' to: {databricks_folder_path}")
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code != 200:
        logger.error(f"Failed to upload notebook {base_name}: {response.text}")
        raise Exception(f"Failed to upload notebook {base_name}: {response.text}")
    logger.info(f"Uploaded notebook: {base_name}")
    return base_name
   
 
def upload_all_notebooks_in_folder(migration_id, databricks_token, databricks_instance, databricks_folder_path):
    """Upload all notebooks in the notebook_generated folder."""
    base_path = os.path.join("Project_Workspace", migration_id, "notebook_generated")
    if not os.path.exists(base_path):
        logger.error(f"Base path not found: {base_path}")
        return []
    uploaded = []
    for root, _, files in os.walk(base_path):
        for file in files:
            if file.endswith(".py"):
                notebook_path = os.path.join(root, file)
                try:
                    uploaded.append(upload_notebook_to_databricks(notebook_path, databricks_token, databricks_instance, databricks_folder_path))
                except Exception as e:
                    logger.error(f"Failed to upload notebook {file}: {str(e)}")
    return uploaded
 
def upload_notebooks_from_folders(migration_id, folder_names, databricks_token, databricks_instance, databricks_folder_path, base_path=None):
    """Upload notebooks from specified folders."""
    if base_path is None:
        base_path = os.path.join("Project_Workspace", migration_id, "notebook_generated")
    uploaded = []
    for folder in folder_names:
        folder_path = os.path.normpath(os.path.join(base_path, folder))
        if not os.path.exists(folder_path):
            logger.warning(f"Folder not found: {folder_path}")
            continue
        for root, _, files in os.walk(folder_path):
            for file in files:
                if file.endswith(".py"):
                    notebook_path = os.path.join(root, file)
                    try:
                        uploaded.append(upload_notebook_to_databricks(notebook_path, databricks_token, databricks_instance, databricks_folder_path))
                    except Exception as e:
                        logger.error(f"Failed to upload notebook {file}: {str(e)}")
    return uploaded
 
def upload_selected_notebooks(migration_id, notebook_ids, databricks_token, databricks_instance, databricks_folder_path):
    """Upload selected notebooks based on notebook IDs."""
    registry_path = os.path.join("Project_Workspace", migration_id, "notebook_generated", "notebook_registry.json")
    if not os.path.exists(registry_path):
        logger.error(f"Notebook registry not found: {registry_path}")
        raise Exception(f"Notebook registry not found: {registry_path}")
    with open(registry_path, "r") as f:
        registry = json.load(f)
    uploaded = []
    for notebook_id in notebook_ids:
        notebook_entry = registry.get(notebook_id)
        if not notebook_entry:
            logger.warning(f"Notebook ID not found in registry: {notebook_id}")
            continue
        notebook_path = notebook_entry.get("notebook_path")
        if not os.path.exists(notebook_path):
            logger.warning(f"Notebook file not found: {notebook_path}")
            continue
        try:
            uploaded_path = upload_notebook_to_databricks(notebook_path, databricks_token, databricks_instance, databricks_folder_path)
            uploaded.append(uploaded_path)
        except Exception as e:
            logger.error(f"Failed to upload notebook {notebook_id}: {str(e)}")
    return uploaded
 
def create_databricks_job(databricks_instance, databricks_token, job_name, tasks, cluster_type, cluster_id, depends_on=None):
    """Create a Databricks job with tasks and optional dependencies."""
    headers = {"Authorization": f"Bearer {databricks_token}", "Content-Type": "application/json"}
    url = f"{databricks_instance}/api/2.1/jobs/create"
    job_spec = {
        "name": job_name,
        "tasks": tasks
    }
    if cluster_type == "serverless":
        job_spec["job_clusters"] = [{
            "job_cluster_key": "serverless_cluster",
            "new_cluster": {
                "spark_version": "14.3.x-snapshot",
                "node_type_id": "serverless"
            }
        }]
    elif cluster_type == "allpurpose":
        # Validate cluster_id
        cluster_check_url = f"{databricks_instance}/api/2.0/clusters/get?cluster_id={cluster_id}"
        response = requests.get(cluster_check_url, headers=headers)
        if response.status_code != 200:
            logger.error(f"Invalid cluster_id {cluster_id}: {response.text}")
            raise Exception(f"Invalid cluster_id {cluster_id}: {response.text}")
        for task in tasks:
            task["existing_cluster_id"] = cluster_id
    if depends_on:
        job_spec["depends_on"] = depends_on
 
    logger.info(f"Creating job {job_name} with payload: {json.dumps(job_spec, indent=2)}")
    response = requests.post(url, headers=headers, json=job_spec)
    if response.status_code != 200:
        logger.error(f"Failed to create job {job_name}: {response.text}")
        raise Exception(f"Failed to create job {job_name}: {response.text}")
    job_id = response.json().get("job_id")
    logger.info(f"Created job {job_name} with ID: {job_id}")
    return job_id
 
def run_databricks_job(databricks_instance, databricks_token, job_id):
    """Run a Databricks job and return the run ID."""
    api_url = f"{databricks_instance}/api/2.1/jobs/run-now"
    headers = {"Authorization": f"Bearer {databricks_token}", "Content-Type": "application/json"}
    data = {"job_id": job_id}
    response = requests.post(api_url, headers=headers, data=json.dumps(data))
    if response.status_code != 200:
        logger.error(f"Failed to run job ID {job_id}: {response.text}")
        raise Exception(f"Failed to run job ID {job_id}: {response.text}")
    run_id = response.json()["run_id"]
    logger.info(f"Started job run with ID: {run_id}")
    return run_id