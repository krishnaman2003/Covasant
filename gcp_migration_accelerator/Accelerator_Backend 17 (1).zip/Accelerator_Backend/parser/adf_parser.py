import json
import io

def convert_arm_json(json_bytes):
    data = json.load(io.BytesIO(json_bytes))

    tp = data.get("properties", {}).get("typeProperties", {})
    sources = []
    targets = []
    transformations = []
    transformation_script = []

    for src in tp.get("sources", []):
        sources.append({
            "dataset": src.get("dataset"),
            "name": src.get("name"),
            "description": src.get("description", "ARM Source")
        })
    for sink in tp.get("sinks", []):
        targets.append({
            "dataset": sink.get("dataset"),
            "name": sink.get("name"),
            "description": sink.get("description", "ARM Target")
        })
    for trans in tp.get("transformations", []):
        transformations.append({
            "name": trans.get("name")
        })
    transformation_script = tp.get("scriptLines", [])

    return build_unified_json(data.get("name", "ARM_Pipeline"), "ADF", sources, targets, transformations, transformation_script)

def build_unified_json(name, etl_type, sources, targets, transformations, transformation_script):
    return {
        "name": name,
        "ETL_Type": etl_type,   
        "properties": {
            "type": "MappingDataFlow",
            "typeProperties": {
                "SOURCE_LIST": sources,
                "TARGET_LIST": targets,
                "TRANSFORMATION_LIST": transformations,
                "TRANSFORMATIONS": transformation_script
            }
        }
    }

def convert_to_uniform_format(json_bytes):
    # Accepts bytes, returns unified JSON
    return convert_arm_json(json_bytes)

