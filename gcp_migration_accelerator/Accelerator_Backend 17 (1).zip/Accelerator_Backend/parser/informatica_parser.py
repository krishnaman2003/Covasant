import xml.etree.ElementTree as ET

def parse_informatica(xml_file_path):
    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()

        json_data = {
            "name": "Informatica_Mapping",
            "ETL_Type": "Informatica",
            "properties": {
                "type": "MappingDataFlow",
                "typeProperties": {
                    "SOURCE_LIST": [],
                    "TARGET_LIST": [],
                    "TRANSFORMATION_LIST": [],
                    "TRANSFORMATIONS": []
                }
            }
        }

        # Sources
        for source in root.findall('.//SOURCE'):
            fields = []
            for field in source.findall('.//SOURCEFIELD'):
                field_def = f"{field.get('NAME')} as {field.get('DATATYPE')}"
                if field.get('PRECISION') and field.get('SCALE'):
                    field_def += f"({field.get('PRECISION')},{field.get('SCALE')})"
                elif field.get('PRECISION'):
                    field_def += f"({field.get('PRECISION')})"
                fields.append(field_def)

            json_data["properties"]["typeProperties"]["SOURCE_LIST"].append({
                "dataset": {
                    "referenceName": source.get("NAME"),
                    "type": source.get("DATABASETYPE")
                },
                "name": source.get("NAME"),
                "description": source.get("DESCRIPTION", "")
            })

            json_data["properties"]["typeProperties"]["TRANSFORMATIONS"].append(
                f"source(output(\n    " + ",\n    ".join(fields) +
                "\n),\n    allowSchemaDrift: true,\n    validateSchema: false,\n" +
                "    ignoreNoFilesFound: false) ~> " + source.get("NAME")
            )

        # Targets
        for target in root.findall('.//TARGET'):
            json_data["properties"]["typeProperties"]["TARGET_LIST"].append({
                "dataset": {
                    "referenceName": target.get("NAME"),
                    "type": target.get("DATABASETYPE")
                },
                "name": target.get("NAME"),
                "description": target.get("DESCRIPTION", "")
            })

        # Mappings / Transformations
        for mapping in root.findall('.//MAPPING'):
            transformations = {}

            for trans in mapping.findall('.//TRANSFORMATION'):
                name = trans.get("NAME")
                ttype = trans.get("TYPE")
                transformations[name] = {
                    "type": ttype,
                    "fields": [],
                    "inputs": [],
                    "outputs": []
                }
                for field in trans.findall('.//TRANSFORMFIELD'):
                    transformations[name]["fields"].append({
                        "name": field.get("NAME"),
                        "dataType": field.get("DATATYPE"),
                        "precision": field.get("PRECISION", ""),
                        "scale": field.get("SCALE", "")
                    })

            for conn in mapping.findall('.//CONNECTOR'):
                from_inst = conn.get("FROMINSTANCE")
                to_inst = conn.get("TOINSTANCE")
                if from_inst in transformations:
                    transformations[from_inst]["outputs"].append(to_inst)
                if to_inst in transformations:
                    transformations[to_inst]["inputs"].append(from_inst)

            for name, t in transformations.items():
                if t["type"] == "Source Qualifier":
                    continue
                elif t["type"] == "Target Definition" and t["inputs"]:
                    in_trans = t["inputs"][0]
                    json_data["properties"]["typeProperties"]["TRANSFORMATIONS"].append(
                        f"{in_trans} sink(\n    allowSchemaDrift: true,\n    validateSchema: false) ~> {name}"
                    )
                elif t["type"] == "Joiner" and len(t["inputs"]) >= 2:
                    conditions = [f"{t['inputs'][i]}@ID == {t['inputs'][0]}@ID" for i in range(1, len(t["inputs"]))]
                    json_data["properties"]["typeProperties"]["TRANSFORMATIONS"].append(
                        f"{', '.join(t['inputs'])} join({', '.join(conditions)},\n    joinType:'inner', matchType:'exact') ~> {name}"
                    )
                elif t["inputs"]:
                    json_data["properties"]["typeProperties"]["TRANSFORMATIONS"].append(
                        f"{t['inputs'][0]} {t['type'].lower()}() ~> {name}"
                    )

                json_data["properties"]["typeProperties"]["TRANSFORMATION_LIST"].append({
                    "name": name,
                    "description": "",
                    "type": t["type"]
                })

        return json_data

    except Exception as e:
        return {
            "ETL_Type": "Informatica",
            "error": str(e),
            "file": xml_file_path
        } 





















































# import xml.etree.ElementTree as ET
# import json

# def parse_informatica(xml_file_path):
#     try:
#         tree = ET.parse(xml_file_path)
#         root = tree.getroot()

#         # --- 1. Build mapping: session -> mapping name ---
#         session_to_mapping = {}
#         for sess in root.findall(".//SESSION"):
#             sess_name = sess.attrib.get("NAME")
#             map_name = sess.attrib.get("MAPPINGNAME") or sess.attrib.get("MAPNAME")
#             if sess_name and map_name:
#                 session_to_mapping[sess_name] = map_name

#         # --- 2. Workflow dependencies ---
#         dependencies_map = {}
#         for wflink in root.findall(".//WORKFLOWLINK"):
#             from_task = wflink.attrib.get("FROMTASK", "").strip()
#             to_task = wflink.attrib.get("TOTASK", "").strip()
#             if from_task.lower() == "start" or to_task.lower() == "start":
#                 continue
#             if from_task and to_task:
#                 dependencies_map.setdefault(from_task, []).append(to_task)

#         for sess in dependencies_map:
#             dependencies_map[sess] = sorted(set(dependencies_map[sess]))

#         # --- 3. Dataset type inference ---
#         def infer_dataset_type(obj_elem):
#             db_type = obj_elem.attrib.get("DATABASETYPE", "").lower()
#             if "flat file" in db_type:
#                 flatfile_elem = obj_elem.find(".//FLATFILE")
#                 if flatfile_elem is not None:
#                     if flatfile_elem.attrib.get("DELIMITED", "").upper() == "YES":
#                         return "csv"
#                     else:
#                         return "flatfile"
#                 return "flatfile"
#             elif any(db in db_type for db in ["oracle", "sql", "postgres", "mysql", "teradata", "snowflake"]):
#                 return "table"
#             else:
#                 return db_type or "unknown"

#         # --- 4. Extract mapping details ---
#         def extract_mapping_details(mapping_name):
#             mapping_elem = root.find(f".//MAPPING[@NAME='{mapping_name}']")
#             if mapping_elem is None:
#                 return [], [], [], []

#             connectors = []
#             used_trans_names = set()
#             used_ports = set()

#             # Collect connectors
#             for conn in mapping_elem.findall(".//CONNECTOR"):
#                 from_inst = f"{mapping_name}.{conn.attrib['FROMINSTANCE']}"
#                 to_inst = f"{mapping_name}.{conn.attrib['TOINSTANCE']}"
#                 from_field = conn.attrib['FROMFIELD']
#                 to_field = conn.attrib['TOFIELD']

#                 connectors.append(f"{from_inst}({from_field}) ~> {to_inst}({to_field})")
#                 used_trans_names.update([from_inst, to_inst])
#                 used_ports.add((from_inst, from_field))
#                 used_ports.add((to_inst, to_field))

#             # Sources
#             sources = []
#             for inst in mapping_elem.findall(".//INSTANCE[@TYPE='SOURCE']"):
#                 src_obj_name = inst.attrib.get("TRANSFORMATIONNAME", inst.attrib["NAME"])
#                 src_def = root.find(f".//SOURCE[@NAME='{src_obj_name}']")
#                 if src_def is not None:
#                     dataset_type = infer_dataset_type(src_def)
#                     sources.append({
#                         "name": src_obj_name,
#                         "type": dataset_type,
#                         "databaseType": src_def.attrib.get("DATABASETYPE", ""),
#                         "dbName": src_def.attrib.get("DBDNAME", ""),
#                         "description": f"Source {dataset_type} {src_obj_name}"
#                     })

#             # Targets
#             targets = []
#             for inst in mapping_elem.findall(".//INSTANCE[@TYPE='TARGET']"):
#                 tgt_obj_name = inst.attrib.get("TRANSFORMATIONNAME", inst.attrib["NAME"])
#                 tgt_def = root.find(f".//TARGET[@NAME='{tgt_obj_name}']")
#                 if tgt_def is not None:
#                     dataset_type = infer_dataset_type(tgt_def)
#                     targets.append({
#                         "name": tgt_obj_name,
#                         "type": dataset_type,
#                         "databaseType": tgt_def.attrib.get("DATABASETYPE", ""),
#                         "dbName": tgt_def.attrib.get("DBDNAME", ""),
#                         "description": f"Target {dataset_type} {tgt_obj_name}"
#                     })

#             # Transformations
#             transformations = []
#             for trans in mapping_elem.findall(".//TRANSFORMATION"):
#                 fq_name = f"{mapping_name}.{trans.attrib['NAME']}"
#                 if fq_name not in used_trans_names:
#                     continue

#                 t_info = {
#                     "name": fq_name,
#                     "type": trans.attrib.get("TYPE", ""),
#                     "description": f"{trans.attrib.get('TYPE', '')} transformation in mapping {mapping_name}"
#                 }

#                 # Ports
#                 ports = []
#                 for port in trans.findall(".//PORT"):
#                     if (fq_name, port.attrib["NAME"]) not in used_ports:
#                         continue
#                     port_info = {
#                         "name": port.attrib["NAME"],
#                         "datatype": port.attrib.get("DATATYPE", ""),
#                         "precision": port.attrib.get("PRECISION", ""),
#                         "scale": port.attrib.get("SCALE", ""),
#                         "portType": port.attrib.get("PORTTYPE", "")
#                     }
#                     expr = port.attrib.get("EXPRESSION")
#                     if expr:
#                         port_info["expression"] = expr
#                     ports.append(port_info)
#                 if ports:
#                     t_info["ports"] = ports

#                 # Attributes + SQL override
#                 attributes = {}
#                 for tattr in trans.findall(".//TABLEATTRIBUTE"):
#                     attr_name = tattr.attrib["NAME"].strip()
#                     value = tattr.attrib.get("VALUE", "").strip()
#                     attributes[attr_name] = value
#                     if "sql" in attr_name.lower() and value:
#                         t_info["sqlOverride"] = value
#                 if attributes:
#                     t_info["attributes"] = attributes

#                 transformations.append(t_info)

#             return sources, targets, transformations, connectors

#         # --- 5. Session properties ---
#         def extract_session_properties(sess_elem):
#             sess_name = sess_elem.attrib["NAME"]
#             props_list = []
#             for sess_ext in sess_elem.findall(".//SESSIONEXTENSION"):
#                 target_inst = sess_ext.attrib.get("REFINSTANCE", "")
#                 props = {"session": sess_name, "target": target_inst}

#                 for attr in sess_ext.findall(".//ATTRIBUTE"):
#                     name = attr.attrib["NAME"].strip().lower()
#                     val = attr.attrib.get("VALUE", "")
#                     if name == "truncate target table":
#                         props["truncateTarget"] = (val.lower() == "yes")
#                     elif name == "target load type":
#                         props["loadType"] = val
#                     elif name == "commit interval":
#                         props["commitInterval"] = int(val) if val.isdigit() else val

#                 if len(props.keys() - {"session", "target"}) > 0:
#                     props_list.append(props)
#             return props_list

#         # --- 6. Build sessions array ---
#         sessions_data = []
#         for sess_elem in root.findall(".//SESSION"):
#             sess_name = sess_elem.attrib["NAME"]
#             mapping_name = session_to_mapping.get(sess_name)
#             sources, targets, transformations, connectors = ([], [], [], [])
#             if mapping_name:
#                 sources, targets, transformations, connectors = extract_mapping_details(mapping_name)

#             session_data = {
#                 "session": sess_name,
#                 "mapping": mapping_name,
#                 "sources": sources,
#                 "targets": targets,
#                 "transformations": transformations,
#                 "connectors": connectors,
#                 "sessionProperties": extract_session_properties(sess_elem),
#                 "dependencies": dependencies_map.get(sess_name, [])
#             }
#             sessions_data.append(session_data)

#         # --- 7. Final JSON ---
#         return {
#             "name": "Informatica_ETL_Flow_Grouped_By_Session",
#             "ETL_Type": "Informatica",
#             "SESSIONS": sessions_data
#         }

#     except Exception as e:
#         return {
#             "ETL_Type": "Informatica",
#             "error": str(e),
#             "file": xml_file_path
#         }



















































