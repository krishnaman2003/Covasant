
import json
import os
from collections import defaultdict, deque

def split_informatica_json_by_job(unified_data, output_dir):
    """
    Takes grouped-by-session Informatica JSON and writes one JSON per session.
    Orders sessions so dependencies come before dependents (topological sort).
    Strips common prefixes like 's_m_' or 'm_' from filenames.
    """

    sessions = unified_data.get("SESSIONS", [])
    if not sessions:
        raise ValueError("No 'SESSIONS' key found in the provided data.")

    os.makedirs(output_dir, exist_ok=True)

    # --- 1. Build dependency graph ---
    graph = defaultdict(list)
    indegree = defaultdict(int)
    session_map = {}

    for session in sessions:
        session_name = session.get("session", "UNKNOWN_SESSION")
        deps = session.get("dependencies", [])
        session_map[session_name] = session
        indegree.setdefault(session_name, 0)
        for dep in deps:
            graph[dep].append(session_name)
            indegree[session_name] += 1

    # --- 2. Topological sort ---
    queue = deque([s for s in indegree if indegree[s] == 0])
    ordered_sessions = []

    while queue:
        s = queue.popleft()
        ordered_sessions.append(session_map[s])
        for neighbor in graph[s]:
            indegree[neighbor] -= 1
            if indegree[neighbor] == 0:
                queue.append(neighbor)

    if len(ordered_sessions) < len(sessions):
        remaining = {s["session"] for s in sessions} - {s["session"] for s in ordered_sessions}
        for sname in remaining:
            ordered_sessions.append(session_map[sname])

    # --- 3. Write each session file ---
    written_files = []

    for session in ordered_sessions:
        raw_name = session.get("session", "UNKNOWN_SESSION")
        clean_name = raw_name
        for prefix in ["s_m_", "m_"]:
            if clean_name.lower().startswith(prefix):
                clean_name = clean_name[len(prefix):]

        session_json = {
            "name": f"Informatica_Mapping_{clean_name}",
            "ETL_Type": "Informatica",
            "properties": {
                "type": "MappingDataFlow",
                "typeProperties": {
                    "SOURCE_LIST": session.get("sources", []),
                    "TARGET_LIST": session.get("targets", []),
                    "TRANSFORMATION_LIST": session.get("transformations", []),
                    "TRANSFORMATIONS": session.get("connectors", [])
                }
            },
            "SESSION_DEPENDENCIES": [{"session": raw_name, "dependsOn": session.get("dependencies", [])}],
            "SESSION_PROPERTIES": session.get("sessionProperties", [])
        }

        out_path = os.path.join(output_dir, f"{clean_name}.json")
        with open(out_path, "w") as f:
            json.dump(session_json, f, indent=4)

        written_files.append(out_path)

    return written_files
 