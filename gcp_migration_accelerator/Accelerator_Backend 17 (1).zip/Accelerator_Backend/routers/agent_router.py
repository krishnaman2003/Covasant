

from fastapi import APIRouter, HTTPException, Query, UploadFile, File, status, Body
import os
import tempfile
import json
import datetime
import asyncio
import logging
import shutil
from typing import List, Optional
from Agent.generator import generate_beam_and_yaml, apply_review_modifications
from Agent.review_agent import generate_review

router = APIRouter(prefix="/api/agent", tags=["GCP Migration Transformer"])

WORKSPACE_DIR = "Project_Workspace"
logger = logging.getLogger(__name__)

def write_log(migration_id: str, message: str):
    log_dir = os.path.join(WORKSPACE_DIR, migration_id, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "activity.log")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    with open(log_path, "a") as log_file:
        log_file.write(f"{timestamp} - INFO - {message}\n")

def mark_generated(parsed_output_dir, filename):
    status_path = os.path.join(parsed_output_dir, "generated_status.json")
    if os.path.exists(status_path):
        with open(status_path, "r") as f:
            status = json.load(f)
    else:
        status = {}
    status[filename] = True
    with open(status_path, "w") as f:
        json.dump(status, f, indent=2)

# async def process_file(file_path, gcp_config_data, output_folder, migration_id):
#     result = {}
#     try:
#         with open(file_path, "r") as f:
#             unified_json_data = json.load(f)
#         msg = f"Processing file: {file_path}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#     except Exception as e:
#         error_msg = f"Failed to read: {e}"
#         logger.error(f"[{migration_id}] {error_msg} for file: {file_path}")
#         write_log(migration_id, f"{error_msg} for file: {file_path}")
#         result = {"file": file_path, "error": error_msg}
#         return result

#     try:
#         agent_response = await generate_beam_and_yaml(unified_json_data, gcp_config_data)
#     except Exception as e:
#         error_msg = f"Agent logic failed: {e}"
#         logger.error(f"[{migration_id}] {error_msg} for file: {file_path}")
#         write_log(migration_id, f"{error_msg} for file: {file_path}")
#         result = {"file": file_path, "error": error_msg}
#         return result

#     beam_script = agent_response.get("beam_script")
#     yaml_config = agent_response.get("yaml_config")

#     if not beam_script or not yaml_config:
#         error_msg = "Agent response missing content."
#         logger.error(f"[{migration_id}] {error_msg} for file: {file_path}")
#         write_log(migration_id, f"{error_msg} for file: {file_path}")
#         result = {"file": file_path, "error": error_msg}
#         return result

#     pipeline_name = os.path.splitext(os.path.basename(file_path))[0]
#     pipeline_output_path = os.path.join(output_folder, pipeline_name)
#     os.makedirs(pipeline_output_path, exist_ok=True)

#     beam_filename = f"{pipeline_name}_beam.py"
#     beam_path = os.path.join(pipeline_output_path, beam_filename)
#     yaml_path = os.path.join(pipeline_output_path, "cloudbuild.yaml")

#     with open(beam_path, "w") as f:
#         f.write(beam_script)
#     with open(yaml_path, "w") as f:
#         f.write(yaml_config)

#     parsed_output_dir = os.path.dirname(file_path)
#     mark_generated(parsed_output_dir, os.path.basename(file_path))

#     msg = f"Generated files for pipeline: {pipeline_name} -> {beam_path}, {yaml_path}"
#     logger.info(f"[{migration_id}] {msg}")
#     write_log(migration_id, msg)
#     result = {
#         "pipeline_name": pipeline_name,
#         "beam_script_path": beam_path,
#         "yaml_config_path": yaml_path,
#         "message": "Agent triggered and files generated."
#     }
#     return result

AGENT_CONCURRENCY_LIMIT = int(os.getenv("AGENT_CONCURRENCY_LIMIT", 2))
agent_semaphore = asyncio.Semaphore(AGENT_CONCURRENCY_LIMIT)

# async def limited_process_file(file_path, gcp_config_data, output_folder, migration_id):
#     async with agent_semaphore:
#         msg_start = f"START processing file (semaphore acquired): {file_path}"
#         logger.info(f"[{migration_id}] {msg_start}")
#         write_log(migration_id, msg_start)
#         result = await process_file(file_path, gcp_config_data, output_folder, migration_id)
#         msg_end = f"END processing file: {file_path} | Result: {result.get('message', result.get('error', 'Unknown'))}"
#         logger.info(f"[{migration_id}] {msg_end}")
#         write_log(migration_id, msg_end)
#         return result
    



@router.post("/trigger/{migration_id}")
async def trigger_full_agent(
    migration_id: str,
    input_paths: Optional[List[str]] = Query(None, description="List of JSON filenames or a single folder name or single")
):
    WORKSPACE_DIR = "Project_Workspace"
    base_parsed_output = os.path.join(WORKSPACE_DIR, migration_id, "parsed_output")
    gcp_config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
    output_folder = os.path.join(WORKSPACE_DIR, migration_id, "dataflow")

    logger.info(f"[{migration_id}] Script generation started by Coder Agent")
    write_log(migration_id, "Script generation started by Coder Agent")

    try:
        with open(gcp_config_path, "r") as f:
            gcp_config_data = json.load(f)
    except FileNotFoundError:
        msg = f"GCP config file not found: {gcp_config_path}"
        logger.error(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=404, detail=f"GCP config file not found: {gcp_config_path}. Please create it first.")

    files_to_process = []
    for path in input_paths:
        abs_input_path = os.path.join(base_parsed_output, path)
        logger.info(f"[{migration_id}] Looking for file: {abs_input_path}")
        if os.path.isfile(abs_input_path):
            files_to_process.append(abs_input_path)
        elif os.path.isdir(abs_input_path):
            json_files = [
                os.path.join(abs_input_path, fname)
                for fname in os.listdir(abs_input_path)
                if fname.endswith(".json")
            ]
            if not json_files:
                msg = f"No JSON files found in folder: {abs_input_path}"
                logger.error(f"[{migration_id}] {msg}")
                write_log(migration_id, msg)
                raise HTTPException(status_code=404, detail=f"No JSON files found in folder: {abs_input_path}")
            files_to_process.extend(json_files)
        else:
            msg = f"Input path not found: {abs_input_path}"
            logger.error(f"[{migration_id}] {msg}")
            write_log(migration_id, msg)
            raise HTTPException(status_code=404, detail=f"Input path not found: {abs_input_path}")

    AGENT_CONCURRENCY_LIMIT = int(os.getenv("AGENT_CONCURRENCY_LIMIT", 2))
    agent_semaphore = asyncio.Semaphore(AGENT_CONCURRENCY_LIMIT)

    async def process_pipeline_file(file_path):
        async with agent_semaphore:
            try:
                pipeline_name = os.path.splitext(os.path.basename(file_path))[0]
                pipeline_output_path = os.path.join(output_folder, pipeline_name)
                os.makedirs(pipeline_output_path, exist_ok=True)
                beam_filename = f"{pipeline_name}_beam.py"
                beam_path = os.path.join(pipeline_output_path, beam_filename)
                yaml_path = os.path.join(pipeline_output_path, "cloudbuild.yaml")

                # Step 1: Generate Beam script and YAML
                write_log(migration_id, f"Generating Beam script and YAML for file: {pipeline_name}")
                with open(file_path, "r", encoding="utf-8") as f:
                    unified_json_data = json.load(f)
                agent_response = await generate_beam_and_yaml(unified_json_data, gcp_config_data)
                beam_script = agent_response.get("beam_script")
                yaml_config = agent_response.get("yaml_config")
                if not beam_script or not yaml_config:
                    raise Exception("Agent response missing content.")

                # Step 2: Save initial Beam script and YAML
                with open(beam_path, "w", encoding="utf-8") as f:
                    f.write(beam_script)
                with open(yaml_path, "w", encoding="utf-8") as f:
                    f.write(yaml_config)
                write_log(migration_id, f"Initial Beam script and YAML saved for pipeline: {pipeline_name}")

                # Mark generation as done for this file
                parsed_output_dir = os.path.join(WORKSPACE_DIR, migration_id, "parsed_output")
                mark_generated(parsed_output_dir, os.path.basename(file_path))

                # Step 3: Take backup of original Beam script before review
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_beam_path = os.path.join(pipeline_output_path, f"{pipeline_name}_backup_{timestamp}.py")
                shutil.copy2(beam_path, backup_beam_path)
                write_log(migration_id, f"Taking backup of original script for pipeline: {pipeline_name} as {os.path.basename(backup_beam_path)}")

                # Step 4: Send code to Review agent
                write_log(migration_id, f"Sending Beam script for pipeline: {pipeline_name} to Review agent")
                write_log(migration_id, f"Review agent received input for pipeline: {pipeline_name}")
                review_json_str = await generate_review(
                    unified_json=json.dumps(unified_json_data),
                    generated_beam_code=beam_script,
                    beam_script_filename=beam_filename,
                )
                # Save review JSON in the pipeline directory
                review_data = json.loads(review_json_str)
                review_filename = f"review_{pipeline_name}_{timestamp}.json"
                review_path = os.path.join(pipeline_output_path, review_filename)
                with open(review_path, "w", encoding="utf-8") as f:
                    json.dump(review_data, f, ensure_ascii=False, indent=2)
                # Log only the review_summary
                review_summary = review_data.get("review_summary", "No summary available")
                write_log(migration_id, f"Review agent completed for pipeline: {pipeline_name}, summary: {review_summary}")
                write_log(migration_id, f"Sent comments to Coder agent for pipeline: {pipeline_name}")

                # Step 5: Coder Agent applies code changes suggested
                write_log(migration_id, f"Sending Beam script for pipeline: {pipeline_name} and review comments to Coder agent")
                write_log(migration_id, f"Coder agent received input for pipeline: {pipeline_name}")
                with tempfile.NamedTemporaryFile("w+", suffix=".py", delete=False) as tmp_script:
                    tmp_script.write(beam_script)
                    tmp_script_path = tmp_script.name

                with tempfile.NamedTemporaryFile("w+", suffix=".json", delete=False) as tmp_review:
                    tmp_review.write(review_json_str)
                    tmp_review_path = tmp_review.name

                try:
                    updated_script = await apply_review_modifications(tmp_script_path, tmp_review_path)
                finally:
                    os.remove(tmp_script_path)
                    os.remove(tmp_review_path)

                # Step 6: Save updated script as original name, keep backup
                shutil.move(beam_path, backup_beam_path)  # Move old to backup
                with open(beam_path, "w", encoding="utf-8") as f:
                    f.write(updated_script)
                write_log(migration_id, f"Coder agent applied changes for pipeline: {pipeline_name}, updated script saved")
                write_log(migration_id, f"Script generation complete for pipeline: {pipeline_name}")

                return {
                    "pipeline_name": pipeline_name,
                    "beam_script_path": beam_path,
                    "backup_beam_script_path": backup_beam_path,
                    "yaml_config_path": yaml_path,
                    "message": "Final reviewed Beam script and YAML saved."
                }
            except Exception as e:
                error_msg = f"Error in full agent process for {file_path}: {e}"
                logger.error(f"[{migration_id}] {error_msg}")
                write_log(migration_id, error_msg)
                return {"file": file_path, "error": error_msg}

    msg_files = f"Total files to process: {len(files_to_process)} | Files: {files_to_process}"
    logger.info(f"[{migration_id}] {msg_files}")
    write_log(migration_id, msg_files)
    msg_conc = f"Concurrency limit set to {AGENT_CONCURRENCY_LIMIT}"
    logger.info(f"[{migration_id}] {msg_conc}")
    write_log(migration_id, msg_conc)

    tasks = [process_pipeline_file(file_path) for file_path in files_to_process]
    results = await asyncio.gather(*tasks)

    msg_end = f"Full agent trigger completed for input: {input_paths}. All files processed."
    logger.info(f"[{migration_id}] {msg_end}")
    write_log(migration_id, msg_end)

    return results





# @router.post("/trigger/{migration_id}")
# async def trigger_full_agent(
#     migration_id: str,
#     input_paths: Optional[List[str]] = Query(None, description="List of JSON filenames or a single folder name or single")
# ):
#     WORKSPACE_DIR = "Project_Workspace"
#     base_parsed_output = os.path.join(WORKSPACE_DIR, migration_id, "parsed_output")
#     gcp_config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
#     output_folder = os.path.join(WORKSPACE_DIR, migration_id, "dataflow")

#     msg_start = f"GCP Migration Transformer started for input: {input_paths}"
#     logger.info(f"[{migration_id}] {msg_start}")
#     write_log(migration_id, msg_start)

#     try:
#         with open(gcp_config_path, "r") as f:
#             gcp_config_data = json.load(f)
#     except FileNotFoundError:
#         msg = f"GCP config file not found: {gcp_config_path}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail=f"GCP config file not found: {gcp_config_path}. Please create it first.")

#     files_to_process = []
#     for path in input_paths:
#         abs_input_path = os.path.join(base_parsed_output, path)
#         logger.info(f"[{migration_id}] Looking for file: {abs_input_path}")
#         if os.path.isfile(abs_input_path):
#             files_to_process.append(abs_input_path)
#         elif os.path.isdir(abs_input_path):
#             json_files = [
#                 os.path.join(abs_input_path, fname)
#                 for fname in os.listdir(abs_input_path)
#                 if fname.endswith(".json")
#             ]
#             if not json_files:
#                 msg = f"No JSON files found in folder: {abs_input_path}"
#                 logger.error(f"[{migration_id}] {msg}")
#                 write_log(migration_id, msg)
#                 raise HTTPException(status_code=404, detail=f"No JSON files found in folder: {abs_input_path}")
#             files_to_process.extend(json_files)
#         else:
#             msg = f"Input path not found: {abs_input_path}"
#             logger.error(f"[{migration_id}] {msg}")
#             write_log(migration_id, msg)
#             raise HTTPException(status_code=404, detail=f"Input path not found: {abs_input_path}")

#     AGENT_CONCURRENCY_LIMIT = int(os.getenv("AGENT_CONCURRENCY_LIMIT", 2))
#     agent_semaphore = asyncio.Semaphore(AGENT_CONCURRENCY_LIMIT)

#     async def process_pipeline_file(file_path):
#         async with agent_semaphore:
#             try:
#                 write_log(migration_id, f"START agent generation for {file_path}")
#                 with open(file_path, "r", encoding="utf-8") as f:
#                     unified_json_data = json.load(f)
#                 agent_response = await generate_beam_and_yaml(unified_json_data, gcp_config_data)
#                 beam_script = agent_response.get("beam_script")
#                 yaml_config = agent_response.get("yaml_config")
#                 if not beam_script or not yaml_config:
#                     raise Exception("Agent response missing content.")

#                 pipeline_name = os.path.splitext(os.path.basename(file_path))[0]
#                 pipeline_output_path = os.path.join(output_folder, pipeline_name)
#                 os.makedirs(pipeline_output_path, exist_ok=True)
#                 beam_filename = f"{pipeline_name}_beam.py"
#                 beam_path = os.path.join(pipeline_output_path, beam_filename)
#                 yaml_path = os.path.join(pipeline_output_path, "cloudbuild.yaml")

#                 # write_log(migration_id, f"Initial Beam script for {pipeline_name}:\n{beam_script}")

#                 write_log(migration_id, f"START review for {pipeline_name}")
#                 review_json_str = await generate_review(
#                     unified_json=json.dumps(unified_json_data),
#                     generated_beam_code=beam_script,
#                     beam_script_filename=beam_filename,
#                 )
#                 write_log(migration_id, f"Review JSON for {pipeline_name}: {review_json_str}")

#                 write_log(migration_id, f"Applying review suggestions to {pipeline_name}")
#                 with tempfile.NamedTemporaryFile("w+", suffix=".py", delete=False) as tmp_script:
#                     tmp_script.write(beam_script)
#                     tmp_script_path = tmp_script.name

#                 with tempfile.NamedTemporaryFile("w+", suffix=".json", delete=False) as tmp_review:
#                     tmp_review.write(review_json_str)
#                     tmp_review_path = tmp_review.name

#                 try:
#                     updated_script = await apply_review_modifications(tmp_script_path, tmp_review_path)
#                 finally:
#                     os.remove(tmp_script_path)
#                     os.remove(tmp_review_path)

#                 with open(beam_path, "w", encoding="utf-8") as f:
#                     f.write(updated_script)
#                 with open(yaml_path, "w", encoding="utf-8") as f:
#                     f.write(yaml_config)

#                 return {
#                     "pipeline_name": pipeline_name,
#                     "beam_script_path": beam_path,
#                     "yaml_config_path": yaml_path,
#                     "message": "Final reviewed Beam script and YAML saved."
#                 }
#             except Exception as e:
#                 error_msg = f"Error in full agent process for {file_path}: {e}"
#                 logger.error(f"[{migration_id}] {error_msg}")
#                 write_log(migration_id, error_msg)
#                 return {"file": file_path, "error": error_msg}

#     msg_files = f"Total files to process: {len(files_to_process)} | Files: {files_to_process}"
#     logger.info(f"[{migration_id}] {msg_files}")
#     write_log(migration_id, msg_files)
#     msg_conc = f"Concurrency limit set to {AGENT_CONCURRENCY_LIMIT}"
#     logger.info(f"[{migration_id}] {msg_conc}")
#     write_log(migration_id, msg_conc)

#     tasks = [process_pipeline_file(file_path) for file_path in files_to_process]
#     results = await asyncio.gather(*tasks)

#     msg_end = f"Full agent trigger completed for input: {input_paths}. All files processed."
#     logger.info(f"[{migration_id}] {msg_end}")
#     write_log(migration_id, msg_end)

#     return results




# @router.post("/trigger/{migration_id}")
# async def trigger_agent(
#     migration_id: str,
#     input_paths: Optional[List[str]] = Query(None, description="List of JSON filenames or a single folder name or single"),
#     update: bool = Body(False, embed=True, description="Set to true for update mode"),
#     pipeline_name: Optional[str] = Body(None, embed=True, description="Pipeline name (required for update)")
# ):
#     WORKSPACE_DIR = "Project_Workspace"

#     if update:
#         if not pipeline_name:
#             raise HTTPException(status_code=400, detail="pipeline_name is required for update mode.")
#         pipeline_dir = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)
#         # Find latest review JSON
#         review_files = [
#             fname for fname in os.listdir(pipeline_dir)
#             if fname.startswith("review_") and fname.endswith(".json")
#         ]
#         if not review_files:
#             raise HTTPException(status_code=404, detail="No review JSON file found in pipeline directory.")
#         review_files.sort(reverse=True)
#         review_json_name = review_files[0]
#         review_json_path = os.path.join(pipeline_dir, review_json_name)
#         # Find Beam script (not backup)
#         beam_script_name = None
#         for fname in os.listdir(pipeline_dir):
#             if fname.endswith(".py") and "_backup_" not in fname:
#                 beam_script_name = fname
#                 break
#         if not beam_script_name:
#             raise HTTPException(status_code=404, detail="No Beam script file found in pipeline directory.")
#         beam_script_path = os.path.join(pipeline_dir, beam_script_name)
#         # Backup original file
#         timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
#         backup_name = beam_script_name.replace(".py", f"_backup_{timestamp}.py")
#         backup_path = os.path.join(pipeline_dir, backup_name)
#         os.rename(beam_script_path, backup_path)
#         # Generate updated script
#         updated_script = await apply_review_modifications(backup_path, review_json_path)
#         # Save updated script with original name
#         with open(beam_script_path, "w", encoding="utf-8") as f:
#             f.write(updated_script)
#         return {
#             "message": "Beam script updated with review fixes.",
#             "updated_script_path": beam_script_path,
#             "backup_path": backup_path,
#             "review_json_used": review_json_name
#         }

#     # --- Original agent trigger logic (create mode) ---
#     base_parsed_output = os.path.join(WORKSPACE_DIR, migration_id, "parsed_output")
#     gcp_config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
#     output_folder = os.path.join(WORKSPACE_DIR, migration_id, "dataflow")

#     msg_start = f"Agent trigger started for input: {input_paths}"
#     logger.info(f"[{migration_id}] {msg_start}")
#     write_log(migration_id, msg_start)

#     try:
#         with open(gcp_config_path, "r") as f:
#             gcp_config_data = json.load(f)
#     except FileNotFoundError:
#         msg = f"GCP config file not found: {gcp_config_path}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail=f"GCP config file not found: {gcp_config_path}. Please create it first.")

#     files_to_process = []
#     for path in input_paths:
#         abs_input_path = os.path.join(base_parsed_output, path)
#         logger.info(f"[{migration_id}] Looking for file: {abs_input_path}")
#         if os.path.isfile(abs_input_path):
#             files_to_process.append(abs_input_path)
#         elif os.path.isdir(abs_input_path):
#             json_files = [
#                 os.path.join(abs_input_path, fname)
#                 for fname in os.listdir(abs_input_path)
#                 if fname.endswith(".json")
#             ]
#             if not json_files:
#                 msg = f"No JSON files found in folder: {abs_input_path}"
#                 logger.error(f"[{migration_id}] {msg}")
#                 write_log(migration_id, msg)
#                 raise HTTPException(status_code=404, detail=f"No JSON files found in folder: {abs_input_path}")
#             files_to_process.extend(json_files)
#         else:
#             msg = f"Input path not found: {abs_input_path}"
#             logger.error(f"[{migration_id}] {msg}")
#             write_log(migration_id, msg)
#             raise HTTPException(status_code=404, detail=f"Input path not found: {abs_input_path}")

#     msg_files = f"Total files to process: {len(files_to_process)} | Files: {files_to_process}"
#     logger.info(f"[{migration_id}] {msg_files}")
#     write_log(migration_id, msg_files)
#     msg_conc = f"Concurrency limit set to {AGENT_CONCURRENCY_LIMIT}"
#     logger.info(f"[{migration_id}] {msg_conc}")
#     write_log(migration_id, msg_conc)

#     # Run file processing with concurrency limit
#     tasks = [
#         limited_process_file(file_path, gcp_config_data, output_folder, migration_id)
#         for file_path in files_to_process
#     ]
#     results = await asyncio.gather(*tasks)

#     msg_end = f"Agent trigger completed for input: {input_paths}. All files processed."
#     logger.info(f"[{migration_id}] {msg_end}")
#     write_log(migration_id, msg_end)

#     return results

@router.post("/review-pipeline/{migration_id}/{pipeline_name}", status_code=status.HTTP_201_CREATED)
async def review_pipeline(
    migration_id: str,
    pipeline_name: str,
):
    """
    Reviews the Beam script against the unified pipeline JSON and saves the review output as review_pipeline.json
    in the same directory as the Beam script for the given migration and pipeline.
    The files are fetched automatically based on migration_id and pipeline_name.
    """
    WORKSPACE_DIR = "Project_Workspace"
    # Find the unified JSON file
    unified_json_path = os.path.join(WORKSPACE_DIR, migration_id, "parsed_output", f"{pipeline_name}.json")
    # Find the beam script (exclude backup files)
    pipeline_dir = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)
    beam_script_path = None
    for fname in os.listdir(pipeline_dir):
        if fname.endswith(".py") and "_backup_" not in fname:
            beam_script_path = os.path.join(pipeline_dir, fname)
            break

    if not os.path.isfile(unified_json_path):
        raise HTTPException(status_code=404, detail=f"Unified JSON file not found: {unified_json_path}")
    if not beam_script_path or not os.path.isfile(beam_script_path):
        raise HTTPException(status_code=404, detail=f"Beam script file not found in: {pipeline_dir}")

    # Read files
    with open(unified_json_path, "r", encoding="utf-8") as f:
        unified_json_str = f.read()
    with open(beam_script_path, "r", encoding="utf-8") as f:
        beam_script_str = f.read()

    try:
        json.loads(unified_json_str)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON format in the specification file: {exc}")

    try:
        review_json_str = generate_review(
            unified_json=unified_json_str,
            generated_beam_code=beam_script_str,
            beam_script_filename=os.path.basename(beam_script_path),
        )
        if not review_json_str:
            raise HTTPException(status_code=500, detail="Code review generation resulted in an empty response.")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

    try:
        review_data = json.loads(review_json_str)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=500, detail="Model produced invalid JSON for review.")

    # Save review JSON in the pipeline directory as review_pipeline.json
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    review_filename = f"review_{os.path.splitext(os.path.basename(beam_script_path))[0]}_{timestamp}.json"
    review_path = os.path.join(pipeline_dir, review_filename)
    with open(review_path, "w", encoding="utf-8") as f:
        json.dump(review_data, f, ensure_ascii=False, indent=2)

    return {
        "review": review_data,
        "review_file_path": review_path
    }



