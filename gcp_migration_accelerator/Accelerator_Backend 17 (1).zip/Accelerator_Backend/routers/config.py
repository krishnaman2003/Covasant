from fastapi import APIRouter, Request, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
import os
import json
 
router = APIRouter(prefix="/api/config", tags=["Configuration"])
 
 
from fastapi import Form
 
@router.post("/{migration_id}")
async def create_config(
    migration_id: str,
    project_name: str = Form(...),
    domain: str = Form(...),
    target: str = Form(...),
    project_id: str = Form(None),
    region: str = Form(None),
    bucket_name: str = Form(None),
    bigquery_dataset: str = Form(None),
    source: str = Form(None),
    email: str = Form(None),
    instance: str = Form(None),
    access_token: str = Form(None),
    cluster_id: str = Form(None),
    folder_path: str = Form(None),
    json_file: UploadFile = File(None)
):
    config_dir = os.path.join("Project_Workspace", migration_id, "configuration")
    os.makedirs(config_dir, exist_ok=True)
    config_path = os.path.join(config_dir, "config.json")
 
    data = {
        "target": target,
        "project_name": project_name,
        "domain": domain,
        "project_id": project_id,
        "region": region,
        "bucket_name": bucket_name,
        "bigquery_dataset": bigquery_dataset,
        "source": source,
        "email": email,
        "instance": instance,
        "access_token": access_token,
        "cluster_id": cluster_id,
        "folder_path": folder_path
    }
 
    data = {k: v for k, v in data.items() if v is not None}
 
    if target == "gcp":
        required_fields = ["project_id", "region", "bucket_name", "bigquery_dataset", "source", "project_name", "domain"]
        missing = [f for f in required_fields if f not in data]
        if missing:
            return JSONResponse(status_code=400, content={
                "error": "Missing required GCP fields",
                "missing_fields": missing
            })
 
        with open(config_path, "w") as f:
            json.dump(data, f, indent=4)
 
        if json_file:
            if json_file.filename.endswith(".json"):
                with open(os.path.join(config_dir, "service_account.json"), "wb") as f:
                    f.write(await json_file.read())
            else:
                raise HTTPException(status_code=400, detail="Only .json files are allowed")
 
        return JSONResponse(content={"message": "GCP config created successfully.", "config": data})
 
    elif target.lower() == "databricks":
        required_fields = ["email", "instance", "access_token", "folder_path", "source", "cluster_id", "project_name", "domain"]
        missing = [f for f in required_fields if f not in data]
        if missing:
            return JSONResponse(status_code=400, content={
                "error": "Missing required Databricks fields",
                "missing_fields": missing
            })
 
        if json_file:
            raise HTTPException(status_code=400, detail="File upload is not allowed for Databricks config")
 
        with open(config_path, "w") as f:
            json.dump(data, f, indent=4)
 
        return JSONResponse(content={"message": "Databricks config created successfully.", "config": data})
 
    else:
        raise HTTPException(status_code=400, detail="Invalid target. Use 'gcp' or 'databricks'.")
 
@router.put("/{migration_id}")
async def update_databricks_config(
    migration_id: str,
    email: str = Form(None),
    instance: str = Form(None),
    cluster_id: str = Form(None),
    access_token: str = Form(None),
    folder_path: str = Form(None)
):
    config_dir = os.path.join("Project_Workspace", migration_id, "configuration")
    config_path = os.path.join(config_dir, "config.json")
 
    if not os.path.exists(config_path):
        raise HTTPException(status_code=404, detail="Config does not exist. Create it first.")
 
    with open(config_path, "r") as f:
        config_data = json.load(f)
 
    if config_data.get("target").lower() != "databricks":
        raise HTTPException(status_code=400, detail="Only Databricks config can be updated with this endpoint.")
 
    updates = {
        "email": email,
        "instance": instance,
        "cluster_id": cluster_id,
        "access_token": access_token,
        "folder_path": folder_path
    }
 
    updates = {k: v for k, v in updates.items() if v is not None}
    config_data.update(updates)
 
    with open(config_path, "w") as f:
        json.dump(config_data, f, indent=4)
 
    return JSONResponse(content={"message": "Databricks config updated successfully.", "config": config_data})
 
 
 
@router.get("/{migration_id}")
async def get_config(migration_id: str):
    try:
        config_path = os.path.join("Project_Workspace", migration_id, "configuration", "config.json")
        if not os.path.exists(config_path):
            raise HTTPException(status_code=404, detail=f"No config found for migration_id: {migration_id}")
 
        with open(config_path, "r") as f:
            config_data = json.load(f)
 
        return JSONResponse(content=config_data)
 
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read config: {str(e)}") 
 