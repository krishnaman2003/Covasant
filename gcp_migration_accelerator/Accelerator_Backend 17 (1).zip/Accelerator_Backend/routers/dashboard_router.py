from fastapi import APIRouter, Query
import os
import json

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])

WORKSPACE_DIR = "Project_Workspace"

def get_folder_tree(path):
    tree = []
    try:
        for entry in os.scandir(path):
            if entry.is_dir():
                tree.append({
                    "type": "folder",
                    "name": entry.name,
                    "children": get_folder_tree(entry.path)
                })
            else:
                tree.append({
                    "type": "file",
                    "name": entry.name
                })
    except Exception:
        pass
    return tree

@router.get("/migrations")
def list_migrations(workspace: str = Query(WORKSPACE_DIR, description="Workspace directory")):
    """
    List all migration folders in the given workspace.
    """
    results = []
    if not os.path.isdir(workspace):
        return {"error": f"Workspace '{workspace}' not found."}
    for migration_id in os.listdir(workspace):
        migration_path = os.path.join(workspace, migration_id)
        if os.path.isdir(migration_path):
            results.append(migration_id)
    return {"workspace": workspace, "migrations": results}

@router.get("/counts")
def get_dashboard_counts():
    """
    Returns:
    - total_projects: total number of migration folders
    - source_counts: count of each source type (e.g., informatica, adf)
    - target_counts: count of each target type (e.g., gcp, databricks)
    """
    total_projects = 0
    source_counts = {}
    target_counts = {}

    for migration_id in os.listdir(WORKSPACE_DIR):
        migration_path = os.path.join(WORKSPACE_DIR, migration_id)
        if not os.path.isdir(migration_path):
            continue

        config_path = os.path.join(migration_path, "configuration", "config.json")
        if not os.path.exists(config_path):
            continue

        total_projects += 1

        try:
            with open(config_path, "r") as f:
                config = json.load(f)
            source = config.get("source", "").lower()
            target = config.get("target", "").lower()
        except Exception:
            continue

        if source:
            source_counts[source] = source_counts.get(source, 0) + 1
        if target:
            target_counts[target] = target_counts.get(target, 0) + 1

    return {
        "total_projects": total_projects,
        "source_counts": source_counts,
        "target_counts": target_counts
    }



@router.get("/migration-details/{migration_id}")
def get_migration_details(migration_id: str):
    migration_path = os.path.join(WORKSPACE_DIR, migration_id)
    config_path = os.path.join(migration_path, "configuration", "config.json")
    if not os.path.exists(config_path):
        return {"error": f"Config file not found for migration '{migration_id}'."}

    # Load config
    with open(config_path, "r") as f:
        config = json.load(f)
    target = config.get("target", "").lower()

    # Find parsed files
    parsed_dir = os.path.join(migration_path, "parsed_output")
    parsed_files = [
        f for f in os.listdir(parsed_dir)
        if f.endswith(".json")
        and f != "generated_status.json"
        and os.path.isfile(os.path.join(parsed_dir, f))
    ] if os.path.isdir(parsed_dir) else []

    total_parsed = len(parsed_files)

    # Where to look for generated_status.json and .deployed files
    if target == "gcp":
        gen_dir = parsed_dir
    elif target == "databricks":
        gen_dir = os.path.join(migration_path, "notebook_generated")
    else:
        gen_dir = parsed_dir  # fallback

    # Load generated_status.json
    generated_status_path = os.path.join(gen_dir, "generated_status.json")
    if os.path.exists(generated_status_path):
        with open(generated_status_path, "r") as f:
            generated_status = json.load(f)
    else:
        generated_status = {}

    # Count generated and deployed
    generated_count = 0
    deployed_count = 0
    generated_files = []
    deployed_files = []
    for fname in parsed_files:
        if generated_status.get(fname):
            generated_count += 1
            generated_files.append(fname)
            # Check for .deployed file
            deployed_flag = os.path.join(gen_dir, fname.replace(".json", ".deployed"))
            if os.path.exists(deployed_flag):
                deployed_count += 1
                deployed_files.append(fname)
    yet_to_generate = total_parsed - generated_count
    yet_to_deploy = generated_count - deployed_count

    return {
        "migration_id": migration_id,
        "config": config,
        "total_parsed_files": total_parsed,
        "converted_files_count": generated_count,
        # "converted_files": generated_files,
        "deployed_files_count": deployed_count,
        "deployed_files": deployed_files,
        "yet_to_generate": yet_to_generate,
        "yet_to_deploy": yet_to_deploy
    }


@router.get("/logs/{migration_id}")
def get_migration_logs(migration_id: str):
    migration_path = os.path.join(WORKSPACE_DIR, migration_id)
    logs_path = os.path.join(migration_path, "logs")
    if not os.path.exists(logs_path):
        return {"error": f"Logs not found for migration '{migration_id}'."}
    log_files = [f for f in os.listdir(logs_path) if f.endswith(".log")]
    if not log_files:
        return {"error": f"No log files found for migration '{migration_id}'."}

    # Read log files
    logs = {}
    for log_file in log_files:
        log_path = os.path.join(logs_path, log_file)
        with open(log_path, "r") as f:
            logs[log_file] = f.read()

    return {"migration_id": migration_id, "logs": logs}



@router.get("/migration_progress/{migration_id}")
def get_migration_progress(migration_id: str):
    migration_path = os.path.join(WORKSPACE_DIR, migration_id)
    config_path = os.path.join(migration_path, "configuration", "config.json")
    parsed_dir = os.path.join(migration_path, "parsed_output")

    # Step 1: Ingest & Parse
    parsed_files = [
        f for f in os.listdir(parsed_dir)
        if f.endswith(".json")
        and f != "generated_status.json"
        and os.path.isfile(os.path.join(parsed_dir, f))
    ] if os.path.isdir(parsed_dir) else []
    total_parsed = len(parsed_files)

    # Step 2: Generation
    generated_status_path = os.path.join(parsed_dir, "generated_status.json")
    if os.path.exists(generated_status_path):
        with open(generated_status_path, "r") as f:
            generated_status = json.load(f)
    else:
        generated_status = {}

    generated_files = [f for f in parsed_files if generated_status.get(f)]
    generated_count = len(generated_files)

    # Step 3: Deployment
    deployed_files = []
    for f in generated_files:
        pipeline_name = f.replace(".json", "")
        deployed_path = os.path.join(migration_path, "dataflow", pipeline_name, f"{pipeline_name}.deployed")
        if os.path.exists(deployed_path):
            deployed_files.append(f)
    deployed_count = len(deployed_files)

    def percent(count, total):
        return round((count / total) * 100, 1) if total else 0.0

    # Calculate step percentages
    ingest_percent = percent(total_parsed, total_parsed)
    generation_percent = percent(generated_count, total_parsed)
    deployment_percent = percent(deployed_count, generated_count if generated_count else 1)

    # Calculate overall percentage (average of three steps)
    step_percents = [
        generation_percent,
        deployment_percent
    ]
    # Only include ingest if there are files to parse
    if total_parsed > 0:
        step_percents.insert(0, ingest_percent)
    overall_percent = round(sum(step_percents) / len(step_percents), 1) if step_percents else 0.0

    # Determine status
    status = "completed" if overall_percent == 100.0 else "in_progress"

    return {
        "migration_id": migration_id,
        "steps": [
            {
                "name": "Ingest & Parse",
                "completed": total_parsed,
                "total": total_parsed,
                "percent": ingest_percent
            },
            {
                "name": "Generation",
                "completed": generated_count,
                "total": total_parsed,
                "percent": generation_percent
            },
            {
                "name": "Deployment",
                "completed": deployed_count,
                "total": generated_count,
                "percent": deployment_percent
            }
        ],
        "overall_percent": overall_percent,
        "status": status
    }



def calculate_progress(migration_id: str) -> dict:
    migration_path = os.path.join(WORKSPACE_DIR, migration_id)
    config_path = os.path.join(migration_path, "configuration", "config.json")
    parsed_dir = os.path.join(migration_path, "parsed_output")

    # Read project name from config.json
    project_name = None
    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as f:
                config = json.load(f)
            project_name = config.get("project_name")
        except Exception:
            project_name = None

    # Step 1: Ingest & Parse
    parsed_files = [
        f for f in os.listdir(parsed_dir)
        if f.endswith(".json")
        and f != "generated_status.json"
        and os.path.isfile(os.path.join(parsed_dir, f))
    ] if os.path.isdir(parsed_dir) else []
    total_parsed = len(parsed_files)

    # Step 2: Generation
    generated_status_path = os.path.join(parsed_dir, "generated_status.json")
    if os.path.exists(generated_status_path):
        with open(generated_status_path, "r") as f:
            generated_status = json.load(f)
    else:
        generated_status = {}

    generated_files = [f for f in parsed_files if generated_status.get(f)]
    generated_count = len(generated_files)

    # Step 3: Deployment
    deployed_files = []
    for f in generated_files:
        pipeline_name = f.replace(".json", "")
        deployed_path = os.path.join(migration_path, "dataflow", pipeline_name, f"{pipeline_name}.deployed")
        if os.path.exists(deployed_path):
            deployed_files.append(f)
    deployed_count = len(deployed_files)

    def percent(count, total):
        return round((count / total) * 100, 1) if total else 0.0

    # Calculate step percentages
    ingest_percent = percent(total_parsed, total_parsed)
    generation_percent = percent(generated_count, total_parsed)
    deployment_percent = percent(deployed_count, generated_count if generated_count else 1)

    step_percents = [generation_percent, deployment_percent]
    if total_parsed > 0:
        step_percents.insert(0, ingest_percent)

    overall_percent = round(sum(step_percents) / len(step_percents), 1) if step_percents else 0.0
    status = "completed" if overall_percent == 100.0 else "in_progress"

    return {
        "migration_id": migration_id,
        "project_name": project_name,
        "workflow": [
            {
                "name": "Ingest & Parse",
                "completed": total_parsed,
                "total": total_parsed,
                "percent": ingest_percent
            },
            {
                "name": "Generation",
                "completed": generated_count,
                "total": total_parsed,
                "percent": generation_percent
            },
            {
                "name": "Deployment",
                "completed": deployed_count,
                "total": generated_count,
                "percent": deployment_percent
            }
        ],
        "overall_percent": overall_percent,
        "status": status
    }

@router.get("/progress")
def get_all_migrations_progress():
    if not os.path.isdir(WORKSPACE_DIR):
        return {"error": "Workspace directory not found", "migrations": []}

    migration_dirs = [
        d for d in os.listdir(WORKSPACE_DIR)
        if os.path.isdir(os.path.join(WORKSPACE_DIR, d))
    ]

    migrations_progress = []
    for migration_id in migration_dirs:
        try:
            progress = calculate_progress(migration_id)
            migrations_progress.append(progress)
        except Exception as e:
            # Log or handle error; here we just skip broken migrations
            migrations_progress.append({
                "migration_id": migration_id,
                "error": str(e),
                "status": "error"
            })

    return {"migrations": migrations_progress}



