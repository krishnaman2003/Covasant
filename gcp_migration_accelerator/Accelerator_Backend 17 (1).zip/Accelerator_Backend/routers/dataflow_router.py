from fastapi import APIRouter, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
import os
import datetime
import logging
import json
from google.cloud import bigquery

router = APIRouter(prefix="/api/dataflow", tags=["Dataflow Pipelines"])

WORKSPACE_DIR = "Project_Workspace"

# Standard logger for app.log
logger = logging.getLogger(__name__)

def write_log(migration_id: str, message: str):
    log_dir = os.path.join(WORKSPACE_DIR, migration_id, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "activity.log")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    with open(log_path, "a") as log_file:
        log_file.write(f"{timestamp} - INFO - {message}\n")

def build_pipeline_tree(path):
    """
    Recursively builds a tree of folders and files starting from 'path'.
    """
    items = []
    try:
        for entry in sorted(os.listdir(path)):
            entry_path = os.path.join(path, entry)
            if os.path.isdir(entry_path):
                items.append({
                    "name": entry,
                    "type": "folder",
                    "children": build_pipeline_tree(entry_path)
                })
            elif os.path.isfile(entry_path):
                items.append({
                    "name": entry,
                    "type": "file"
                })
    except Exception as e:
        logger.error(f"Error building pipeline tree: {e}")
        # Optionally also log to activity.log if needed
    return items

@router.get("/{migration_id}/pipelines")
def get_pipeline_tree(migration_id: str):
    """
    Returns the full folder/file hierarchy for all pipelines under a migration.
    """
    dataflow_path = os.path.join(WORKSPACE_DIR, migration_id, "dataflow")
    if not os.path.isdir(dataflow_path):
        msg = "Pipeline tree requested but dataflow folder not found."
        logger.info(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=404, detail="Dataflow folder not found.")
    tree = build_pipeline_tree(dataflow_path)
    msg = "Pipeline tree returned."
    logger.info(f"[{migration_id}] {msg}")
    write_log(migration_id, msg)
    return {
        "migration_id": migration_id,
        "tree": tree
    }

@router.get("/{migration_id}/{pipeline_name}/file/{file_name}")
def get_pipeline_file(migration_id: str, pipeline_name: str, file_name: str):
    """
    Gets any file (Beam script, cloudbuild.yaml, etc.) from the pipeline folder as an attachment.
    """
    pipeline_path = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)
    file_path = os.path.join(pipeline_path, file_name)

    if not os.path.isfile(file_path):
        msg = f"File '{file_name}' not found in pipeline '{pipeline_name}'."
        logger.info(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=404, detail=f"File '{file_name}' not found in pipeline '{pipeline_name}'")

    # Set media type based on file extension
    if file_name.endswith(".py"):
        media_type = "text/x-python"
    elif file_name.endswith(".yaml") or file_name.endswith(".yml"):
        media_type = "application/x-yaml"
    else:
        media_type = "application/octet-stream"

    msg = f"File '{file_name}' sent as attachment from pipeline '{pipeline_name}'."
    logger.info(f"[{migration_id}] {msg}")
    write_log(migration_id, msg)
    return FileResponse(file_path, media_type=media_type, filename=file_name)

@router.put("/{migration_id}/{pipeline_name}/file/{file_name}")
async def update_pipeline_file(
    migration_id: str,
    pipeline_name: str,
    file_name: str,
    file: UploadFile = File(...)
):
    """
    Updates any file (Beam script, cloudbuild.yaml, etc.) in the pipeline folder using an uploaded file.
    If the file exists, it is versioned as filename_vN before being overwritten.
    """
    pipeline_path = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)
    file_path = os.path.join(pipeline_path, file_name)

    if not os.path.isdir(pipeline_path):
        msg = f"File update failed: pipeline '{pipeline_name}' folder not found."
        logger.info(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=404, detail=f"Pipeline folder '{pipeline_name}' not found")

    # Versioning logic
    if os.path.isfile(file_path):
        base, ext = os.path.splitext(file_name)
        version = 1
        while True:
            versioned_name = f"{base}_v{version}{ext}"
            versioned_path = os.path.join(pipeline_path, versioned_name)
            if not os.path.exists(versioned_path):
                os.rename(file_path, versioned_path)
                msg = f"Existing file '{file_name}' versioned as '{versioned_name}' in pipeline '{pipeline_name}'."
                logger.info(f"[{migration_id}] {msg}")
                write_log(migration_id, msg)
                break
            version += 1

    try:
        contents = await file.read()
        with open(file_path, "wb") as f:
            f.write(contents)
        msg = f"File '{file_name}' updated in pipeline '{pipeline_name}' via file upload."
        logger.info(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        return {"message": f"File '{file_name}' updated successfully in pipeline '{pipeline_name}'."}
    except Exception as e:
        msg = f"Failed to update file '{file_name}' for pipeline '{pipeline_name}': {e}"
        logger.error(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=500, detail=f"Failed to update file: {e}")
    


@router.post("/{migration_id}/deploy-bigquery-dataset")
def deploy_bigquery_dataset(migration_id: str):
    """
    Checks if the BigQuery dataset exists using config.json and service_account.json.
    If not present, creates the dataset. Otherwise, returns already present.
    """
    config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
    sa_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "service_account.json")

    if not os.path.isfile(config_path):
        msg = f"config.json not found for migration '{migration_id}'."
        logger.info(msg)
        write_log(migration_id, msg)
        raise HTTPException(status_code=404, detail=msg)
    if not os.path.isfile(sa_path):
        msg = f"service_account.json not found for migration '{migration_id}'."
        logger.info(msg)
        write_log(migration_id, msg)
        raise HTTPException(status_code=404, detail=msg)

    try:
        with open(config_path) as f:
            config = json.load(f)
        project_id = config["project_id"]
        dataset_id = config["bigquery_dataset"]
    except Exception as e:
        msg = f"Failed to read config.json: {e}"
        logger.error(msg)
        write_log(migration_id, msg)
        raise HTTPException(status_code=400, detail=msg)

    try:
        client = bigquery.Client.from_service_account_json(sa_path, project=project_id)
        dataset_ref = bigquery.Dataset(f"{project_id}.{dataset_id}")
        try:
            client.get_dataset(dataset_ref)
            msg = f"BigQuery dataset '{dataset_id}' already exists in project '{project_id}'."
            logger.info(msg)
            write_log(migration_id, msg)
            return {"message": msg}
        except Exception:
            client.create_dataset(dataset_ref)
            msg = f"BigQuery dataset '{dataset_id}' created in project '{project_id}'."
            logger.info(msg)
            write_log(migration_id, msg)
            return {"message": msg}
    except Exception as e:
        msg = f"BigQuery operation failed: {e}"
        logger.error(msg)
        write_log(migration_id, msg)
        raise HTTPException(status_code=500, detail=msg)