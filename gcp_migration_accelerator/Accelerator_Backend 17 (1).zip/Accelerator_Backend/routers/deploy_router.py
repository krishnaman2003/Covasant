import datetime
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, List
from google.cloud import storage, devtools
from google.cloud.devtools import cloudbuild_v1
from google.oauth2 import service_account
import os
import yaml
import tarfile
import io
import re
import difflib
import json
import logging

router = APIRouter(prefix="/api/deploy", tags=["Deploy"])

WORKSPACE_DIR = "Project_Workspace"

# Standard logger for app.log
logger = logging.getLogger(__name__)

def write_log(migration_id: str, message: str):
    log_dir = os.path.join(WORKSPACE_DIR, migration_id, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "activity.log")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    with open(log_path, "a") as log_file:
        log_file.write(f"{timestamp} - INFO - {message}\n")

def write_deployed_file(pipeline_dir: str, pipeline_name: str, build_id: str, status: str = "deployed"):
    deployed_path = os.path.join(pipeline_dir, f"{pipeline_name}.deployed")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = {
        "timestamp": timestamp,
        "pipeline_name": pipeline_name,
        "status": status,
        "cloud_build_job_id": build_id
    }
    with open(deployed_path, "a") as f:
        f.write(json.dumps(entry) + "\n")

class LiteralString(str):
    pass

def literal_presenter(dumper, data):
    return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')

yaml.add_representer(LiteralString, literal_presenter)

class CloudBuildConfigUpdate(BaseModel):
    beam_script: Optional[str] = None
    project: Optional[str] = None
    region: Optional[str] = None
    temp_location: Optional[str] = None
    staging_location: Optional[str] = None
    output_table: Optional[str] = None
    job_name: Optional[str] = None
    inputs: Optional[Dict[str, str]] = None

def _update_command_arg(command_str: str, arg_name: str, new_value: str) -> str:
    pattern = re.compile(f"(--{re.escape(arg_name)}\\s+)([^\\s\\\\]+)")
    new_command, num_replacements = pattern.subn(f"\\g<1>{new_value}", command_str)
    return new_command

def _update_beam_script(command_str: str, new_script: str) -> str:
    return re.sub(r"(python\s+)([^\s\\]+)", f"\\1{new_script}", command_str, count=1)

def analyze_csv_schema(blob, bucket_name, credentials):
    client = storage.Client(credentials=credentials)
    bucket = client.bucket(bucket_name)
    blob_data = bucket.blob(blob.name).download_as_text()
    rows = blob_data.splitlines()
    headers = rows[0].split(",") if rows else []
    return headers

def find_best_gcs_file_dynamic_with_schema(bucket_name, all_blobs, search_key, input_value, unified_json_schema, credentials):
    ext = os.path.splitext(input_value)[1].lower()
    filtered_blobs = [blob for blob in all_blobs if blob.name.lower().endswith(ext)] if ext else all_blobs
    search_key_clean = search_key.replace("_", "").replace("source", "").lower()
    all_filenames = [os.path.basename(blob.name).replace("_", "").lower() for blob in filtered_blobs]

    for blob in filtered_blobs:
        filename = os.path.basename(blob.name).replace("_", "").lower()
        if search_key_clean in filename:
            headers = analyze_csv_schema(blob, bucket_name, credentials)
            if set(unified_json_schema).issubset(set(headers)):
                return f"gs://{bucket_name}/{blob.name}"

    matches = difflib.get_close_matches(search_key_clean, all_filenames, n=1, cutoff=0.6)
    if matches:
        for blob in filtered_blobs:
            if os.path.basename(blob.name).replace("_", "").lower() == matches[0]:
                headers = analyze_csv_schema(blob, bucket_name, credentials)
                if set(unified_json_schema).issubset(set(headers)):
                    return f"gs://{bucket_name}/{blob.name}"

    return None

@router.get("/args/{migration_id}/{pipeline_name}", response_model=CloudBuildConfigUpdate)
def get_cloudyaml_args(migration_id: str, pipeline_name: str):
    path = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name, "cloudbuild.yaml")
    pipeline_dir = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)
    config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
    service_account_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "service_account.json")
    if not os.path.exists(path):
        msg = f"cloudbuild.yaml not found for fields GET in pipeline '{pipeline_name}'."
        logger.info(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=404, detail=f"cloudbuild.yaml for pipeline '{pipeline_name}' not found")
    try:
        with open(path, 'r') as f:
            data = yaml.safe_load(f)
        command_str = data['steps'][0]['args'][1]
        try:
            beam_script = next(f for f in os.listdir(pipeline_dir)
                               if f.endswith(".py") and "backup" not in f.lower())
        except StopIteration:
            beam_script = None
        def extract_arg(cmd, arg):
            match = re.search(f"--{re.escape(arg)}\\s+([^\\s\\\\]+)", cmd)
            return match.group(1) if match else None
        inputs = {}
        for match in re.finditer(r"--(input_[^\s\\]+)\s+([^\s\\]+)", command_str):
            arg_name = match.group(1)
            arg_value = match.group(2)
            inputs[arg_name] = arg_value
        if os.path.exists(config_path) and os.path.exists(service_account_path):
            with open(config_path, 'r') as f:
                gcp_config = yaml.safe_load(f)
            bucket_name = gcp_config.get("bucket_name")
            credentials = service_account.Credentials.from_service_account_file(service_account_path)
            client = storage.Client(credentials=credentials)
            all_blobs = list(client.list_blobs(bucket_name))

            unified_json_schema = []
            unified_json_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "unified.json")
            if os.path.exists(unified_json_path):
                with open(unified_json_path, 'r') as f:
                    unified_json = json.load(f)
                unified_json_schema = unified_json.get("schema", [])

            for arg_name, arg_value in inputs.items():
                if arg_value.startswith("gs://"):
                    search_key = arg_name.replace("input_", "").replace("Source", "").lower()
                    best_match = find_best_gcs_file_dynamic_with_schema(bucket_name, all_blobs, search_key, arg_value, unified_json_schema, credentials)
                    if not best_match:
                        input_basename = os.path.basename(arg_value).replace("_", "").lower()
                        best_match = find_best_gcs_file_dynamic_with_schema(bucket_name, all_blobs, input_basename, arg_value, unified_json_schema, credentials)
                    if best_match:
                        inputs[arg_name] = best_match
        result = CloudBuildConfigUpdate(
            beam_script=beam_script,
            project=extract_arg(command_str, "project"),
            region=extract_arg(command_str, "region"),
            temp_location=extract_arg(command_str, "temp_location"),
            staging_location=extract_arg(command_str, "staging_location"),
            output_table=extract_arg(command_str, "output_table"),
            job_name=extract_arg(command_str, "job_name"),
            inputs=inputs if inputs else None
        )
        msg = f"cloudbuild.yaml fields (beam_script from file, GCS input dynamic matching) returned for pipeline '{pipeline_name}'."
        logger.info(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        return result
    except Exception as e:
        msg = f"Failed to extract fields from YAML for pipeline '{pipeline_name}': {e}"
        logger.error(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=500, detail=f"Failed to extract fields: {e}")

@router.put("/args/{migration_id}/{pipeline_name}", status_code=200)
def update_cloudyaml_args(migration_id: str, pipeline_name: str, updates: CloudBuildConfigUpdate):
    path = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name, "cloudbuild.yaml")
    if not os.path.exists(path):
        msg = f"cloudbuild.yaml not found for update in pipeline '{pipeline_name}'."
        logger.info(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=404, detail=f"cloudbuild.yaml for pipeline '{pipeline_name}' not found")
    try:
        with open(path, 'r') as f:
            data = yaml.safe_load(f)
        command_str = data['steps'][0]['args'][1]
        update_map = updates.dict(exclude_unset=True)
        if "beam_script" in update_map and update_map["beam_script"]:
            command_str = _update_beam_script(command_str, update_map["beam_script"])
        for arg_name, new_value in update_map.items():
            if arg_name not in ("inputs", "beam_script"):
                command_str = _update_command_arg(command_str, arg_name, new_value)
        if "inputs" in update_map and update_map["inputs"]:
            for input_arg_name, input_arg_value in update_map["inputs"].items():
                command_str = _update_command_arg(command_str, input_arg_name, input_arg_value)
        data['steps'][0]['args'][1] = LiteralString(command_str)
        with open(path, "w") as f:
            yaml.dump(data, f, sort_keys=False)
        msg = f"cloudbuild.yaml updated for pipeline '{pipeline_name}'."
        logger.info(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
    except Exception as e:
        msg = f"Failed to update YAML for pipeline '{pipeline_name}': {e}"
        logger.error(f"[{migration_id}] {msg}")
        write_log(migration_id, msg)
        raise HTTPException(status_code=500, detail=f"An error occurred: {e}")
    return {"message": f"Pipeline config for '{pipeline_name}' updated successfully."}

# @router.post("/{migration_id}/{pipeline_name}")
# def deploy_dataflow_pipeline(migration_id: str, pipeline_name: str):
#     pipeline_dir = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)
#     yaml_local_path = os.path.join(pipeline_dir, "cloudbuild.yaml")
#     try:
#         beam_script_name = next(f for f in os.listdir(pipeline_dir) if f.endswith(".py"))
#         beam_script_local_path = os.path.join(pipeline_dir, beam_script_name)
#         msg = f"Found beam script: {beam_script_name} in pipeline {pipeline_name}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#     except StopIteration:
#         msg = f"Beam script (.py file) not found in {pipeline_dir}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail=f"Beam script (.py file) not found in {pipeline_dir}")
#     if not os.path.exists(yaml_local_path):
#         msg = f"cloudbuild.yaml not found in {pipeline_dir}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail=f"cloudbuild.yaml not found in {pipeline_dir}")
#     config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
#     if not os.path.exists(config_path):
#         msg = f"gcp_config.json not found for migration {migration_id}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail=f"gcp_config.json not found for migration {migration_id}")
#     with open(config_path, 'r') as f:
#         gcp_config = yaml.safe_load(f)
#     project_id = gcp_config.get("project_id")
#     bucket_name = gcp_config.get("bucket_name")
#     if not project_id or not bucket_name:
#         msg = "project_id and bucket_name must be in gcp_config.json"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=400, detail="project_id and bucket_name must be in gcp_config.json")
#     service_account_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "service_account.json")
#     if not os.path.exists(service_account_path):
#         msg = "Service account file not found."
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail="Service account file not found.")
#     credentials = service_account.Credentials.from_service_account_file(service_account_path)
#     storage_client = storage.Client(credentials=credentials)
#     cloudbuild_client = cloudbuild_v1.CloudBuildClient(credentials=credentials)
#     tar_stream = io.BytesIO()
#     with tarfile.open(fileobj=tar_stream, mode='w:gz') as tar:
#         msg = f"Packaging source files for pipeline {pipeline_name}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         tar.add(yaml_local_path, arcname="cloudbuild.yaml")
#         tar.add(beam_script_local_path, arcname=beam_script_name)
#     tar_stream.seek(0)
#     gcs_source_path = f"dataflow_deployments/{pipeline_name}/source.tar.gz"
#     bucket = storage_client.bucket(bucket_name)
#     blob = bucket.blob(gcs_source_path)
#     blob.upload_from_file(tar_stream, content_type='application/gzip')
#     msg = f"Uploaded source to gs://{bucket_name}/{gcs_source_path}"
#     logger.info(f"[{migration_id}] {msg}")
#     write_log(migration_id, msg)
#     with open(yaml_local_path, 'r') as f:
#         msg = f"Reading cloudbuild.yaml for pipeline {pipeline_name}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         build_config = yaml.safe_load(f)
#     build = cloudbuild_v1.Build()
#     build.source = {"storage_source": {"bucket": bucket_name, "object_": gcs_source_path}}
#     for step in build_config["steps"]:
#         msg = f"Adding build step: {step.get('name')}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         build.steps.append(cloudbuild_v1.BuildStep(
#             name=step.get("name"),
#             entrypoint=step.get("entrypoint"),
#             args=step.get("args", [])
#         ))
#     try:
#         operation = cloudbuild_client.create_build(project_id=project_id, build=build)
#         build_id = operation.metadata.build.id
#         log_url = operation.metadata.build.log_url
#         msg = f"Started Cloud Build job: {build_id} for pipeline {pipeline_name}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         write_deployed_file(
#             pipeline_dir, pipeline_name, f"{build_id}"
#         )
#         return {
#             "message": f"Pipeline '{pipeline_name}' deployed successfully.",
#             "build_id": build_id,
#             "log_url": log_url,
#             "gcs_source_path": f"gs://{bucket_name}/{gcs_source_path}"
#         }
#     except Exception as e:
#         msg = f"Failed to trigger Cloud Build: {e}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=500, detail=f"Failed to trigger Cloud Build: {e}")

@router.get("/pipelines/{migration_id}")
def list_pipelines_with_status(migration_id: str):
    dataflow_dir = os.path.join(WORKSPACE_DIR, migration_id, "dataflow")
    if not os.path.exists(dataflow_dir):
        raise HTTPException(status_code=404, detail="Dataflow directory not found")
    pipelines = []
    for name in os.listdir(dataflow_dir):
        pipeline_path = os.path.join(dataflow_dir, name)
        if os.path.isdir(pipeline_path):
            deployed_file = os.path.join(pipeline_path, f"{name}.deployed")
            is_deployed = os.path.exists(deployed_file)
            pipelines.append({
                "pipeline_name": name,
                "deployed": is_deployed
            })
    return {"pipelines": pipelines}

@router.get("/pipeline/{migration_id}/{pipeline_name}/deployed")
def get_pipeline_deployed_details(migration_id: str, pipeline_name: str):
    deployed_file = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name, f"{pipeline_name}.deployed")
    if not os.path.exists(deployed_file):
        raise HTTPException(status_code=404, detail="Deployed file not found")
    with open(deployed_file, "r") as f:
        lines = [json.loads(line) for line in f if line.strip()]
    return {"deployments": lines}
 