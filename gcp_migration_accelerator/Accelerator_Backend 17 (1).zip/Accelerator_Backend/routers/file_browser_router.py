from fastapi import APIRouter, HTTPException, Query
import os
import datetime
from typing import List, Dict, Optional
from google.cloud import storage
from google.oauth2 import service_account
import json
import time

router = APIRouter(prefix="/api/browse", tags=["File Explorer"])

# BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# WORKSPACE_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "project_workspace"))
WORKSPACE_DIR = "Project_Workspace"

def write_log(migration_id: str, message: str):
    log_dir = os.path.join(WORKSPACE_DIR, migration_id, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "activity.log")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    with open(log_path, "a") as log_file:
        log_file.write(f"{timestamp} - INFO - {message}\n")

def get_folder_tree(path):
    """
    Recursively builds a tree of folders and files starting from 'path'.
    """
    items = []
    for entry in sorted(os.listdir(path)):
        entry_path = os.path.join(path, entry)
        if os.path.isdir(entry_path):
            items.append({
                "name": entry,
                "type": "folder",
                "children": get_folder_tree(entry_path)
            })
        elif os.path.isfile(entry_path):
            if "_backup" in entry or entry.startswith("review_"):
                continue 
            items.append({
                "name": entry,
                "type": "file"
            })
    return items

def build_gcs_tree(object_names):
    """Builds a nested folder/file tree from a list of GCS object names."""
    tree = {}
    for obj in object_names:
        parts = obj.split('/')
        node = tree
        for i, part in enumerate(parts):
            if i == len(parts) - 1 and part != '':
                node.setdefault(part, {"type": "file"})
            elif part != '':
                node = node.setdefault(part, {"type": "folder", "children": {}})["children"]
    def to_list(node):
        result = []
        for name, value in sorted(node.items()):
            if value["type"] == "file":
                result.append({"name": name, "type": "file"})
            else:
                result.append({"name": name, "type": "folder", "children": to_list(value["children"])})
        return result
    return to_list(tree)


@router.get("/dataflow-tree/{migration_id}")
def browse_dataflow_tree(migration_id: str):
    """
    Recursively lists the entire dataflow directory structure (all subfolders and files).
    """
    base_path = os.path.join(WORKSPACE_DIR, migration_id, "dataflow")
    if not os.path.isdir(base_path):
        write_log(migration_id, f"Dataflow directory for migration '{migration_id}' not found.")
        raise HTTPException(status_code=404, detail=f"Dataflow directory for migration '{migration_id}' not found.")
    try:
        tree = get_folder_tree(base_path)
        write_log(migration_id, f"Browsed full dataflow tree.")
        return {
            "migration_id": migration_id,
            "path": "dataflow",
            "tree": tree
        }
    except Exception as e:
        write_log(migration_id, f"Error reading dataflow directory: {e}")
        raise HTTPException(status_code=500, detail=f"Error reading dataflow directory: {str(e)}")

@router.get("/gcpbucket-tree/{migration_id}/{bucket_name}")
def browse_gcp_bucket_tree(migration_id: str, bucket_name: str):
    """
    Recursively lists the entire GCS bucket structure (all subfolders and files) for the given migration_id and bucket_name.
    """
    sa_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "service_account.json")
    if not os.path.exists(sa_path):
        write_log(migration_id, f"Service account file not found for bucket '{bucket_name}'.")
        raise HTTPException(status_code=404, detail="Service account file not found for this migration.")
    try:
        credentials = service_account.Credentials.from_service_account_file(sa_path)
        client = storage.Client(credentials=credentials, project=credentials.project_id)
        blobs = client.list_blobs(bucket_name)
        object_names = [blob.name for blob in blobs]
        tree = build_gcs_tree(object_names)
        write_log(migration_id, f"Browsed GCS bucket tree for bucket '{bucket_name}'.")
        return {
            "migration_id": migration_id,
            "bucket_name": bucket_name,
            "tree": tree
        }
    except Exception as e:
        write_log(migration_id, f"Failed to browse bucket '{bucket_name}': {e}")
        raise HTTPException(status_code=500, detail=f"Failed to browse bucket: {e}")
    


@router.get("/migration-status")
def get_migration_status():
    """
    Returns a list of all migration folders with their source, target, created_at, and updated_at.
    """
    results = []
    for migration_id in os.listdir(WORKSPACE_DIR):
        migration_path = os.path.join(WORKSPACE_DIR, migration_id)
        if not os.path.isdir(migration_path):
            continue

        config_path = os.path.join(migration_path, "configuration", "config.json")
        if not os.path.exists(config_path):
            continue

        try:
            with open(config_path, "r") as f:
                config = json.load(f)
            source = config.get("source", "")
            target = config.get("target", "")
        except Exception:
            continue

        # Get timestamps
        try:
            created_at = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getctime(migration_path)))
            updated_at = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(migration_path)))
        except Exception:
            created_at = None
            updated_at = None

        results.append({
            "migration_id": migration_id,
            "source": source,
            "target": target,
            "created_at": created_at,
            "updated_at": updated_at
        })
    return results