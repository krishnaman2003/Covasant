from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel
from google.cloud import storage
from google.cloud.devtools import cloudbuild_v1
from google.oauth2 import service_account
from google.cloud.dataflow_v1beta3 import FlexTemplatesServiceClient, LaunchFlexTemplateRequest, LaunchFlexTemplateParameter, FlexTemplateRuntimeEnvironment
import os
import yaml
import json
import re
import tarfile
import io
from typing import Dict
import time
import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Pydantic Model for Run Request ---
class FlexTemplateRunRequest(BaseModel):
    parameters: Dict[str, str]
    job_name: str

# --- Router Setup ---
router = APIRouter(prefix="/api/flex-template", tags=["Dataflow Flex Template"])

# --- Path Setup ---
WORKSPACE_DIR = "Project_Workspace"

def write_log(migration_id: str, message: str):
    log_dir = os.path.join(WORKSPACE_DIR, migration_id, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "activity.log")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    with open(log_path, "a") as log_file:
        log_file.write(f"{timestamp} - INFO - {message}\n")

def write_deployed_file(pipeline_dir: str, pipeline_name: str, build_id: str, job_id: str, job_url: str, log_url: str, status: str = "deployed"):
    deployed_path = os.path.join(pipeline_dir, f"{pipeline_name}.deployed")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = {
        "timestamp": timestamp,
        "pipeline_name": pipeline_name,
        "status": status,
        "cloud_build_job_id": build_id,
        "dataflow_job_id": job_id,
        "dataflow_job_url": job_url,
        "cloud_build_log_url": log_url
    }
    with open(deployed_path, "a") as f:
        f.write(json.dumps(entry) + "\n")

def _build_label(param_name: str) -> str:
    return " ".join(word.capitalize() for word in param_name.split("_"))

def _generate_help_text(param_name: str, example_value: str) -> str:
    example_value = example_value.strip()
    if "gs://" in example_value:
        return f"GCS path to the input file. Example: {example_value}"
    if "table" in param_name:
        return f"BigQuery table specification. Format: project:dataset.table. Example: {example_value}"
    return f"Example: {example_value}"

def _generate_metadata_from_yaml(yaml_path: str, output_path: str, migration_id: str) -> dict:
    try:
        with open(yaml_path, 'r') as f:
            data = yaml.safe_load(f)
    except FileNotFoundError:
        write_log(migration_id, f"cloudbuild.yaml not found at {yaml_path}")
        raise HTTPException(status_code=404, detail=f"cloudbuild.yaml not found at {yaml_path}")
    except Exception as e:
        write_log(migration_id, f"Failed to read or parse YAML: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to read or parse YAML: {e}")

    steps = data.get("steps", [])
    job_name = None
    parameters = []
    for step in steps:
        if step.get('name', '').startswith('python'):
            command_string = step.get('args', [])[-1]
            matches = re.findall(r"--([a-zA-Z0-9_]+)\s+([^\s\\]+)", command_string)
            for key, value in matches:
                if key == "job_name":
                    job_name = value
                    continue
                if key in ['runner', 'project', 'region', 'temp_location', 'staging_location']:
                    continue
                parameters.append({"name": key, "label": _build_label(key), "helpText": _generate_help_text(key, value)})
            break
    if not job_name:
        job_name = os.path.basename(os.path.dirname(yaml_path)) + "-template"
    metadata_content = {"name": job_name, "description": "Dataflow Flex Template generated from cloudbuild.yaml.", "parameters": parameters}
    with open(output_path, "w") as f:
        json.dump(metadata_content, f, indent=2)
    write_log(migration_id, f"Generated metadata.json at {output_path}")
    return metadata_content



@router.post("/generate-build-run/{migration_id}/{pipeline_name}", status_code=202)
def generate_build_run_flex_template(
    migration_id: str,
    pipeline_name: str,
    deploy_as_job: bool = False
):
    """
    If deploy_as_job=False: Runs Flex Template build and launch logic.
    If deploy_as_job=True: Runs deploy logic only.
    """
    pipeline_dir = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)

    if not os.path.exists(pipeline_dir):
        write_log(migration_id, f"Pipeline directory not found for pipeline: {pipeline_name}")
        raise HTTPException(status_code=404, detail=f"Pipeline directory not found: {pipeline_name}")

    if not deploy_as_job:
        # --- DEPLOY LOGIC ---
        yaml_local_path = os.path.join(pipeline_dir, "cloudbuild.yaml")
        try:
            beam_script_name = next(f for f in os.listdir(pipeline_dir) if f.endswith(".py") and "backup" not in f.lower())
            beam_script_local_path = os.path.join(pipeline_dir, beam_script_name)
            write_log(migration_id, f"Found beam script: {beam_script_name} for pipeline: {pipeline_name}")
        except StopIteration:
            write_log(migration_id, f"Beam script (.py file) not found for pipeline: {pipeline_name}")
            raise HTTPException(status_code=404, detail=f"Beam script (.py file) not found in {pipeline_dir}")
        if not os.path.exists(yaml_local_path):
            write_log(migration_id, f"cloudbuild.yaml not found for pipeline: {pipeline_name}")
            raise HTTPException(status_code=404, detail=f"cloudbuild.yaml not found in {pipeline_dir}")
        config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
        if not os.path.exists(config_path):
            write_log(migration_id, f"gcp_config.json not found for migration: {migration_id}")
            raise HTTPException(status_code=404, detail=f"gcp_config.json not found for migration {migration_id}")
        with open(config_path, 'r') as f:
            gcp_config = yaml.safe_load(f)
        project_id = gcp_config.get("project_id")
        bucket_name = gcp_config.get("bucket_name")
        if not project_id or not bucket_name:
            write_log(migration_id, "project_id and bucket_name must be in gcp_config.json")
            raise HTTPException(status_code=400, detail="project_id and bucket_name must be in gcp_config.json")
        service_account_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "service_account.json")
        if not os.path.exists(service_account_path):
            write_log(migration_id, "Service account file not found for migration: {migration_id}")
            raise HTTPException(status_code=404, detail="Service account file not found.")
        credentials = service_account.Credentials.from_service_account_file(service_account_path)
        storage_client = storage.Client(credentials=credentials)
        cloudbuild_client = cloudbuild_v1.CloudBuildClient(credentials=credentials)
        tar_stream = io.BytesIO()
        with tarfile.open(fileobj=tar_stream, mode='w:gz') as tar:
            write_log(migration_id, f"Packaging source files for pipeline: {pipeline_name}")
            tar.add(yaml_local_path, arcname="cloudbuild.yaml")
            tar.add(beam_script_local_path, arcname=beam_script_name)
        tar_stream.seek(0)
        gcs_source_path = f"dataflow_deployments/{pipeline_name}/source.tar.gz"
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(gcs_source_path)
        blob.upload_from_file(tar_stream, content_type='application/gzip')
        write_log(migration_id, f"Uploaded source to gs://{bucket_name}/{gcs_source_path} for pipeline: {pipeline_name}")
        with open(yaml_local_path, 'r') as f:
            write_log(migration_id, f"Reading cloudbuild.yaml for pipeline: {pipeline_name}")
            build_config = yaml.safe_load(f)
        build = cloudbuild_v1.Build()
        build.source = {"storage_source": {"bucket": bucket_name, "object_": gcs_source_path}}
        for step in build_config["steps"]:
            write_log(migration_id, f"Adding build step: {step.get('name')} for pipeline: {pipeline_name}")
            build.steps.append(cloudbuild_v1.BuildStep(
                name=step.get("name"),
                entrypoint=step.get("entrypoint"),
                args=step.get("args", [])
            ))
        try:
            operation = cloudbuild_client.create_build(project_id=project_id, build=build)
            build_id = operation.metadata.build.id
            log_url = operation.metadata.build.log_url
            write_log(migration_id, f"Started Cloud Build job: {build_id} for pipeline: {pipeline_name}")
            write_deployed_file(
                pipeline_dir, pipeline_name, f"{build_id}", "", "", log_url, status="deployed"
            )
            return {
                "message": f"Pipeline '{pipeline_name}' deployed successfully.",
                "build_id": build_id,
                "log_url": log_url,
                "gcs_source_path": f"gs://{bucket_name}/{gcs_source_path}"
            }
        except Exception as e:
            write_log(migration_id, f"Failed to trigger Cloud Build for pipeline: {pipeline_name}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to trigger Cloud Build: {e}")

    else:
        # --- FLEX TEMPLATE BUILD/RUN LOGIC ---
        yaml_path = os.path.join(pipeline_dir, "cloudbuild.yaml")
        metadata_path = os.path.join(pipeline_dir, "metadata.json")
        try:
            generated_metadata = _generate_metadata_from_yaml(yaml_path, metadata_path, migration_id)
            write_log(migration_id, f"Generated metadata.json for pipeline: {pipeline_name}")
        except Exception as e:
            write_log(migration_id, f"Failed to generate metadata.json for pipeline: {pipeline_name}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to generate metadata.json: {e}")

        config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
        if not os.path.exists(config_path):
            write_log(migration_id, f"config.json not found for migration: {migration_id}")
            raise HTTPException(status_code=404, detail=f"config.json not found for migration {migration_id}")

        with open(config_path, 'r') as f:
            config = json.load(f)

        project_id = config.get("project_id")
        bucket_name = config.get("bucket_name")
        region = config.get("region")
        if not all([project_id, bucket_name, region]):
            write_log(migration_id, "project_id, bucket_name, and region must be in config.json")
            raise HTTPException(status_code=400, detail="project_id, bucket_name, and region must be in config.json")

        try:
            beam_script_name = next(f for f in os.listdir(pipeline_dir) if f.endswith(".py"))
            beam_script_path = os.path.join(pipeline_dir, beam_script_name)
            write_log(migration_id, f"Found beam script: {beam_script_name} for pipeline: {pipeline_name}")
        except StopIteration:
            write_log(migration_id, f"Beam script (.py file) not found for pipeline: {pipeline_name}")
            raise HTTPException(status_code=404, detail=f"Beam script (.py file) not found in {pipeline_dir}")

        service_account_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "service_account.json")
        if not os.path.exists(service_account_path):
            write_log(migration_id, "Service account file not found for migration: {migration_id}")
            raise HTTPException(status_code=404, detail="Service account file not found.")

        credentials = service_account.Credentials.from_service_account_file(service_account_path)
        storage_client = storage.Client(credentials=credentials)
        cloudbuild_client = cloudbuild_v1.CloudBuildClient(credentials=credentials)
        dataflow_client = FlexTemplatesServiceClient(credentials=credentials)

        dockerfile_content = f"""FROM gcr.io/dataflow-templates-base/python3-template-launcher-base
ARG WORKDIR=/dataflow/template
RUN mkdir -p ${{WORKDIR}}
WORKDIR ${{WORKDIR}}
COPY requirements.txt .
COPY {beam_script_name} .
RUN pip install --no-cache-dir -r requirements.txt
ENV FLEX_TEMPLATE_PYTHON_PY_FILE=${{WORKDIR}}/{beam_script_name}
"""
        requirements_content = "apache-beam[gcp]==2.66\n"

        tar_stream = io.BytesIO()
        with tarfile.open(fileobj=tar_stream, mode='w:gz') as tar:
            tar.add(beam_script_path, arcname=beam_script_name)
            tar.add(metadata_path, arcname="metadata.json")
            dockerfile_info = tarfile.TarInfo(name="Dockerfile")
            dockerfile_bytes = dockerfile_content.encode('utf-8')
            dockerfile_info.size = len(dockerfile_bytes)
            tar.addfile(dockerfile_info, io.BytesIO(dockerfile_bytes))
            reqs_info = tarfile.TarInfo(name="requirements.txt")
            reqs_bytes = requirements_content.encode('utf-8')
            reqs_info.size = len(reqs_bytes)
            tar.addfile(reqs_info, io.BytesIO(reqs_bytes))
        tar_stream.seek(0)

        gcs_source_path = f"flex-template-builds/{pipeline_name}/source.tar.gz"
        blob = storage_client.bucket(bucket_name).blob(gcs_source_path)
        blob.upload_from_file(tar_stream, content_type='application/gzip')
        write_log(migration_id, f"Uploaded flex template source to gs://{bucket_name}/{gcs_source_path} for pipeline: {pipeline_name}")

        template_path = f"gs://{bucket_name}/templates/{pipeline_name}.json"
        docker_name = re.sub(r'[^a-z0-9-]', '-', pipeline_name.lower())
        image_path = f"gcr.io/{project_id}/{docker_name}:latest"
        build = cloudbuild_v1.Build()
        build.source = {"storage_source": {"bucket": bucket_name, "object_": gcs_source_path}}
        build.steps = [
            cloudbuild_v1.BuildStep(
                name='gcr.io/cloud-builders/docker',
                args=['build', '-t', image_path, '.']
            ),
            cloudbuild_v1.BuildStep(
                name='gcr.io/cloud-builders/docker',
                args=['push', image_path]
            ),
            cloudbuild_v1.BuildStep(
                name='gcr.io/google.com/cloudsdktool/cloud-sdk',
                entrypoint='gcloud',
                args=[
                    'dataflow', 'flex-template', 'build', template_path,
                    f'--image={image_path}',
                    '--sdk-language=PYTHON',
                    '--metadata-file=metadata.json',
                ]
            )
        ]
        build.timeout = {"seconds": 1200}

        try:
            operation = cloudbuild_client.create_build(project_id=project_id, build=build)
            build_id = operation.metadata.build.id
            log_url = operation.metadata.build.log_url
            write_log(migration_id, f"Started Cloud Build job: {build_id} for flex template pipeline: {pipeline_name}")
        except Exception as e:
            write_log(migration_id, f"Failed to trigger Cloud Build for Flex Template pipeline: {pipeline_name}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to trigger Cloud Build for Flex Template: {e}")

        while True:
            build_status = cloudbuild_client.get_build(project_id=project_id, id=build_id)
            if build_status.status == cloudbuild_v1.Build.Status.SUCCESS:
                write_log(migration_id, f"Cloud Build job {build_id} succeeded for flex template pipeline: {pipeline_name}")
                break
            elif build_status.status in [cloudbuild_v1.Build.Status.FAILURE, cloudbuild_v1.Build.Status.CANCELLED]:
                write_log(migration_id, f"Flex Template build failed for pipeline: {pipeline_name}: {build_status.status}")
                raise HTTPException(status_code=500, detail=f"Flex Template build failed: {build_status.status}")
            time.sleep(10)

        try:
            parameters = {}
            for param in generated_metadata.get("parameters", []):
                help_text = param.get("helpText", "")
                if param["name"] == "output_table":
                    match = re.search(r'Example:\s*([^"]+)', help_text)
                    if match:
                        parameters[param["name"]] = match.group(1)
                else:
                    match = re.search(r'gs://[^\s"]+', help_text)
                    if match:
                        parameters[param["name"]] = match.group(0)
            write_log(migration_id, f"Launching Dataflow Flex Template job for pipeline: {pipeline_name} with parameters: {parameters}")

            launch_request = LaunchFlexTemplateRequest(
                project_id=project_id,
                location=region,
                launch_parameter=LaunchFlexTemplateParameter(
                    job_name=generated_metadata["name"],
                    container_spec_gcs_path=template_path,
                    parameters=parameters,
                ),
            )
            response = dataflow_client.launch_flex_template(request=launch_request)
            job_id = response.job.id
            job_url = f"https://console.cloud.google.com/dataflow/jobs/{region}/{job_id}?project={project_id}"
            write_log(migration_id, f"Successfully launched Dataflow Flex Template job: {job_id} for pipeline: {pipeline_name}")

            write_deployed_file(
                pipeline_dir=pipeline_dir,
                pipeline_name=pipeline_name,
                build_id=build_id,
                job_id=job_id,
                job_url=job_url,
                log_url=log_url,
                status="deployed"
            )

            return {
                "message": "Successfully generated metadata.json, built Flex Template, and launched Dataflow job.",
                "build_id": build_id,
                "log_url": log_url,
                "job_id": job_id,
                "job_url": job_url
            }
        except Exception as e:
            write_log(migration_id, f"Failed to launch Dataflow job for pipeline: {pipeline_name}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to launch Dataflow job: {e}")

# @router.post("/generate-build-run/{migration_id}/{pipeline_name}", status_code=202)
# def generate_build_run_flex_template(migration_id: str, pipeline_name: str):
#     """
#     Combines metadata generation, Flex Template build, and execution into a single API.
#     Waits for the build process to complete before running the Flex Template.
#     """
#     # Step 1: Generate metadata.json
#     pipeline_dir = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)
#     yaml_path = os.path.join(pipeline_dir, "cloudbuild.yaml")
#     metadata_path = os.path.join(pipeline_dir, "metadata.json")

#     if not os.path.exists(pipeline_dir):
#         write_log(migration_id, f"Pipeline directory not found: {pipeline_dir}")
#         raise HTTPException(status_code=404, detail=f"Pipeline directory not found: {pipeline_dir}")

#     try:
#         generated_metadata = _generate_metadata_from_yaml(yaml_path, metadata_path, migration_id)
#     except Exception as e:
#         write_log(migration_id, f"Failed to generate metadata.json: {e}")
#         raise HTTPException(status_code=500, detail=f"Failed to generate metadata.json: {e}")

#     # Step 2: Build Flex Template
#     config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
#     if not os.path.exists(config_path):
#         write_log(migration_id, f"config.json not found for migration {migration_id}")
#         raise HTTPException(status_code=404, detail=f"config.json not found for migration {migration_id}")

#     with open(config_path, 'r') as f:
#         config = json.load(f)

#     project_id = config.get("project_id")
#     bucket_name = config.get("bucket_name")
#     region = config.get("region")
#     if not all([project_id, bucket_name, region]):
#         write_log(migration_id, "project_id, bucket_name, and region must be in config.json")
#         raise HTTPException(status_code=400, detail="project_id, bucket_name, and region must be in config.json")

#     try:
#         beam_script_name = next(f for f in os.listdir(pipeline_dir) if f.endswith(".py"))
#         beam_script_path = os.path.join(pipeline_dir, beam_script_name)
#     except StopIteration:
#         write_log(migration_id, f"Beam script (.py file) not found in {pipeline_dir}")
#         raise HTTPException(status_code=404, detail=f"Beam script (.py file) not found in {pipeline_dir}")

#     # Load service account for this migration
#     service_account_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "service_account.json")
#     if not os.path.exists(service_account_path):
#         write_log(migration_id, "Service account file not found.")
#         raise HTTPException(status_code=404, detail="Service account file not found.")

#     credentials = service_account.Credentials.from_service_account_file(service_account_path)
#     storage_client = storage.Client(credentials=credentials)
#     cloudbuild_client = cloudbuild_v1.CloudBuildClient(credentials=credentials)
#     dataflow_client = FlexTemplatesServiceClient(credentials=credentials)

#     # Generate Dockerfile and requirements.txt in memory
#     dockerfile_content = f"""FROM gcr.io/dataflow-templates-base/python3-template-launcher-base
# ARG WORKDIR=/dataflow/template
# RUN mkdir -p ${{WORKDIR}}
# WORKDIR ${{WORKDIR}}
# COPY requirements.txt .
# COPY {beam_script_name} .
# RUN pip install --no-cache-dir -r requirements.txt
# ENV FLEX_TEMPLATE_PYTHON_PY_FILE=${{WORKDIR}}/{beam_script_name}
# """
#     requirements_content = "apache-beam[gcp]==2.66\n"

#     # Package source files into an in-memory tarball
#     tar_stream = io.BytesIO()
#     with tarfile.open(fileobj=tar_stream, mode='w:gz') as tar:
#         tar.add(beam_script_path, arcname=beam_script_name)
#         tar.add(metadata_path, arcname="metadata.json")
#         dockerfile_info = tarfile.TarInfo(name="Dockerfile")
#         dockerfile_bytes = dockerfile_content.encode('utf-8')
#         dockerfile_info.size = len(dockerfile_bytes)
#         tar.addfile(dockerfile_info, io.BytesIO(dockerfile_bytes))
#         reqs_info = tarfile.TarInfo(name="requirements.txt")
#         reqs_bytes = requirements_content.encode('utf-8')
#         reqs_info.size = len(reqs_bytes)
#         tar.addfile(reqs_info, io.BytesIO(reqs_bytes))
#     tar_stream.seek(0)

#     # Upload the tarball to GCS
#     gcs_source_path = f"flex-template-builds/{pipeline_name}/source.tar.gz"
#     blob = storage_client.bucket(bucket_name).blob(gcs_source_path)
#     blob.upload_from_file(tar_stream, content_type='application/gzip')
#     write_log(migration_id, f"Uploaded flex template source to gs://{bucket_name}/{gcs_source_path}")

#     # Construct the Build request object
#     template_path = f"gs://{bucket_name}/templates/{pipeline_name}.json"
#     docker_name = re.sub(r'[^a-z0-9-]', '-', pipeline_name.lower())
#     image_path = f"gcr.io/{project_id}/{docker_name}:latest"
#     build = cloudbuild_v1.Build()
#     build.source = {"storage_source": {"bucket": bucket_name, "object_": gcs_source_path}}
#     build.steps = [
#         # Step to build the Docker image
#         cloudbuild_v1.BuildStep(
#             name='gcr.io/cloud-builders/docker',
#             args=[
#                 'build',
#                 '-t', image_path,
#                 '.'
#             ]
#         ),
#         # Step to push the Docker image to the Container Registry
#         cloudbuild_v1.BuildStep(
#             name='gcr.io/cloud-builders/docker',
#             args=[
#                 'push',
#                 image_path
#             ]
#         ),
#         # Step to build the Flex Template
#         cloudbuild_v1.BuildStep(
#             name='gcr.io/google.com/cloudsdktool/cloud-sdk',
#             entrypoint='gcloud',
#             args=[
#                 'dataflow', 'flex-template', 'build', template_path,
#                 f'--image={image_path}',
#                 '--sdk-language=PYTHON',
#                 '--metadata-file=metadata.json',
#             ]
#         )
#     ]
#     build.timeout = {"seconds": 1200}  # 20 minutes

#     # Trigger the Cloud Build job
#     try:
#         operation = cloudbuild_client.create_build(project_id=project_id, build=build)
#         build_id = operation.metadata.build.id
#         log_url = operation.metadata.build.log_url
#         write_log(migration_id, f"Started Cloud Build job: {build_id} for flex template pipeline {pipeline_name}")
#     except Exception as e:
#         write_log(migration_id, f"Failed to trigger Cloud Build for Flex Template: {e}")
#         raise HTTPException(status_code=500, detail=f"Failed to trigger Cloud Build for Flex Template: {e}")

#     # Step 3: Wait for Build Completion
#     while True:
#         build_status = cloudbuild_client.get_build(project_id=project_id, id=build_id)
#         if build_status.status == cloudbuild_v1.Build.Status.SUCCESS:
#             write_log(migration_id, f"Cloud Build job {build_id} succeeded for flex template pipeline {pipeline_name}")
#             break
#         elif build_status.status in [cloudbuild_v1.Build.Status.FAILURE, cloudbuild_v1.Build.Status.CANCELLED]:
#             write_log(migration_id, f"Flex Template build failed: {build_status.status}")
#             raise HTTPException(status_code=500, detail=f"Flex Template build failed: {build_status.status}")
#         time.sleep(10)  # Poll every 10 seconds

#     # Step 4: Run the Flex Template
#     try:
#         # Extract parameters from metadata
#         parameters = {}
#         for param in generated_metadata.get("parameters", []):
#             help_text = param.get("helpText", "")
#             if param["name"] == "output_table":
#                 match = re.search(r'Example:\s*([^"]+)', help_text)
#                 if match:
#                     parameters[param["name"]] = match.group(1)
#             else:
#                 match = re.search(r'gs://[^\s"]+', help_text)
#                 if match:
#                     parameters[param["name"]] = match.group(0)
#         write_log(migration_id, f"Launching Dataflow Flex Template job for pipeline {pipeline_name} with parameters: {parameters}")

#         launch_request = LaunchFlexTemplateRequest(
#             project_id=project_id,
#             location=region,
#             launch_parameter=LaunchFlexTemplateParameter(
#                 job_name=generated_metadata["name"],
#                 container_spec_gcs_path=template_path,
#                 parameters=parameters,
#             ),
#         )
#         response = dataflow_client.launch_flex_template(request=launch_request)
#         job_id = response.job.id
#         job_url = f"https://console.cloud.google.com/dataflow/jobs/{region}/{job_id}?project={project_id}"
#         write_log(migration_id, f"Successfully launched Dataflow Flex Template job: {job_id} for pipeline {pipeline_name}")

#         # --- Write .deployed file ---
#         write_deployed_file(
#             pipeline_dir=pipeline_dir,
#             pipeline_name=pipeline_name,
#             build_id=build_id,
#             job_id=job_id,
#             job_url=job_url,
#             log_url=log_url,
#             status="deployed"
#         )

#         return {
#             "message": "Successfully generated metadata.json, built Flex Template, and launched Dataflow job.",
#             "build_id": build_id,
#             "log_url": log_url,
#             "job_id": job_id,
#             "job_url": job_url
#         }
#     except Exception as e:
#         write_log(migration_id, f"Failed to launch Dataflow job: {e}")
#         raise HTTPException(status_code=500, detail=f"Failed to launch Dataflow job: {e}")
    


# @router.post("/{migration_id}/{pipeline_name}")
# def deploy_dataflow_pipeline(migration_id: str, pipeline_name: str):
#     pipeline_dir = os.path.join(WORKSPACE_DIR, migration_id, "dataflow", pipeline_name)
#     yaml_local_path = os.path.join(pipeline_dir, "cloudbuild.yaml")
#     try:
#         beam_script_name = next(f for f in os.listdir(pipeline_dir) if f.endswith(".py"))
#         beam_script_local_path = os.path.join(pipeline_dir, beam_script_name)
#         msg = f"Found beam script: {beam_script_name} in pipeline {pipeline_name}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#     except StopIteration:
#         msg = f"Beam script (.py file) not found in {pipeline_dir}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail=f"Beam script (.py file) not found in {pipeline_dir}")
#     if not os.path.exists(yaml_local_path):
#         msg = f"cloudbuild.yaml not found in {pipeline_dir}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail=f"cloudbuild.yaml not found in {pipeline_dir}")
#     config_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "config.json")
#     if not os.path.exists(config_path):
#         msg = f"gcp_config.json not found for migration {migration_id}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail=f"gcp_config.json not found for migration {migration_id}")
#     with open(config_path, 'r') as f:
#         gcp_config = yaml.safe_load(f)
#     project_id = gcp_config.get("project_id")
#     bucket_name = gcp_config.get("bucket_name")
#     if not project_id or not bucket_name:
#         msg = "project_id and bucket_name must be in gcp_config.json"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=400, detail="project_id and bucket_name must be in gcp_config.json")
#     service_account_path = os.path.join(WORKSPACE_DIR, migration_id, "configuration", "service_account.json")
#     if not os.path.exists(service_account_path):
#         msg = "Service account file not found."
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=404, detail="Service account file not found.")
#     credentials = service_account.Credentials.from_service_account_file(service_account_path)
#     storage_client = storage.Client(credentials=credentials)
#     cloudbuild_client = cloudbuild_v1.CloudBuildClient(credentials=credentials)
#     tar_stream = io.BytesIO()
#     with tarfile.open(fileobj=tar_stream, mode='w:gz') as tar:
#         msg = f"Packaging source files for pipeline {pipeline_name}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         tar.add(yaml_local_path, arcname="cloudbuild.yaml")
#         tar.add(beam_script_local_path, arcname=beam_script_name)
#     tar_stream.seek(0)
#     gcs_source_path = f"dataflow_deployments/{pipeline_name}/source.tar.gz"
#     bucket = storage_client.bucket(bucket_name)
#     blob = bucket.blob(gcs_source_path)
#     blob.upload_from_file(tar_stream, content_type='application/gzip')
#     msg = f"Uploaded source to gs://{bucket_name}/{gcs_source_path}"
#     logger.info(f"[{migration_id}] {msg}")
#     write_log(migration_id, msg)
#     with open(yaml_local_path, 'r') as f:
#         msg = f"Reading cloudbuild.yaml for pipeline {pipeline_name}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         build_config = yaml.safe_load(f)
#     build = cloudbuild_v1.Build()
#     build.source = {"storage_source": {"bucket": bucket_name, "object_": gcs_source_path}}
#     for step in build_config["steps"]:
#         msg = f"Adding build step: {step.get('name')}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         build.steps.append(cloudbuild_v1.BuildStep(
#             name=step.get("name"),
#             entrypoint=step.get("entrypoint"),
#             args=step.get("args", [])
#         ))
#     try:
#         operation = cloudbuild_client.create_build(project_id=project_id, build=build)
#         build_id = operation.metadata.build.id
#         log_url = operation.metadata.build.log_url
#         msg = f"Started Cloud Build job: {build_id} for pipeline {pipeline_name}"
#         logger.info(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         write_deployed_file(
#             pipeline_dir, pipeline_name, f"{build_id}"
#         )
#         return {
#             "message": f"Pipeline '{pipeline_name}' deployed successfully.",
#             "build_id": build_id,
#             "log_url": log_url,
#             "gcs_source_path": f"gs://{bucket_name}/{gcs_source_path}"
#         }
#     except Exception as e:
#         msg = f"Failed to trigger Cloud Build: {e}"
#         logger.error(f"[{migration_id}] {msg}")
#         write_log(migration_id, msg)
#         raise HTTPException(status_code=500, detail=f"Failed to trigger Cloud Build: {e}")
























