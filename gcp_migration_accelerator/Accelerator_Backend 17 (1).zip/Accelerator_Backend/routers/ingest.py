from fastapi import APIRouter, UploadFile, File, Form, Request, HTTPException
from fastapi.responses import JSONResponse
import os
import zipfile
import shutil
import logging
import stat
import json
from typing import List, Optional
from datetime import datetime
from git import Repo
from urllib.parse import urlparse, urlunparse, urlencode, quote
 
router = APIRouter(
    prefix="/api/ingest",
    tags=["Ingestion"]
)
 
logger = logging.getLogger(__name__)
 
SUPPORTED_EXTENSIONS = ['.json', '.xml']
BASE_DIR = "Project_Workspace"


def create_migration_folder():
    os.makedirs(BASE_DIR, exist_ok=True)
    folders = [f for f in os.listdir(BASE_DIR) if f.startswith("migration_folder_")]
    max_id = max([int(f.split("_")[-1]) for f in folders if f.split("_")[-1].isdigit()], default=0)
    next_folder_name = f"migration_folder_{max_id + 1}"
    folder_path = os.path.join(BASE_DIR, next_folder_name)
 
    os.makedirs(os.path.join(folder_path, "extracted_files"), exist_ok=True)
    os.makedirs(os.path.join(folder_path, "parsed_output"), exist_ok=True)
    os.makedirs(os.path.join(folder_path, "notebook_generated"), exist_ok=True)
    os.makedirs(os.path.join(folder_path, "logs"), exist_ok=True)
 
    return folder_path
 
 
def setup_logger(log_path):
    logger = logging.getLogger(log_path)
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.FileHandler(log_path)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger
 
 
import tempfile
 
@router.post("/")
async def upload_zip_git_or_files(
    zipfile: Optional[UploadFile] = File(None),
    files: List[UploadFile] = File(default_factory=list),
    git_url: Optional[str] = Form(None),
    git_access_type: Optional[str] = Form("public"),  # "public" or "private"
    git_token: Optional[str] = Form(None),            # Only required for private
    migration_id: str = Form(...)
 
):
    if not migration_id:
        raise HTTPException(status_code=400, detail="migration_id is required. Please create it using /create_migration first.")
 
    migration_path = os.path.join(BASE_DIR, migration_id)
    if not os.path.exists(migration_path):
        raise HTTPException(status_code=404, detail=f"Migration folder '{migration_id}' does not exist. Create it via /create_migration.")
 
    ingest_path = os.path.join(migration_path, "extracted_files")
    log_file = os.path.join(migration_path, "logs", "activity.log")
    folder_logger = setup_logger(log_file)
 
    metadata = {
        "migration_folder": migration_id,
        "timestamp": datetime.utcnow().isoformat(),
        "source": None,
        "status": "started"
    }
 
    # Read config.json to get source type
    config_path = os.path.join(migration_path, "configuration", "config.json")
    if not os.path.exists(config_path):
        raise HTTPException(status_code=400, detail="config.json not found in migration folder.")
 
    with open(config_path, "r") as f:
        config = json.load(f)
 
    source_type = config.get("source", "").lower()
    if source_type not in ["informatica", "adf"]:
        raise HTTPException(status_code=400, detail="Unsupported source in config.json.")
 
    def validate_file_extensions(file_paths):
        if source_type == "informatica":
            return [f for f in file_paths if not f.lower().endswith(".xml")]
        elif source_type in ["adf"]:
            return [f for f in file_paths if not f.lower().endswith(".json")]
        else:
            return []
 
    def move_valid_files(src_dir, dest_dir):
        extracted = []
        for root, _, files in os.walk(src_dir):
            # Skip .git directory
            if ".git" in root.split(os.sep):
                continue
 
            for file in files:
                full_src = os.path.join(root, file)
                rel_path = os.path.relpath(full_src, src_dir)
                dest_file_path = os.path.join(dest_dir, rel_path)
 
                os.makedirs(os.path.dirname(dest_file_path), exist_ok=True)
                shutil.copy2(full_src, dest_file_path)
                extracted.append(dest_file_path)
 
        return extracted
 
    if zipfile:
        zip_path = os.path.join(migration_path, "uploaded.zip")
        with open(zip_path, "wb") as f:
            f.write(await zipfile.read())
        folder_logger.info("Zip file uploaded and saved.")
 
        with tempfile.TemporaryDirectory() as temp_extract_dir:
            extracted_temp = extract_zip(zip_path, temp_extract_dir)
            invalid_files = validate_file_extensions(extracted_temp)
            if invalid_files:
                raise HTTPException(status_code=400, detail=f"ZIP file contains invalid files for source '{source_type}': {invalid_files}")
            extracted = move_valid_files(temp_extract_dir, ingest_path)
 
        metadata.update({"source": "zip", "status": "completed", "file_count": len(extracted)})
        write_metadata(migration_path, metadata)
        return JSONResponse(content={
            "source": "zip",
            "msg": "Files extracted from ZIP",
            "folder": migration_id,
            "file_count": len(extracted),
            "files": [os.path.relpath(f, BASE_DIR).replace("\\", "/") for f in extracted]
        })
 
    elif git_url:
        folder_logger.info(f"Git URL received: {git_url}")
 
        if git_access_type == "private":
            if not git_token:
                raise HTTPException(status_code=400, detail="Access token required for private Git repositories.")
        else:
            git_token = None  # No token needed for public
 
        with tempfile.TemporaryDirectory() as temp_git_dir:
            try:
                extracted_temp = clone_git_repo(git_url, temp_git_dir, git_token)
            except Exception as e:
                folder_logger.error(f"Git clone failed: {str(e)}")
                raise HTTPException(status_code=500, detail=f"Git clone failed: {str(e)}")
 
            invalid_files = validate_file_extensions(extracted_temp)
            if invalid_files:
                raise HTTPException(status_code=400, detail=f"Git repo contains invalid files for source '{source_type}': {invalid_files}")
            extracted = move_valid_files(temp_git_dir, ingest_path)
 
        metadata.update({
            "source": "git",
            "git_url": git_url,
            "access_type": git_access_type,
            "status": "completed",
            "file_count": len(extracted)
        })
        write_metadata(migration_path, metadata)
        return JSONResponse(content={
            "source": "git",
            "msg": "Files extracted from Git repo",
            "folder": migration_id,
            "file_count": len(extracted),
            "files": [os.path.relpath(f, BASE_DIR).replace("\\", "/") for f in extracted]
        })
 
    elif files:
        folder_logger.info("Direct file upload received.")
 
        # Validate file extensions before saving
        filenames = [file.filename for file in files]
        invalid_files = validate_file_extensions(filenames)
        if invalid_files:
            raise HTTPException(status_code=400, detail=f"Uploaded files contain invalid files for source '{source_type}': {invalid_files}")
 
        saved = save_uploaded_files(files, ingest_path)
 
        metadata.update({"source": "files", "status": "completed", "file_count": len(saved)})
        write_metadata(migration_path, metadata)
        return JSONResponse(content={
            "source": "files",
            "msg": "Files extracted from files",
            "folder": migration_id,
            "file_count": len(saved),
            "files": [os.path.relpath(f, BASE_DIR).replace("\\", "/") for f in saved]
        })
 
    else:
        folder_logger.warning("No valid input (zipfile, git_url or files[]) provided.")
        raise HTTPException(status_code=400, detail="Provide zipfile, git_url or files[]")
 
 
 
def extract_zip(zip_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    extracted_files = []
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        for member in zip_ref.namelist():
            if not member.strip() or member.endswith('/'):
                continue
            dest_path = os.path.join(output_dir, member)
            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            with open(dest_path, 'wb') as f:
                f.write(zip_ref.read(member))
    extracted_files = route_or_preserve_files(output_dir)
    return extracted_files
 
from urllib.parse import urlparse, quote
 
def clone_git_repo(git_url, output_dir, token):
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir, onerror=handle_remove_readonly)
 
    # Sanitize and encode token
    token = token.strip()
    encoded_token = quote(token)
 
    # Parse original URL
    parsed = urlparse(git_url)
    if not parsed.hostname or not parsed.path:
        raise ValueError("Invalid Git URL")
 
    # Construct secure URL
    secure_url = f"https://x-access-token:{encoded_token}@{parsed.hostname}{parsed.path}"
 
    # Clone repo
    Repo.clone_from(secure_url, output_dir)
    return route_or_preserve_files(output_dir)
 
 
def save_uploaded_files(files: List[UploadFile], output_dir):
    os.makedirs(output_dir, exist_ok=True)
    saved = []
    for file in files:
        filename = file.filename
        ext = os.path.splitext(filename)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            continue
        subfolder = "ARM" if ext == ".json" else "Informatica"
        target_dir = os.path.join(output_dir, subfolder)
        os.makedirs(target_dir, exist_ok=True)
        full_path = os.path.join(target_dir, filename)
        with open(full_path, "wb") as f:
            f.write(file.file.read())
        saved.append(full_path)
    return saved
 
 
def route_or_preserve_files(base_dir):
    routed = []
    for root, _, files in os.walk(base_dir):
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext not in SUPPORTED_EXTENSIONS:
                continue
            src_path = os.path.join(root, file)
            rel_path = os.path.relpath(src_path, base_dir)
            parts = rel_path.split(os.sep)
            if len(parts) == 1:
                subfolder = "ARM" if ext == ".json" else "Informatica"
                target_dir = os.path.join(base_dir, subfolder)
                os.makedirs(target_dir, exist_ok=True)
                dest_path = os.path.join(target_dir, file)
                shutil.move(src_path, dest_path)
                routed.append(dest_path)
            else:
                routed.append(src_path)
    return routed
 
 
def handle_remove_readonly(func, path, exc_info):
    os.chmod(path, stat.S_IWRITE)
    func(path)
 
 
def write_metadata(folder_path, metadata):
    with open(os.path.join(folder_path, "metadata.json"), "w") as f:
        json.dump(metadata, f, indent=4)