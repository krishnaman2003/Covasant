from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
import os
import logging
import json
import shutil

router = APIRouter(
    prefix="/api/workspace",
    tags=["Project Workspace"]
)

BASE_DIR = "Project_Workspace"
logger = logging.getLogger(__name__)


def create_migration_folder():
    os.makedirs(BASE_DIR, exist_ok=True)

    # Only include folders that match the expected pattern with a numeric suffix
    folders = [
        f for f in os.listdir(BASE_DIR)
        if f.startswith("migration_folder_") and f.split("_")[-1].isdigit()
    ]   

    max_id = max([int(f.split("_")[-1]) for f in folders], default=0)
    next_folder_name = f"migration_folder_{max_id + 1}"
    folder_path = os.path.join(BASE_DIR, next_folder_name)

    os.makedirs(os.path.join(folder_path, "extracted_files"), exist_ok=True)
    os.makedirs(os.path.join(folder_path, "parsed_output"), exist_ok=True)
    os.makedirs(os.path.join(folder_path, "logs"), exist_ok=True)

    return folder_path



@router.post("/create_migration")
async def create_migration_api():
    folder_path = create_migration_folder()
    folder_name = os.path.basename(folder_path)
    return JSONResponse(content={
        "msg": "Migration folder created successfully",
        "migration_id": folder_name,
    })


@router.get("/")
async def list_migrations():
    try:
        if not os.path.exists(BASE_DIR):
            return JSONResponse(
                content={
                    "migrations": [],
                    "message": "Project workspace does not exist. Please create it first."
                }
            )
        migrations = []
        for f in os.listdir(BASE_DIR):
            folder_path = os.path.join(BASE_DIR, f)
            if os.path.isdir(folder_path) and f.startswith("migration_folder_") and f.split("_")[-1].isdigit():
                config_path = os.path.join(folder_path, "configuration", "config.json")
                source = target = None
                if os.path.exists(config_path):
                    try:
                        with open(config_path, "r") as cf:
                            config = json.load(cf)
                        source = config.get("source")
                        target = config.get("target")
                        project_name = config.get("project_name")
                        domain = config.get("domain")

                    except Exception:
                        pass
                migrations.append({
                    "migration_id": f,
                    "source": source,
                    "target": target,
                    "project_name": project_name,
                    "domain": domain
                })
        return JSONResponse(content={"migrations": migrations})
    except Exception as e:
        logger.error(f"Error listing migration folders: {e}")
        # Only return 500 if it's a real error, not just empty
        return JSONResponse(content={"migrations": [], "message": "Unexpected error occurred."})

@router.get("/source_target/{migration_id}")
async def get_source_target(migration_id: str):
    config_path = os.path.join(BASE_DIR, migration_id, "configuration", "config.json")
    if not os.path.exists(config_path):
        raise HTTPException(status_code=404, detail="Config file not found")
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        source = config.get("source")
        target = config.get("target")
        project_name = config.get("project_name")
        domain = config.get("domain")

        return JSONResponse(content={"source": source, "target": target, "project_name": project_name, "domain": domain})
    except Exception as e:
        logger.error(f"Error reading config.json: {e}")
        raise HTTPException(status_code=500, detail="Error reading config file") 
    

@router.delete("/delete_migration/{migration_id}")
async def delete_migration(migration_id: str):
    migration_path = os.path.join(BASE_DIR, migration_id)
    if not os.path.exists(migration_path):
        raise HTTPException(status_code=404, detail="Migration folder not found")
    
    try:
        logging.shutdown()
        shutil.rmtree(migration_path)
        logger.info(f"Successfully deleted migration folder: {migration_id}")
        return JSONResponse(content={"message": "Migration folder deleted successfully"})
    
    except Exception as e:
        logger.error(f"Error deleting migration folder: {e}")
        raise HTTPException(status_code=500, detail="Error deleting migration folder")
    


 
    

    



