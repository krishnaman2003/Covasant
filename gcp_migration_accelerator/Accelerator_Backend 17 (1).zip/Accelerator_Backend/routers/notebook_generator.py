import os
import json
import uuid
import re
from datetime import datetime
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional
from dotenv import load_dotenv
from google.oauth2 import service_account
import vertexai
from vertexai.preview.generative_models import GenerativeModel
import traceback
import logging
 
# Assuming setup_logger is defined in a sibling module, e.g., 'ingest.py'
def setup_logger(log_file):
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(levelname)s - %(message)s',
                        handlers=[
                            logging.FileHandler(log_file),
                            logging.StreamHandler()
                        ])
    return logging.getLogger(__name__)
 
router = APIRouter(prefix="/api/notebooks", tags=["Notebook Generator"])
 
load_dotenv(".env")
BASE_DIR = "Project_Workspace"
SERVICE_ACCOUNT_INFO = json.loads(os.getenv("GOOGLE_CREDENTIALS"))
credentials = service_account.Credentials.from_service_account_info(SERVICE_ACCOUNT_INFO)
vertexai.init(project=SERVICE_ACCOUNT_INFO["project_id"], credentials=credentials)
model = GenerativeModel("gemini-2.0-flash")
 
class NotebookRequest(BaseModel):
    migration_id: str
    selected_files: Optional[List[str]] = None
 
# Updated NotebookResponse model
class NotebookResponse(BaseModel):
    json_file: str
    output_dir: str
    notebook_ids: dict
    all_sections_generated: bool
    error: Optional[str] = None
 
# Updated sections list to use .py files
sections = ["catalog_setup.py", "ingestion.py", "transformation.py", "aggregated.py"]
 
# Updated prompt template for Databricks-compatible .py files
prompt_template = """
You are an expert in Databricks PySpark and Informatica ETL translation.
 
Given this JSON Informatica-based ETL spec, generate 4 modular notebooks with PySpark code following the Medallion Architecture (Bronze, Silver, Gold layers) in Databricks. Use Delta tables stored in ABFSS paths (Azure Blob File System) and ensure the notebooks are clean, clear, and executable as Databricks jobs with minimal setup. Each table’s schema must be declared just above its creation block. Use managed tables where possible, but use explicit paths only for Gold tables. Always use fully qualified table names (`etl_catalog.etl_schema.<table>`) in all notebooks to avoid storing tables in the `default` database.
 
**Important Instructions for Formatting:**
- The first line of each notebook must be `# Databricks notebook source`.
- Use `# COMMAND ----------` to separate distinct sections of code within each file.
- **Use `%sql` magic commands for all SQL statements.**
- Do not use the `%python` magic command anywhere in the notebooks.
- The generated code must not be enclosed in triple backticks (```).
- At the end of each notebook, add a single print statement: `print("Notebook <name> completed successfully")`.
 
1. `catalog_setup.py`: Create catalog if not exists `etl_catalog` MANAGED LOCATION, schema, and all Delta tables (`etl_catalog.etl_schema.SRC_<source>_bronze`, `etl_catalog.etl_schema.silver_<target>`, `etl_catalog.etl_schema.gold_<target>`). Define each table’s schema above its creation block and specify explicit ABFSS path only for Gold tables.
2. `ingestion.py`: Read raw sources (CSV, Oracle, etc. from ABFSS) and write to Bronze Delta tables (`etl_catalog.etl_schema.SRC_<source>_bronze`).
3. `transformation.py`: Read from Bronze Delta tables/views (`etl_catalog.etl_schema.SRC_<source>_bronze`), apply all transformations (as specified in JSON), and write to Silver Delta table (`etl_catalog.etl_schema.silver_<target>`).If the trasnsformations in json are not clear ,try to infer the transformations based on the source and target names .use the columns to do transformations.if transfoormations are mentioned in the json , then use them as it is.
4. `aggregated.py`: Read from Silver Delta table/view (`etl_catalog.etl_schema.silver_<target>`), apply final aggregations or transformations, and write to Gold Delta table (`etl_catalog.etl_schema.gold_<target>`).
 
Rules and Assumptions:
- Use Unity Catalog: All tables must be created as fully qualified (`etl_catalog.etl_schema.<table>`).
- Tables should be created only once in `catalog_setup.py` using `CREATE TABLE IF NOT EXISTS`. Do not re-create them in other notebooks.
- Use managed tables for Bronze and Silver layers.
- Use explicit ABFSS `LOCATION` only for Gold tables.
- Use Delta format for all tables.
- Define each table’s schema as a triple-quoted string before creation.
- Always use overwrite mode with `.option("overwriteSchema", "true")`.
- Use `.option("mergeSchema", "true")` where applicable (Silver & Gold).
- Use ABFSS paths only in:
  - `catalog_setup.py` (to define managed location & Gold table locations),
  - `ingestion.py` (to read raw sources),
  - `aggregated.py` (to write Gold tables).
- Add print() statements to indicate success at each stage.
- Use constants to define:
  - `storage_account`
  - `container`
  - `catalog_name = "etl_catalog"`
  - `schema_name = "etl_schema"`
- Create views with consistent naming like: `bronze_<source>_view`, `silver_<target>_view`.
- Use f""" """ format for all SQL queries with embedded variables.
- Include `spark.sql(f"USE CATALOG catalog_name")` after catalog creation.
- Always validate schema alignment between read/write steps.
- Avoid hardcoded paths or column types — use inferred schemas where safe.
-i dont want to have string literals in the code , so use f""" """ format for all SQL queries with embedded variables.i dont want my notebook to have string literals in the code.and my notebooks shouldnt start and end with triple quotes or any other comment syntax.
-i want my notebooks to be in .py format and not in .ipynb format.
-And there should be no print statements in the code not even for the  last line of each notebook.
---
 
🔹 TRANSFORMATION RULES:
Follow this logic while translating Informatica components:
 
| Component | PySpark Equivalent |
|---|---|
| Joiner | SQL joins or DataFrame joins (use aliases) |
| Filter | .filter() or SQL WHERE |
| Aggregator | .groupBy().agg() or SQL GROUP BY |
| Expression | .withColumn() or SQL expressions |
| Lookup | Broadcast join if source is small |
| Router | Multiple .filter() with different conditions |
| Update Strategy | Use MERGE if logic exists, otherwise overwrite |
| Sequence | Use row_number() or monotonically_increasing_id()|
 
---
Format:
Return each notebook in this format:
 
--- catalog_setup.py ---
#No comment(''' or "" or anything) or python(string)in first line
# Databricks notebook source
# COMMAND ----------
# Define all constants and paths.
# COMMAND ----------
# Create the Unity Catalog, schema, and all Delta tables (Bronze, Silver, Gold).
# Use `%sql` for all CREATE statements.
# Declare schemas as triple-quoted strings just above each `CREATE TABLE` statement.
# Use `LOCATION` only for the Gold table, referencing the `gold_location` constant.
#No comment(''' or "" or anything) or python(string)in last line
 
 
--- ingestion.py ---
#No comment(''' or "" or anything) or python(string)in first line
# Databricks notebook source
# COMMAND ----------
# Define all constants and paths.
# COMMAND ----------
# Read the raw data from the source (e.g., CSV, Oracle) using ABFSS paths.
# COMMAND ----------
# Write the raw DataFrame to the Bronze Delta table using overwrite mode.
#No comment(''' or "" or anything) or python(string)in last line
 
 
--- transformation.py ---
#No comment(''' or "" or anything) or python(string)in first line
# Databricks notebook source
# COMMAND ----------
# Define constants and schema names.
# COMMAND ----------
# Read data from the Bronze Delta table(s).
# COMMAND ----------
# Apply all transformation logic as specified in the JSON.
# COMMAND ----------
# Write the transformed DataFrame to the Silver Delta table using overwrite mode.
 
#No comment(''' or "" or anything) or python(string)in last line
 
--- aggregated.py ---
#No comment(''' or "" or anything) or python(string)in first line
# Databricks notebook source
# COMMAND ----------
# Define constants and schema names.
# COMMAND ----------
# Read from the Silver Delta table(s) and apply final aggregations.
# COMMAND ----------
# Write the aggregated DataFrame to the Gold Delta table using overwrite mode and the explicit `gold_location`.
#No comment(''' or "" or anything) or python(string)in last line
 
---
 
INPUT JSON:
{etl_json}
"""
 
 
@router.post("/generate", response_model=List[NotebookResponse])
async def generate_dlt_notebooks(req: NotebookRequest):
    migration_id = req.migration_id
    selected_files = req.selected_files
    base_dir = os.path.join(BASE_DIR, migration_id)
    input_dir = os.path.join(base_dir, "parsed_output")
    output_base_dir = os.path.join(base_dir, "notebook_generated")
    registry_path = os.path.join(output_base_dir, "notebook_registry.json")
    os.makedirs(output_base_dir, exist_ok=True)
    log_file = os.path.join(base_dir, "logs", "activity.log")
    results = []
   
    folder_logger = setup_logger(log_file)
    folder_logger.info(f"notebook generation started for migration: {migration_id}")
 
    if os.path.exists(registry_path):
        with open(registry_path, "r") as regf:
            registry = json.load(regf)
    else:
        registry = {}
 
    all_json_files = [
        f for f in os.listdir(input_dir)
        if f.endswith(".json") and (not selected_files or f in selected_files)
    ]
 
    if not all_json_files:
        folder_logger.error(f"No matching JSON files found for migration: {migration_id}")
        raise HTTPException(status_code=404, detail="No matching JSON files found.")
 
    for json_file in all_json_files:
        try:
            with open(os.path.join(input_dir, json_file)) as f:
                etl_json = json.load(f)
            json_name = os.path.splitext(json_file)[0]
            base_output_dir = os.path.join(output_base_dir, json_name)
            output_dir = base_output_dir
            suffix = 1
            while os.path.exists(output_dir):
                output_dir = f"{base_output_dir}_{suffix}"
                suffix += 1
            os.makedirs(output_dir)
 
            prompt = prompt_template.format(etl_json=json.dumps(etl_json, indent=2))
            response = model.generate_content(prompt)
            output = response.text.strip()
 
            split_blocks = re.split(r'--- (.*?) ---', output)
            section_dict = {}
            # Corrected parsing logic to directly use the split blocks
            for i in range(1, len(split_blocks), 2):
                section_name = split_blocks[i].strip()
                code_block = split_blocks[i+1].strip()
                section_dict[section_name] = code_block
 
            notebook_ids = {}
            for section_filename in sections:
                if section_filename in section_dict:
                    code = section_dict[section_filename]
                    notebook_id = str(uuid.uuid4())[:8]
 
                    # Write the raw Python code directly to a .py file
                    py_path = os.path.join(output_dir, section_filename)
                    with open(py_path, "w", encoding="utf-8") as py_file:
                        py_file.write(code)
 
                    registry[notebook_id] = {
                        "id": notebook_id,
                        "source_json": os.path.join(input_dir, json_file),
                        "generated_at": datetime.utcnow().isoformat(),
                        "notebook_name": section_filename,
                        "notebook_path": py_path
                    }
                    notebook_ids[section_filename] = notebook_id
 
            folder_logger.info(f"Generated notebooks for {json_file} in {output_dir}")
            results.append(NotebookResponse(
                json_file=json_file,
                output_dir=output_dir,
                notebook_ids=notebook_ids,
                all_sections_generated=all(section in notebook_ids for section in sections),
                error=None
            ))
        except Exception as e:
            folder_logger.error(f"Failed to process {json_file}: {e}")
            folder_logger.error(f"Traceback: {traceback.format_exc()}")
            # Corrected response for validation
            results.append(NotebookResponse(
                json_file=json_file,
                output_dir="",  # Default value
                notebook_ids={},  # Default value
                all_sections_generated=False,  # Default value
                error=str(e)  # The actual error message
            ))
 
    with open(registry_path, "w") as regf:
        json.dump(registry, regf, indent=2)
    folder_logger.info(f"Notebook registry updated at {registry_path}")
    return results
 
# Endpoint to download the .py file
@router.get("/download/{notebook_id}")
async def get_notebook_code(notebook_id: str):
    project_root = BASE_DIR
    for migration_folder in os.listdir(project_root):
        migration_path = os.path.join(project_root, migration_folder)
        if not os.path.isdir(migration_path):
            continue
 
        registry_path = os.path.join(migration_path, "notebook_generated", "notebook_registry.json")
        if not os.path.exists(registry_path):
            continue
 
        with open(registry_path) as regf:
            registry = json.load(regf)
 
        notebook = registry.get(notebook_id)
        if notebook and os.path.exists(notebook["notebook_path"]):
            return FileResponse(
                notebook["notebook_path"],
                media_type="text/x-python",
                filename=os.path.basename(notebook["notebook_path"])
            )
 
    raise HTTPException(status_code=404, detail="Python file for Notebook ID not found")
 
# Helper function to build the folder tree for the API
def build_folder_tree_with_ids(folder_path: str, registry: dict) -> list:
    tree = []
    for entry in os.scandir(folder_path):
        if entry.name == "notebook_registry.json":
            continue
 
        if entry.is_dir():
            tree.append({
                "name": entry.name,
                "type": "folder",
                "children": build_folder_tree_with_ids(entry.path, registry)
            })
        elif entry.is_file():
            relative_path = os.path.normpath(entry.path)
            notebook_id = ""
 
            for nid, meta in registry.items():
                registry_path = os.path.normpath(meta.get("notebook_path", ""))
                if registry_path == relative_path:
                    notebook_id = nid
                    break
 
            file_entry = {
                "name": entry.name,
                "type": "file",
                "notebook_id": notebook_id
            }
            tree.append(file_entry)
    return tree
 
@router.get("/notebook_list/{migration_id}")
async def list_notebooks(migration_id: str):
    root_path = os.path.join(BASE_DIR, migration_id, "notebook_generated")
    if not os.path.exists(root_path):
        raise HTTPException(status_code=404, detail="Invalid migration_id")
 
    registry_path = os.path.join(root_path, "notebook_registry.json")
    registry = {}
 
    if os.path.exists(registry_path):
        with open(registry_path, "r") as f:
            registry = json.load(f)
 
    folder_tree = build_folder_tree_with_ids(root_path, registry)
 
    return {
        "migration_id": migration_id,
        "path": root_path,
        "tree": folder_tree
    }
 
@router.put("/update/{notebook_id}")
async def update_notebook(notebook_id: str, file: UploadFile = File(...)):
    project_root = BASE_DIR
    for migration_folder in os.listdir(project_root):
        migration_path = os.path.join(project_root, migration_folder)
        registry_path = os.path.join(migration_path, "notebook_generated", "notebook_registry.json")
 
        if not os.path.exists(registry_path):
            continue
 
        with open(registry_path) as f:
            registry = json.load(f)
 
        notebook_info = registry.get(notebook_id)
        if notebook_info:
            notebook_path = os.path.normpath(notebook_info["notebook_path"])
            notebook_name = notebook_info["notebook_name"]
            notebook_dir = os.path.dirname(notebook_path)
           
            if os.path.exists(notebook_path):
                backup_path = os.path.join(notebook_dir, notebook_name + ".txt")
                with open(notebook_path, "rb") as original_file:
                    with open(backup_path, "wb") as backup_file:
                        backup_file.write(original_file.read())
 
            contents = await file.read()
            with open(notebook_path, "wb") as f:
                f.write(contents)
 
            return {
                "message": f"Notebook '{notebook_name}' updated successfully.",
                "backup_created": f"{notebook_name}.txt"
            }
   
    raise HTTPException(status_code=404, detail="Notebook ID not found or file is missing")
 