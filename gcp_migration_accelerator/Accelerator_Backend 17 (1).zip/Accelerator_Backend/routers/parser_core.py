from fastapi import APIRouter, UploadFile, File, Form, Request, HTTPException
from fastapi.responses import JSONResponse, FileResponse
import os
import json
import logging
import mimetypes
 
from requests import request
from routers.ingest import setup_logger
 
from parser.informatica_parser import parse_informatica
from parser.adf_parser import convert_to_uniform_format
from typing import List
 
router = APIRouter(prefix="/api/parse", tags=["Parser"])
 
# logger = logging.getLogger(__name__)

BASE_DIR = "Project_Workspace"

PARSER_MAPPING = {
   
    ".xml": ("informatica", parse_informatica),
    ".json": ("adf", convert_to_uniform_format),
}
 
def detect_parser(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    return PARSER_MAPPING.get(ext, (None, None))[0]
 
def route_to_parser(parser_type, file_path):
    for ext, (ptype, pfunc) in PARSER_MAPPING.items():
        if ptype == parser_type:
            if parser_type == "adf":
                with open(file_path, "rb") as f:
                    return pfunc(f.read())
            else:
                return pfunc(file_path)
    raise ValueError(f"No parser found for type: {parser_type}")
 
@router.post("/")
async def parse(migration_id: str = Form(...)):
    base_dir = os.path.join(BASE_DIR, migration_id)
    # form = await request.form()
    # migration_id = form.get("migration_id")
    if not migration_id:
        raise HTTPException(status_code=400, detail="migration_id is required")
 
    base_dir = os.path.join(BASE_DIR, migration_id)
    input_dir = os.path.join(base_dir, "extracted_files")
    base_output_dir = os.path.join(base_dir, "parsed_output")
    log_file = os.path.join(base_dir, "logs", "activity.log")
 
    os.makedirs(base_output_dir, exist_ok=True)
    folder_logger = setup_logger(log_file)
    folder_logger.info(f"Parsing started for migration: {migration_id}")
 
    parsed_json_info = []
 
    for root, _, files in os.walk(input_dir):
        for file in files:
            filepath = os.path.join(root, file)
            if "parsed_output" in filepath:
                continue
 
            parser_type = detect_parser(filepath)
            if not parser_type:
                folder_logger.warning(f"Skipped unsupported file: {filepath}")
                continue
 
            folder_logger.info(f"Parsing file: {filepath} using {parser_type} parser")
 
            try:
                result = route_to_parser(parser_type, filepath)
 
                json_filename = os.path.splitext(os.path.basename(filepath))[0] + ".json"
                json_path = os.path.join(base_output_dir, json_filename)
 
                with open(json_path, "w") as f:
                    json.dump(result, f, indent=2)
 
                parsed_json_info.append({
                    "json_path": os.path.relpath(json_path, start=base_dir),
                    "source_path": os.path.relpath(filepath, start=base_dir)
                })
 
                folder_logger.info(f"Parsed and saved: {json_filename}")
 
            except Exception as e:
                folder_logger.error(f"Error parsing {filepath}: {str(e)}")
 
    json_locations = [item["json_path"] for item in parsed_json_info]
    folder_logger.info(f"Parsing completed. Total files parsed: {len(json_locations)}")
 
    return JSONResponse(content={
        "parsed_count": len(json_locations),
        "json_files": json_locations
    })
 
# @router.get("/parsed/{migration_id}")
# async def list_parsed_json_files(migration_id: str):
#     parsed_output_dir = os.path.join(BASE_DIR, migration_id, "parsed_output")
#     log_file = os.path.join(BASE_DIR, migration_id, "logs", "activity.log")
#     folder_logger = setup_logger(log_file)
#     if not os.path.exists(parsed_output_dir):
#         folder_logger.error(f" parsed_output folder not found for migration: {migration_id}")
#         raise HTTPException(status_code=404, detail="parsed_output folder not found")
 
#     json_files = [
#         filename for filename in os.listdir(parsed_output_dir)
#         if filename.endswith(".json") and os.path.isfile(os.path.join(parsed_output_dir, filename))
#     ]
#     folder_logger.info(f" Listing {len(json_files)} parsed files for migration: {migration_id}")
#     return JSONResponse(content={"json_files": json_files})

@router.get("/parsed/{migration_id}")
async def list_parsed_json_files(migration_id: str):
    parsed_output_dir = os.path.join(BASE_DIR, migration_id, "parsed_output")
    log_file = os.path.join(BASE_DIR, migration_id, "logs", "activity.log")
    folder_logger = setup_logger(log_file)
    if not os.path.exists(parsed_output_dir):
        folder_logger.error(f" parsed_output folder not found for migration: {migration_id}")
        return JSONResponse(content={"json_files": []})

    json_files = [
        filename for filename in os.listdir(parsed_output_dir)
        if filename.endswith(".json") and os.path.isfile(os.path.join(parsed_output_dir, filename))
    ]

    # Read status file if exists
    status_path = os.path.join(parsed_output_dir, "generated_status.json")
    if os.path.exists(status_path):
        with open(status_path, "r") as f:
            status = json.load(f)
    else:
        status = {}

    files_with_flag = []
    for filename in json_files:
        files_with_flag.append({
            "filename": filename,
            "generated": status.get(filename, False)
        })

    folder_logger.info(f" Listing {len(json_files)} parsed files for migration: {migration_id}")
    return JSONResponse(content={"json_files": files_with_flag})
 
@router.get("/parsed/{migration_id}/{filename}")
async def download_parsed_json_file(migration_id: str, filename: str):
    parsed_base_path = os.path.join(BASE_DIR, migration_id, "parsed_output")
    log_file = os.path.join(BASE_DIR, migration_id, "logs", "activity.log")
    folder_logger = setup_logger(log_file)
 
    for root, _, files in os.walk(parsed_base_path):
        if filename in files:
            file_path = os.path.join(root, filename)
            mimetype, _ = mimetypes.guess_type(file_path)
            mimetype = mimetype or "application/json"
            folder_logger.info(f" File served: {filename} from migration: {migration_id}")
            return FileResponse(file_path, filename=filename, media_type=mimetype)
    folder_logger.warning(f" File not found: {filename} in migration: {migration_id}")
    raise HTTPException(status_code=404, detail=f"{filename} not found under {parsed_base_path}")
 
@router.put("/parsed/{migration_id}/{filename}")
async def update_parsed_json_file_by_name(migration_id: str, filename: str, file: UploadFile = File(...)):
    parsed_base_path = os.path.join(BASE_DIR, migration_id, "parsed_output")
    log_file = os.path.join(BASE_DIR, migration_id, "logs", "activity.log")
    folder_logger = setup_logger(log_file)
    file_path = None
    folder_path = None
 
    for root, _, files in os.walk(parsed_base_path):
        if filename in files:
            file_path = os.path.join(root, filename)
            folder_path = root
            break
 
    if not file_path:
        folder_logger.error(f"Original file not found: {filename} in migration: {migration_id}")
        raise HTTPException(status_code=404, detail="Original file not found")
 
    if not file.filename:
        folder_logger.error("Uploaded file has empty filename")
        raise HTTPException(status_code=400, detail="Uploaded file has empty filename")
 
    base_name = os.path.splitext(filename)[0]
    existing_versions = [
        f for f in os.listdir(folder_path)
        if f.startswith(base_name) and f.endswith(".txt") and "_v" in f
    ]
 
    version_numbers = []
    for f in existing_versions:
        try:
            version = int(f.split("_v")[-1].split(".")[0])
            version_numbers.append(version)
        except ValueError:
            continue
 
    next_version = max(version_numbers, default=0) + 1
    backup_txt_filename = f"{base_name}_v{next_version}.txt"
    backup_txt_path = os.path.join(folder_path, backup_txt_filename)
 
    with open(file_path, "r", encoding="utf-8") as existing_file:
        with open(backup_txt_path, "w", encoding="utf-8") as backup_file:
            backup_file.write(existing_file.read())
 
    with open(file_path, "wb") as f:
        f.write(await file.read())
 
    folder_logger.info(f"Updated {filename} and created backup {backup_txt_filename} in migration: {migration_id}")
    return JSONResponse(content={
        "message": f"{filename} updated successfully.",
        "backup_created": os.path.relpath(backup_txt_path, BASE_DIR),
        "version": next_version
    })