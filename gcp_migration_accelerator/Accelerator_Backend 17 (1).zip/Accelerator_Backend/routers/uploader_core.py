import os
import requests
import json
from fastapi import APIRouter, HTTPException, status, BackgroundTasks
from fastapi.responses import JSONResponse
from typing import List, Optional, Dict
from pydantic import BaseModel
import logging
import time
import traceback
import glob
 
from databricks_deployer.notebook_uploader import (
    create_workspace_folder,
    upload_all_notebooks_in_folder,
    upload_notebooks_from_folders,
    upload_selected_notebooks,
    create_databricks_job,
    run_databricks_job
)
 
# Configure logging to append to activity.log in the migration-specific logs directory
def setup_logging(migration_id: str):
    log_dir = os.path.join("Project_Workspace", migration_id, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "activity.log")
   
    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
   
    # Remove existing handlers to avoid duplicate logging
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
   
    # Create file handler for activity.log
    file_handler = logging.FileHandler(log_file, mode='a')
    file_handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
   
    # Add handler to the logger
    logger.addHandler(file_handler)
   
    # Configure uploader_core logger to use the same handler
    uploader_logger = logging.getLogger('databricks_deployer.notebook_uploader')
    uploader_logger.setLevel(logging.INFO)
    for handler in uploader_logger.handlers[:]:
        uploader_logger.removeHandler(handler)
    uploader_logger.addHandler(file_handler)
   
    return logger
 
router = APIRouter(prefix="/api/deployer", tags=["Notebook Deployment"])
 
class DeployAndRunRequest(BaseModel):
    migration_id: str
    mode: Optional[str] = "all"
    notebook_ids: Optional[List[str]] = []
    folder_names: Optional[List[str]] = []
 
def wait_for_job_run(databricks_instance: str, databricks_token: str, run_id: int) -> bool:
    """Wait for a job run to complete and return True if successful, False if failed."""
    logger.info(f"Background Task: Waiting for job run ID: {run_id}")
    api_url = f"{databricks_instance}/api/2.1/jobs/runs/get?run_id={run_id}"
    headers = {"Authorization": f"Bearer {databricks_token}", "Content-Type": "application/json"}
   
    start_time = time.time()
    timeout = 1800  # 30 minutes timeout
   
    while True:
        if time.time() - start_time > timeout:
            logger.error(f"Background Task: Job run {run_id} timed out after {timeout} seconds.")
            raise Exception(f"Background Task: Job run {run_id} timed out.")
       
        response = requests.get(api_url, headers=headers)
        if response.status_code != 200:
            logger.error(f"Background Task: Failed to get job run status for {run_id}: {response.text}")
            raise Exception(f"Background Task: Failed to get job run status for {run_id}: {response.text}")
       
        run_info = response.json()
        state = run_info["state"]["life_cycle_state"]
       
        if state in ["TERMINATED", "SKIPPED", "INTERNAL_ERROR"]:
            result_state = run_info["state"].get("result_state")
            if result_state != "SUCCESS":
                tasks = run_info.get("tasks", [])
                task_errors = []
                for task in tasks:
                    task_key = task.get("task_key")
                    task_state = task["state"].get("life_cycle_state")
                    if task_state in ["FAILED", "CANCELED"]:
                        task_message = task["state"].get("state_message", "No details provided")
                        task_output = "No output available or not a notebook task."
                        if "notebook_task" in task:
                            api_url_output = f"{databricks_instance}/api/2.1/jobs/runs/get-output?run_id={run_id}"
                            output_response = requests.get(api_url_output, headers=headers)
                            if output_response.status_code == 200:
                                output_data = output_response.json()
                                if task_key and output_data.get("tasks"):
                                    for run_task_output in output_data.get("tasks", []):
                                        if run_task_output.get("task_key") == task_key:
                                            task_output = run_task_output.get("notebook_output", {}).get("result", "No notebook output found for this task.")
                                            break
                                elif "notebook_output" in output_data:
                                    task_output = output_data.get("notebook_output", {}).get("result", "No notebook output found.")
                            else:
                                task_output = f"Failed to fetch task output: {output_response.text}"
                        task_errors.append({
                            "task_key": task_key,
                            "status": task_state,
                            "message": task_message,
                            "output": task_output
                        })
                if task_errors:
                    error_detail = f"Background Task: Job run {run_id} failed with task errors: {json.dumps(task_errors, indent=2)}"
                    logger.error(error_detail)
                    return False
               
                logger.error(f"Background Task: Job run {run_id} failed: {run_info['state'].get('state_message', 'No specific message.')}")
                return False
           
            logger.info(f"Background Task: Job run {run_id} completed successfully.")
            return True
       
        logger.info(f"Background Task: Job run {run_id} is still {state}. Checking again in 10 seconds...")
        time.sleep(10)
 
def _write_deployed_file(
    migration_id: str,
    deployment_mode: str,
    local_target_folders: List[str],
    job_run_registry: Dict
):
    """Writes a .deployed file indicating jobs are deployed and started, without success/failure status."""
    notebooks_base_path = os.path.join("Project_Workspace", migration_id, "notebook_generated")

    summarized_jobs = []
    for job_name, job_info in job_run_registry.items():
        job_id = job_info.get("job_id")
        run_id = job_info.get("run_id")
        deployed_status = "YES" if job_id is not None else "NO"
        summarized_jobs.append({
            "job_name": job_name,
            "job_id": job_id,
            "run_id": run_id,
            "deployed_status": deployed_status
        })
   
    deployed_info_content = {
        "migration_id": migration_id,
        "jobs": summarized_jobs
    }
 
    target_write_paths = []
    if deployment_mode == "folder" and local_target_folders:
        for folder_name in local_target_folders:
            specific_folder_path = os.path.join(notebooks_base_path, folder_name)
            deployed_file_name = f"{folder_name}.deployed"
            target_write_paths.append(os.path.join(specific_folder_path, deployed_file_name))
    else:
        target_write_paths.append(os.path.join(notebooks_base_path, ".deployed"))
 
    for deployed_file_path in target_write_paths:
        write_path_dir = os.path.dirname(deployed_file_path)
        deployed_file_name_only = os.path.basename(deployed_file_path)
        logger.info(f"Background Task: Attempting to write .deployed file at: {deployed_file_path}")
        os.makedirs(write_path_dir, exist_ok=True)
        try:
            with open(deployed_file_path, "w", encoding="utf-8") as f:
                json.dump(deployed_info_content, f, indent=2)
            logger.info(f"Background Task: Successfully created .deployed file in: {write_path_dir} named {deployed_file_name_only}")
        except Exception as e:
            logger.error(f"Background Task: Failed to write .deployed file at {deployed_file_path}: {e}")
            logger.error(f"Background Task: Traceback for .deployed file write:\n{traceback.format_exc()}")
 
def _get_local_notebook_names(migration_id: str, mode: str, notebook_ids: List[str], folder_names: List[str]) -> List[str]:
    """Determine locally present notebooks based on deployment mode."""
    base_path = os.path.join("Project_Workspace", migration_id, "notebook_generated")
    found_notebooks = set()
 
    if mode == "all":
        for root, _, files in os.walk(base_path):
            for file in files:
                if file.endswith((".py", ".ipynb", ".sql")):
                    found_notebooks.add(os.path.splitext(file)[0])
    elif mode == "folder":
        for folder_name in folder_names:
            folder_path = os.path.join(base_path, folder_name)
            if os.path.isdir(folder_path):
                for file in os.listdir(folder_path):
                    if file.endswith((".py", ".ipynb", ".sql")):
                        found_notebooks.add(os.path.splitext(file)[0])
            else:
                logger.warning(f"Local folder '{folder_name}' not found for migration_id {migration_id}. Skipping notebook identification.")
    elif mode == "files":
        for nb_id in notebook_ids:
            possible_paths = glob.glob(os.path.join(base_path, "**", f"{nb_id}.*"), recursive=True)
            if possible_paths:
                found_notebooks.add(nb_id)
            else:
                logger.warning(f"Local notebook file for ID '{nb_id}' not found in '{base_path}'. It won't be considered for job creation or upload.")
   
    return sorted(list(found_notebooks))
def _generate_dynamic_jobs_definitions(deployed_notebook_names: List[str], folder_name: str = None) -> List[Dict]:
    """Generate job definitions based on deployed notebooks with folder_name prefix in job names."""
    logger.info(f"Generating job definitions with folder_name: {folder_name}")
    dynamic_jobs = []
    pipeline_components = {
        "catalog_setup": {"job_name_base": "catalog_setup", "main_notebook": "catalog_setup"},
        "ingestion": {"job_name_base": "ingestion", "main_notebook": "ingestion", "depends_on_notebook_in_same_job": "catalog_setup"},
        "transformation": {"job_name_base": "transformation", "main_notebook": "transformation", "depends_on_job_name_base": "catalog_setup"},
        "aggregated": {"job_name_base": "aggregated", "main_notebook": "aggregated", "depends_on_job_name_base": "transformation"},
    }
    ordered_notebook_keys = ["catalog_setup", "ingestion", "transformation", "aggregated"]
    created_jobs: Dict[str, Dict] = {}
 
    # Use folder_name if provided, otherwise default to empty string
    folder_prefix = f"{folder_name}_" if folder_name else ""
 
    for notebook_key in ordered_notebook_keys:
        if notebook_key in deployed_notebook_names:
            component = pipeline_components.get(notebook_key)
            if not component:
                logger.warning(f"Notebook '{notebook_key}' is deployed but not defined in pipeline_components. It will not be part of a Databricks job.")
                continue
            # Determine job name
            if "depends_on_notebook_in_same_job" in component:
                # For ingestion, use the job name of the notebook it depends on (catalog_setup)
                dep_notebook = component["depends_on_notebook_in_same_job"]
                job_name = f"{folder_prefix}{pipeline_components[dep_notebook]['job_name_base']}"
            else:
                job_name = f"{folder_prefix}{component['job_name_base']}"
           
            if job_name not in created_jobs:
                created_jobs[job_name] = {
                    "job_name": job_name,
                    "notebooks": [],
                    "depends_on_jobs": []
                }
            created_jobs[job_name]["notebooks"].append(component["main_notebook"])
           
            if "depends_on_job_name_base" in component:
                dep_job_name_base = component["depends_on_job_name_base"]
                dep_job_name = f"{folder_prefix}{dep_job_name_base}"
                is_dependent_job_in_this_deployment = any(
                    comp_val.get("job_name_base") == dep_job_name_base and comp_key in deployed_notebook_names
                    for comp_key, comp_val in pipeline_components.items()
                )
                if is_dependent_job_in_this_deployment and dep_job_name not in created_jobs[job_name]["depends_on_jobs"]:
                    created_jobs[job_name]["depends_on_jobs"].append(dep_job_name)
 
    # Maintain job order
    conceptual_job_order = [
        f"{folder_prefix}catalog_setup",
        f"{folder_prefix}transformation",
        f"{folder_prefix}aggregated"
    ]
    for job_name_in_order in conceptual_job_order:
        if job_name_in_order in created_jobs:
            dynamic_jobs.append(created_jobs[job_name_in_order])
 
    logger.info(f"Dynamically generated job definitions")
    return dynamic_jobs
async def _process_jobs_in_background(
    migration_id: str,
    databricks_instance: str,
    databricks_folder_path: str,
    databricks_token: str,
    cluster_id: Optional[str],
    cluster_type: str,
    jobs_definitions: List[Dict],
    parameters: dict,
    deployment_mode: str,
    local_target_folders: List[str],
    job_run_registry: Dict
):
    logger.info(f"Background Task: Starting job processing for migration_id: {migration_id}")
    job_run_registry_path = os.path.join("Project_Workspace", migration_id, "job_run_registry.json")

    try:
        # Wait for the first job to complete
        first_job_name = jobs_definitions[0]["job_name"]
        if first_job_name in job_run_registry and job_run_registry[first_job_name].get("run_id"):
            logger.info(f"Background Task: Waiting for first job {first_job_name} (run ID: {job_run_registry[first_job_name]['run_id']}) to complete.")
            success = wait_for_job_run(databricks_instance, databricks_token, job_run_registry[first_job_name]["run_id"])
            job_run_registry[first_job_name]["status"] = "SUCCESS" if success else "FAILED"
            if not success:
                logger.error(f"Background Task: First job {first_job_name} failed. Stopping further job execution.")
                for task in job_run_registry[first_job_name]["tasks"]:
                    if task["status"] != "SUCCESS":
                        task["status"] = "FAILED"
                _write_deployed_file(migration_id, deployment_mode, local_target_folders, job_run_registry)
                return
 
        # Process remaining jobs sequentially
        for job_def in jobs_definitions[1:]:  # Skip first job
            current_job_name = job_def["job_name"]
            if current_job_name not in job_run_registry or job_run_registry[current_job_name]["status"] == "SKIPPED_NO_TASKS":
                logger.warning(f"Background Task: Skipping run for {current_job_name} as it was not created.")
                continue
 
            current_job_id = job_run_registry[current_job_name]["job_id"]
            try:
                # Check dependencies
                can_run = True
                for dep in job_def.get("depends_on_jobs", []):
                    if dep in job_run_registry and job_run_registry[dep].get("run_id"):
                        logger.info(f"Background Task: Checking dependent job {dep} (run ID: {job_run_registry[dep]['run_id']}).")
                        if job_run_registry[dep]["status"] != "SUCCESS":
                            logger.error(f"Background Task: Dependent job {dep} did not succeed (status: {job_run_registry[dep]['status']}). Skipping {current_job_name}.")
                            job_run_registry[current_job_name]["status"] = "SKIPPED_DUE_TO_DEPENDENCY_FAILURE"
                            job_run_registry[current_job_name]["error"] = f"Dependent job '{dep}' did not succeed."
                            can_run = False
                            break
 
                if not can_run:
                    continue
 
                # Start job
                logger.info(f"Background Task: Starting job run for {current_job_name} (Job ID: {current_job_id})...")
                run_id = run_databricks_job(databricks_instance, databricks_token, current_job_id)
                job_run_registry[current_job_name]["run_id"] = run_id
                job_run_registry[current_job_name]["status"] = "RUNNING"
                for task in job_run_registry[current_job_name]["tasks"]:
                    task["status"] = "RUNNING"
                logger.info(f"Background Task: Successfully initiated run for {current_job_name} (Job ID: {current_job_id}, Run ID: {run_id}).")
 
                # Wait for job to complete
                success = wait_for_job_run(databricks_instance, databricks_token, run_id)
                job_run_registry[current_job_name]["status"] = "SUCCESS" if success else "FAILED"
                if not success:
                    logger.error(f"Background Task: Job {current_job_name} failed. Stopping further job execution.")
                    for task in job_run_registry[current_job_name]["tasks"]:
                        if task["status"] != "SUCCESS":
                            task["status"] = "FAILED"
                    _write_deployed_file(migration_id, deployment_mode, local_target_folders, job_run_registry)
                    return
 
            except Exception as e:
                logger.error(f"Background Task: Failed to start or complete job {current_job_name}: {str(e)}")
                logger.error(f"Background Task: Traceback: {traceback.format_exc()}")
                job_run_registry[current_job_name]["status"] = "FAILED"
                job_run_registry[current_job_name]["error"] = str(e)
                for task in job_run_registry[current_job_name]["tasks"]:
                    task["status"] = "FAILED"
                _write_deployed_file(migration_id, deployment_mode, local_target_folders, job_run_registry)
                return
 
        # Write final .deployed file
        if job_run_registry:
            logger.info(f"Background Task: Writing final .deployed file(s) for migration_id {migration_id}")
            _write_deployed_file(migration_id, deployment_mode, local_target_folders, job_run_registry)
   
    except Exception as e:
        logger.critical(f"Background Task: Critical error during job processing for migration_id {migration_id}: {str(e)}")
        logger.critical(f"Background Task: Traceback: {traceback.format_exc()}")
        if job_run_registry:
            _write_deployed_file(migration_id, deployment_mode, local_target_folders, job_run_registry)
   
    finally:
        logger.info(f"Background Task: Saving final job run registry to: {job_run_registry_path}")
        os.makedirs(os.path.dirname(job_run_registry_path), exist_ok=True)
        with open(job_run_registry_path, "w", encoding="utf-8") as f:
            json.dump(job_run_registry, f, indent=2)
 
@router.post("/deploy_and_run")
async def deploy_and_run_jobs(req: DeployAndRunRequest, background_tasks: BackgroundTasks):
    try:
        migration_id = req.migration_id
        mode = req.mode.lower()
        notebook_ids = req.notebook_ids or []
        folder_names = req.folder_names or []
       
        # Setup logging for this migration_id
        global logger
        logger = setup_logging(migration_id)
        logger.info(f"API Endpoint: Received deploy_and_run request for migration_id: {migration_id}, mode: {mode}, folder_names: {folder_names}")

        config_path = os.path.join("Project_Workspace", migration_id, "configuration", "config.json")
        logger.info(f"API Endpoint: Loading config from: {config_path}")
        if not os.path.exists(config_path):
            logger.error(f"API Endpoint: config.json not found at: {config_path}")
            raise HTTPException(status_code=400, detail="config.json not found")
        with open(config_path, "r", encoding="utf-8") as cfg:
            config = json.load(cfg)
       
        databricks_instance = config.get("instance")
        databricks_token = config.get("access_token")
        cluster_id = config.get("cluster_id")
        email = config.get("email")
        config_folder_path = config.get("folder_path")
        parameters = config.get("parameters", {})
 
        if not (databricks_instance and databricks_token and email):
            logger.error("API Endpoint: Missing required fields in config.json: instance, access_token, email")
            raise HTTPException(status_code=400, detail="Missing required fields in config.json: instance, access_token, email")
 
        cluster_type = "allpurpose" if cluster_id else "serverless"
        if cluster_type == "allpurpose" and not cluster_id:
            logger.error("API Endpoint: cluster_id required for all_purpose cluster but not found in config.json")
            raise HTTPException(status_code=400, detail="cluster_id required for all_purpose cluster")
 
        folder_name = folder_names[0] if folder_names else migration_id
        logger.info(f"API Endpoint: Using folder_name: {folder_name} for job name prefix")
        base_path = f"/Users/{email.lstrip('/')}"
        databricks_folder_path = f"{base_path}/{config_folder_path}/{folder_name}".rstrip("/") if config_folder_path else f"{base_path}/{folder_name}".rstrip("/")
 
        logger.info(f"API Endpoint: Creating workspace folder: {databricks_folder_path}")
        try:
            create_workspace_folder(databricks_instance, databricks_token, databricks_folder_path)
        except Exception as e:
            logger.error(f"API Endpoint: Failed to create workspace folder: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to create workspace folder: {str(e)}")
 
        logger.info(f"API Endpoint: Uploading notebooks for mode: {mode}")
        uploaded = False
        if mode == "all":
            uploaded = upload_all_notebooks_in_folder(migration_id, databricks_token, databricks_instance, databricks_folder_path)
        elif mode == "folder":
            if not folder_names:
                logger.error("API Endpoint: 'folder_names' required for mode='folder' in request body.")
                raise HTTPException(status_code=400, detail="'folder_names' required for mode='folder'.")
            uploaded = upload_notebooks_from_folders(migration_id, folder_names, databricks_token, databricks_instance, databricks_folder_path)
        elif mode == "files":
            if not notebook_ids:
                logger.error("API Endpoint: 'notebook_ids' required for mode='files' in request body.")
                raise HTTPException(status_code=400, detail="'notebook_ids' required for mode='files'.")
            uploaded = upload_selected_notebooks(migration_id, notebook_ids, databricks_token, databricks_instance, databricks_folder_path)
        else:
            logger.error(f"API Endpoint: Invalid mode: {mode}")
            raise HTTPException(status_code=400, detail="Invalid mode. Use one of: all, folder, files.")
 
        if not uploaded:
            logger.warning("API Endpoint: No notebooks were uploaded.")
            raise HTTPException(
                status_code=400,
                detail="No notebooks found to deploy. Check your selected mode and notebook/folder names."
            )
 
        deployed_notebook_names = _get_local_notebook_names(migration_id, mode, notebook_ids, folder_names)
       
        if not deployed_notebook_names:
            logger.warning(f"API Endpoint: No relevant notebooks found locally for job creation after upload check.")
            raise HTTPException(
                status_code=400,
                detail="No relevant notebooks found locally to create jobs. Check your selected mode and notebook/folder names."
            )
 
        jobs_definitions = _generate_dynamic_jobs_definitions(deployed_notebook_names, folder_name)
 
        if not jobs_definitions:
            logger.warning("API Endpoint: No Databricks jobs could be defined based on the uploaded notebooks and pipeline logic.")
            raise HTTPException(
                status_code=400,
                detail="Notebooks uploaded, but no Databricks jobs defined based on pipeline logic."
            )
 
        # Create all jobs synchronously
        job_run_registry = {}
        for job_def in jobs_definitions:
            current_job_name = job_def["job_name"]
            tasks = []
            for j, notebook_name in enumerate(job_def["notebooks"]):
                notebook_path = f"{databricks_folder_path}/{notebook_name}"
                task_key = f"{notebook_name}_task"
                task = {
                    "task_key": task_key,
                    "notebook_task": {
                        "notebook_path": notebook_path,
                        "base_parameters": parameters
                    }
                }
                if j > 0:
                    task["depends_on"] = [{"task_key": f"{job_def['notebooks'][j-1]}_task"}]
                if cluster_type == "serverless":
                    task["job_cluster_key"] = "serverless_cluster"
                elif cluster_type == "allpurpose":
                    task["existing_cluster_id"] = cluster_id
                tasks.append(task)
 
            if not tasks:
                logger.warning(f"API Endpoint: No valid tasks for job {current_job_name}. Skipping job definition creation.")
                job_run_registry[current_job_name] = {"status": "SKIPPED_NO_TASKS", "error": "No valid tasks."}
                continue
 
            logger.info(f"API Endpoint: Creating job definition for {current_job_name}...")
            job_id = create_databricks_job(
                databricks_instance,
                databricks_token,
                current_job_name,
                tasks,
                cluster_type,
                cluster_id
            )
            job_run_registry[current_job_name] = {
                "job_id": job_id,
                "run_id": None,
                "tasks": [
                    {"notebook_name": nb, "notebook_path": f"{databricks_folder_path}/{nb}", "status": "PENDING"}
                    for nb in job_def["notebooks"]
                ],
                "status": "CREATED"
            }
            logger.info(f"API Endpoint: Successfully created job definition for {current_job_name} (Job ID: {job_id}).")
 
        # Start first job
        first_job = jobs_definitions[0]
        current_job_name = first_job["job_name"]
        current_job_id = job_run_registry[current_job_name]["job_id"]
        logger.info(f"API Endpoint: Starting job {current_job_name} with job_id {current_job_id}")
        run_id = run_databricks_job(databricks_instance, databricks_token, current_job_id)
        job_run_registry[current_job_name]["run_id"] = run_id
        job_run_registry[current_job_name]["status"] = "RUNNING"
        for task in job_run_registry[current_job_name]["tasks"]:
            task["status"] = "RUNNING"
        logger.info(f"API Endpoint: Successfully initiated run for {current_job_name} (Job ID: {current_job_id}, Run ID: {run_id}).")
 
        # Write initial .deployed file
        if job_run_registry:
            logger.info(f"API Endpoint: Writing initial .deployed file(s) for migration_id {migration_id}")
            _write_deployed_file(migration_id, mode, folder_names, job_run_registry)
 
        # Schedule remaining jobs in background
        background_tasks.add_task(
            _process_jobs_in_background,
            migration_id,
            databricks_instance,
            databricks_folder_path,
            databricks_token,
            cluster_id,
            cluster_type,
            jobs_definitions,
            parameters,
            mode,
            folder_names,
            job_run_registry
        )
       
        logger.info("API Endpoint: All jobs created. First job started, remaining jobs scheduled in background.")
        return JSONResponse(
            status_code=status.HTTP_202_ACCEPTED,
            content={"message": "Notebooks uploaded successfully. Job creation and execution started in the background."}
        )
 
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"API Endpoint: Error during initial deployment setup: {str(e)}")
        logger.error(f"API Endpoint: Traceback: {traceback.format_exc()}")
        if job_run_registry:
            _write_deployed_file(migration_id, mode, folder_names, job_run_registry)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An unexpected error occurred during initial setup: {str(e)}. Check server logs for details."
        )
 
@router.get("/{migration_id}")
def get_migration_folders_status(migration_id: str):
    """Lists all deployable folders within a migration's 'notebook_generated' directory."""
    # Setup logging for this migration_id
    global logger
    logger = setup_logging(migration_id)

    notebook_generated_dir = os.path.join("Project_Workspace", migration_id, "notebook_generated")

    logger.info(f"API Endpoint: Listing deployable folders for migration_id: {migration_id} in {notebook_generated_dir}")
    if not os.path.exists(notebook_generated_dir):
        logger.warning(f"API Endpoint: Notebook generated directory not found at: {notebook_generated_dir}")
        raise HTTPException(status_code=404, detail="Notebook generated directory not found for this migration_id.")
   
    folders_status = []
    for name in os.listdir(notebook_generated_dir):
        folder_path = os.path.join(notebook_generated_dir, name)
        if os.path.isdir(folder_path):
            deployed_file = os.path.join(folder_path, f"{name}.deployed")
            is_deployed = os.path.exists(deployed_file)
            folders_status.append({
                "folder_name": name,
                "deployed": is_deployed
            })
   
    logger.info(f"API Endpoint: Found {len(folders_status)} deployable folders for migration_id: {migration_id}")
    return {"folders": folders_status}
 
@router.get("/{migration_id}/{folder_name}")
def get_folder_deployed_details(migration_id: str, folder_name: str):
    """Retrieves the content of the '{folder_name}.deployed' file."""
    # Setup logging for this migration_id
    global logger
    logger = setup_logging(migration_id)

    deployed_file = os.path.join("Project_Workspace", migration_id, "notebook_generated", folder_name, f"{folder_name}.deployed")

    logger.info(f"API Endpoint: Getting deployed details for folder: {folder_name} in migration_id: {migration_id}")
    if not os.path.exists(deployed_file):
        logger.warning(f"API Endpoint: Deployed file not found at: {deployed_file}")
        raise HTTPException(status_code=404, detail=f"Deployed file '{folder_name}.deployed' not found for this folder.")
   
    try:
        with open(deployed_file, "r", encoding="utf-8") as f:
            deployment_details = json.load(f)
        logger.info(f"API Endpoint: Successfully retrieved deployed details for folder: {folder_name}")
        return {"deployment_details": deployment_details}
    except json.JSONDecodeError:
        logger.error(f"API Endpoint: Error decoding JSON from deployed file: {deployed_file}")
        raise HTTPException(
            status_code=500,
            detail=f"Error reading deployment details for '{folder_name}'. File content might be corrupted."
        )
    except Exception as e:
        logger.error(f"API Endpoint: An unexpected error occurred while reading deployed file: {deployed_file}. Error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"An unexpected error occurred: {e}"
        )
 