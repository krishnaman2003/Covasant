from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
import os
import json
import logging
from google.oauth2 import service_account
from google.cloud import storage

router = APIRouter(prefix="/api/gcp-validation", tags=["GCP Validation"])

# Setup logging to app.log
logging.basicConfig(
    filename="app.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)

def log_and_return_error(message, status_code=400):
    logging.error(message)
    return JSONResponse(status_code=status_code, content={"error": message})

@router.post("/validate")
async def validate_gcp_config(
    project_name: str = Form(...),
    project_id: str = Form(...),
    region: str = Form(...),
    bucket_name: str = Form(...),
    json_file: UploadFile = File(...)
):
    workspace_dir = "Project_Workspace"

    # 1. Unique project name validation
    for folder in os.listdir(workspace_dir):
        config_path = os.path.join(workspace_dir, folder, "configuration", "config.json")
        if os.path.exists(config_path):
            with open(config_path, "r") as f:
                config = json.load(f)
            if config.get("project_name", "").strip().lower() == project_name.strip().lower():
                return log_and_return_error(f"Project name '{project_name}' already exists.")

    # 2. Service account JSON validation
    try:
        service_account_bytes = await json_file.read()
        service_account_info = json.loads(service_account_bytes)
        credentials = service_account.Credentials.from_service_account_info(service_account_info)
    except Exception as e:
        return log_and_return_error(f"Invalid JSON input. Please upload valid JSON input: {str(e)}")

    # 3. Service account existence and type (project-level)
    try:
        sa_email = service_account_info.get("client_email", "")
        if not sa_email or "iam.gserviceaccount.com" not in sa_email:
            return log_and_return_error("Service account email is missing or invalid.")
        
        if service_account_info.get("project_id") != project_id:
            return log_and_return_error("Project ID does not exist. Please provide a valid Project ID.")

        if not sa_email.endswith(f"@{project_id}.iam.gserviceaccount.com"):
            return log_and_return_error("Service account is not project-level or project_id does not match service account.")


        # 4. Bucket existence validation
        storage_client = storage.Client(credentials=credentials, project=project_id)
        bucket = storage_client.bucket(bucket_name)
        if not bucket.exists():
            return log_and_return_error(f"Bucket '{bucket_name}' does not exist. Please provide a valid Bucket Name.")

        # 5. Region validation (check bucket location)
        bucket.reload()
        if bucket.location.lower() != region.lower():
            return log_and_return_error(f"Bucket region {region} does not exist. Please provide a valid Region.")

    except Exception as e:
        return log_and_return_error(f"GCP validation failed: {str(e)}")

    logging.info(f"GCP validation passed for project_name='{project_name}', project_id='{project_id}', bucket='{bucket_name}', region='{region}'")
    return JSONResponse(content={"message": "All GCP validations passed."})